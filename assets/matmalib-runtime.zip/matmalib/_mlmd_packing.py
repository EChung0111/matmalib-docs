"""Periodic Packmol packing adapted from Aimnet/build_solvated_cell.py."""


from __future__ import annotations


import logging

AVOGADRO = 6.02214076e23
ANGSTROM3_TO_ML = 1e-24
GENERATED_FILES = (
    "solute.pdb", "solvent.pdb", "counterion.pdb", "packmol.inp",
    "packmol.log", "packed.pdb", "cell.pdb", "cell.xyz", "summary.json",
    "initial_packmol.inp", "initial_packmol.log", "initial_packed.pdb",
)

def _report(message, **kwargs):
    logging.getLogger(__name__).debug(message)


from dataclasses import dataclass


from io import StringIO


import json


import math


from pathlib import Path


import shutil


import subprocess


import sys


import numpy as np


from ase import Atoms, io


from ase.data import atomic_masses, atomic_numbers, vdw_radii


from ase.neighborlist import neighbor_list


@dataclass
class CellSettings:
    solute: Path
    solvent: Path
    counter_ion: Path | None
    box: float | list[float] | tuple[float, ...]
    density: float
    output_dir: Path
    packmol: str
    tolerance: float
    nloop: int
    timeout: float
    seed: int
    dry_run: bool
    volume_samples: int
    vdw_radius: dict[str, float]
    counterion_gap: float


@dataclass
class Molecule:
    role: str
    source: Path
    atoms: Atoms
    radii: np.ndarray
    mass: float  # g/mol, numerically equal to the molecular mass in u
    volume: float  # angstrom^3
    volume_error: float  # Monte Carlo standard error, angstrom^3


def sphere_union_volume(
    positions: np.ndarray, radii: np.ndarray, samples: int = 200_000, seed: int = 12345
) -> tuple[float, float]:
    """Estimate the union, including multiple overlaps; return volume and SE.

    Points are sampled uniformly in the enclosing box in bounded-memory batches.
    A point contributes once if it lies in ANY sphere. The standard error measures
    sampling error only, not uncertainty in the chosen atomic radii.
    """
    positions = np.asarray(positions, dtype=float)
    radii = np.asarray(radii, dtype=float)
    if (positions.ndim != 2 or positions.shape[1] != 3 or len(positions) == 0
            or radii.shape != (len(positions),)):
        raise ValueError("Expected nonempty positions (N, 3) and radii (N,).")
    if (not np.isfinite(positions).all() or not np.isfinite(radii).all()
            or np.any(radii <= 0) or samples < 2):
        raise ValueError("Coordinates/radii must be finite, radii positive, samples >= 2.")
    if len(radii) == 1:
        return float(4.0 * math.pi * radii[0] ** 3 / 3.0), 0.0
    lower = np.min(positions - radii[:, None], axis=0)
    widths = np.max(positions + radii[:, None], axis=0) - lower
    box_volume = float(np.prod(widths))
    rng = np.random.default_rng(seed)
    hits = 0
    # Larger spheres first can reduce the remaining membership work.
    order = np.argsort(-radii)
    for start in range(0, samples, 8192):
        points = lower + rng.random((min(8192, samples - start), 3)) * widths
        inside = np.zeros(len(points), dtype=bool)
        for i in order:
            remaining = np.flatnonzero(~inside)
            if len(remaining) == 0:
                break
            delta = points[remaining] - positions[i]
            inside[remaining] = np.einsum("ij,ij->i", delta, delta) <= radii[i] ** 2
        hits += int(inside.sum())
    fraction = hits / samples
    if hits == 0:
        raise ValueError("No vdW volume samples hit the molecule; increase VOLUME_SAMPLES.")
    return (box_volume * fraction,
            box_volume * math.sqrt(fraction * (1.0 - fraction) / (samples - 1)))


def pdb_element(line: str) -> str:
    """Use the PDB element column, or standard atom-name alignment if absent."""
    element = line[76:78].strip().capitalize()
    if not element:
        name = line[12:16]
        letters = "".join(c for c in name if c.isalpha())
        if not letters:
            raise ValueError(f"Cannot infer an element from atom name {name!r}.")
        # ' CA ' is carbon (alpha carbon); 'CA  ' is calcium.
        if name[0].isspace() or name[0].isdigit():
            element = letters[0].upper()
        else:
            candidate = letters[:2].capitalize()
            element = candidate if candidate in atomic_numbers else letters[0].upper()
    if element not in atomic_numbers or atomic_numbers[element] == 0:
        raise ValueError(f"Unknown element {element!r}; set PDB columns 77-78 explicitly.")
    return element


def read_pdb_atoms(path: Path) -> Atoms:
    """Normalize one PDB conformation without guessing bonds or adding atoms."""
    lines = path.read_text().splitlines()
    if sum(line[:6].strip() == "MODEL" for line in lines) > 1:
        raise ValueError(f"{path}: provide one PDB model, not a trajectory/ensemble.")
    records = []
    model_ended = False
    for line in lines:
        record = line[:6].strip()
        if record in ("ENDMDL", "END"):
            model_ended = True
        if record not in ("ATOM", "HETATM"):
            continue
        if model_ended:
            raise ValueError(f"{path}: atom records found after END/ENDMDL.")
        line = line.ljust(80)
        if line[16].strip():
            raise ValueError(f"{path}: select one alternate conformation and clear altLoc.")
        occupancy = line[54:60].strip()
        if occupancy and (not math.isfinite(float(occupancy))
                          or not math.isclose(float(occupancy), 1.0, abs_tol=0.001)):
            raise ValueError(f"{path}: use fully occupied atoms (occupancy 1.00 or blank).")
        element = pdb_element(line)
        records.append(line[:76] + f"{element:>2}" + line[78:])
    if not records:
        raise ValueError(f"{path}: no ATOM/HETATM records.")
    # Discard input cell/transform records: each template is an isolated molecule.
    atoms = io.read(StringIO("\n".join(records) + "\nEND\n"), format="proteindatabank")
    if not np.isfinite(atoms.positions).all():
        raise ValueError(f"{path}: coordinates must be finite.")
    atoms.positions -= atoms.positions.mean(axis=0)
    return atoms


def read_molecule(
    path: Path, role: str, overrides: dict[str, float], samples: int, seed: int
) -> Molecule:
    atoms = read_pdb_atoms(path)
    radii = []
    for symbol, number in zip(atoms.get_chemical_symbols(), atoms.numbers):
        radius = overrides.get(symbol, vdw_radii[number] if number < len(vdw_radii) else np.nan)
        if not np.isfinite(radius) or radius <= 0:
            raise ValueError(
                f"{path}: no vdW radius for {symbol}; set VDW_RADII_OVERRIDES = "
                f"{{{symbol!r}: radius_in_angstrom}}."
            )
        radii.append(radius)
    mass = float(atomic_masses[atoms.numbers].sum())
    volume, error = sphere_union_volume(atoms.positions, radii, samples, seed)
    return Molecule(role, path.resolve(), atoms, np.asarray(radii), mass, volume, error)


def solvent_count(box: np.ndarray, density: float, fixed_mass: float,
                  solvent_mass: float) -> tuple[int, float]:
    """Choose the nearest positive solvent count and return the achieved density."""
    box = np.asarray(box, dtype=float)
    if box.shape != (3,) or not np.isfinite(box).all() or np.any(box <= 0):
        raise ValueError("Box requires three finite positive lengths.")
    if (not all(math.isfinite(x) for x in (density, fixed_mass, solvent_mass))
            or density <= 0 or fixed_mass <= 0 or solvent_mass <= 0):
        raise ValueError("Density and molecular masses must be finite and positive.")
    volume_ml = float(np.prod(box)) * ANGSTROM3_TO_ML
    target_mass = density * volume_ml * AVOGADRO
    if not math.isfinite(target_mass):
        raise ValueError("Box volume/density is too large.")
    if target_mass <= fixed_mass:
        raise ValueError("The solute/counterion alone exceed the target mass; enlarge the box.")
    count = math.floor((target_mass - fixed_mass) / solvent_mass + 0.5)
    if count < 1:
        raise ValueError("Density/box gives zero solvent molecules; enlarge the box or raise density.")
    achieved = (fixed_mass + count * solvent_mass) / (AVOGADRO * volume_ml)
    return count, achieved


def central_positions(
    solute: Molecule, ion: Molecule | None, box: np.ndarray,
    tolerance: float, gap: float,
) -> dict[str, np.ndarray]:
    """Center the solute and place the ion nearby without intersecting vdW spheres.

    For each of 26 directions, find the outermost end of all atom-pair collision
    intervals along that ray. Choose the closest placement that fits in the box
    and satisfies the separation under minimum-image periodic distances too.
    Templates are centered on their geometric centers by read_molecule().
    """
    center = box / 2
    # Keep fixed atoms far enough from faces for the periodic-padding retry,
    # and keep their vdW spheres entirely in the cell.
    def fits(molecule: Molecule, location: np.ndarray) -> bool:
        positions = molecule.atoms.positions + location
        margins = np.maximum(molecule.radii, tolerance / 2)[:, None] + 0.01
        return bool(np.all(positions >= margins) and np.all(positions <= box - margins))

    if not fits(solute, center):
        raise ValueError("The centered solute does not fit inside CELL; enlarge the cell.")
    centers = {"solute": center}
    if ion is None:
        return centers

    delta = ion.atoms.positions[None, :, :] - solute.atoms.positions[:, None, :]
    required = np.maximum(solute.radii[:, None] + ion.radii[None, :] + gap, tolerance)
    # Reserve room for template/output coordinate rounding to 0.001 angstrom.
    required = required + 0.01
    squared = np.sum(delta ** 2, axis=2)
    candidates = []
    for direction in np.ndindex(3, 3, 3):
        direction = np.asarray(direction, dtype=float) - 1
        norm = np.linalg.norm(direction)
        if norm == 0:
            continue
        direction /= norm
        projection = delta @ direction
        perpendicular_squared = np.maximum(0.0, squared - projection ** 2)
        intersects = perpendicular_squared < required ** 2
        distance = 0.0
        if np.any(intersects):
            ends = -projection[intersects] + np.sqrt(
                required[intersects] ** 2 - perpendicular_squared[intersects]
            )
            distance = max(0.0, float(ends.max())) + 0.001
        offset = distance * direction
        location = center + offset
        if not fits(ion, location):
            continue
        periodic_delta = delta + offset
        periodic_delta -= box * np.rint(periodic_delta / box)
        if np.any(np.linalg.norm(periodic_delta, axis=2) < required):
            continue
        candidates.append((distance, location))
    if not candidates:
        raise ValueError(
            "Cannot place the counterion beside the centered solute without overlap. "
            "Enlarge CELL or reduce SOLUTE_COUNTERION_GAP."
        )
    centers["counterion"] = min(candidates, key=lambda item: item[0])[1]
    return centers


def packmol_input(molecules: list[tuple[Molecule, int]], box: np.ndarray,
                  tolerance: float, seed: int, nloop: int,
                  fixed_centers: dict[str, np.ndarray], padding: float = 0.0) -> str:
    lengths = " ".join(f"{length:.8f}" for length in box)
    lower = " ".join(f"{padding:.8f}" for _ in range(3))
    upper = " ".join(f"{length - padding:.8f}" for length in box)
    lines = [
        "# Run from this directory: packmol < packmol.inp",
        "# Requires Packmol >= 20.15.0 for periodic boundary conditions.",
        f"tolerance {tolerance:.8f}", "filetype pdb", "output packed.pdb",
        # Packmol's default constraint tolerance permits atoms ~0.1 A outside
        # the box. Tighten it to match the 0.001 A precision of PDB coordinates.
        "precision 0.000001",
        f"seed {seed}", f"nloop {nloop}", f"pbc {lengths}", "",
    ]
    # File/atom order: solute, optional counterion, then solvent.
    for molecule, count in molecules:
        lines.extend([f"structure {molecule.role}.pdb", f"  number {count}"])
        if molecule.role in fixed_centers:
            position = " ".join(f"{x:.8f}" for x in fixed_centers[molecule.role])
            lines.extend(["  center", f"  fixed {position} 0.0 0.0 0.0"])
        else:
            lines.append(f"  inside box {lower} {upper}")
        lines.extend(["end structure", ""])
    return "\n".join(lines)


def closest_clash(atoms: Atoms, molecule_ids: np.ndarray,
                  tolerance: float) -> tuple[int, int, float, bool] | None:
    """Find a packing clash, excluding internal bonds but including self images.

    Allow 0.005 A for Packmol convergence and coordinate rounding in PDB.
    The last return value identifies contacts through a periodic boundary.
    """
    cutoff = tolerance - min(0.005, 0.01 * tolerance)
    i, j, distance, shifts = neighbor_list("ijdS", atoms, cutoff, self_interaction=False)
    periodic = np.any(shifts != 0, axis=1)
    clashes = np.flatnonzero((molecule_ids[i] != molecule_ids[j]) | periodic)
    if not len(clashes):
        return None
    k = clashes[np.argmin(distance[clashes])]
    return int(i[k]), int(j[k]), float(distance[k]), bool(periodic[k])


def run_packmol(executable: str, directory: Path, timeout: float) -> None:
    log_path = directory / "packmol.log"
    (directory / "packed.pdb").unlink(missing_ok=True)
    try:
        with (directory / "packmol.inp").open() as source, log_path.open("w") as log:
            result = subprocess.run(
                [executable], stdin=source, stdout=log, stderr=subprocess.STDOUT,
                cwd=directory, timeout=timeout, check=False,
            )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f"Packmol exceeded {timeout:g} seconds; see {log_path}.") from exc
    log = log_path.read_text(errors="replace")
    if (result.returncode != 0 or "Success!" not in log
            or not (directory / "packed.pdb").is_file()):
        raise RuntimeError(
            f"Packmol did not converge successfully (exit {result.returncode}); see {log_path}. "
            "Check CELL, DENSITY, PACKMOL_TOLERANCE, and PACKMOL_NLOOP. "
            "Packmol >= 20.15.0 is required."
        )


def build(args: CellSettings, *, input_masses=None, source_labels=None) -> dict:
    """Build a cell, optionally retaining masses/provenance from State or XYZ inputs."""
    box = np.atleast_1d(np.asarray(args.box, dtype=float))
    if box.shape == (1,):
        box = np.repeat(box, 3)
    if box.shape != (3,):
        raise ValueError("CELL must be one length or [Lx, Ly, Lz] in angstrom.")
    # PDB CRYST1 stores lengths to 0.001 angstrom. Use the same cell everywhere.
    box = np.round(box, 3)
    if not np.isfinite(box).all() or np.any(box <= 0) or np.any(box > 9999.999):
        raise ValueError("Box lengths must round to 0.001..9999.999 angstrom for PDB output.")
    for name, value in (
        ("DENSITY", args.density), ("PACKMOL_TOLERANCE", args.tolerance),
        ("PACKMOL_TIMEOUT", args.timeout),
    ):
        if not math.isfinite(value) or value <= 0:
            raise ValueError(f"{name} must be finite and greater than zero.")
    for name, value in (
        ("RANDOM_SEED", args.seed), ("VOLUME_SAMPLES", args.volume_samples),
        ("PACKMOL_NLOOP", args.nloop),
    ):
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError(f"{name} must be a positive integer.")
    if args.volume_samples < 2 or args.seed > 2_147_483_647:
        raise ValueError("VOLUME_SAMPLES must be >= 2 and RANDOM_SEED <= 2147483647.")
    if not isinstance(args.dry_run, bool):
        raise ValueError("DRY_RUN must be True or False.")
    if not math.isfinite(args.counterion_gap) or args.counterion_gap < 0:
        raise ValueError("SOLUTE_COUNTERION_GAP must be finite and nonnegative.")
    directory = args.output_dir.expanduser().resolve()
    if directory.exists() and not directory.is_dir():
        raise ValueError(f"OUTPUT_DIR points to a file, not a directory: {directory}")
    executable = None
    if not args.dry_run:
        executable = shutil.which(args.packmol)
        if executable is None:
            raise ValueError(
                "Packmol not found; set PACKMOL_EXECUTABLE to its path or set DRY_RUN = True."
            )
        executable = str(Path(executable).resolve())
    if not isinstance(args.vdw_radius, dict):
        raise ValueError('VDW_RADII_OVERRIDES must be a dictionary, e.g. {"Cl": 1.8}.')
    overrides = {}
    for symbol, raw in args.vdw_radius.items():
        symbol = symbol.capitalize()
        if symbol not in atomic_numbers or symbol == "X":
            raise ValueError(f"Unknown element {symbol!r} in VDW_RADII_OVERRIDES.")
        radius = float(raw)
        if not math.isfinite(radius) or radius <= 0:
            raise ValueError(f"VDW_RADII_OVERRIDES[{symbol!r}] must be finite and positive.")
        overrides[symbol] = radius
    solute = read_molecule(args.solute, "solute", overrides, args.volume_samples, args.seed)
    solvent = read_molecule(args.solvent, "solvent", overrides, args.volume_samples, args.seed)
    molecules = [(solute, 1)]
    ion = None
    if args.counter_ion:
        ion = read_molecule(args.counter_ion, "counterion", overrides, args.volume_samples, args.seed)
        molecules.append((ion, 1))
    for molecule in [*(item for item, _ in molecules), solvent]:
        if input_masses is not None and molecule.role in input_masses:
            masses = np.asarray(input_masses[molecule.role], dtype=float)
            if (masses.shape != (len(molecule.atoms),) or not np.isfinite(masses).all()
                    or np.any(masses <= 0)):
                raise ValueError(f"{molecule.role} atomic masses must be finite and positive.")
            molecule.atoms.set_masses(masses)
            molecule.mass = float(masses.sum())
    fixed_centers = central_positions(solute, ion, box, args.tolerance, args.counterion_gap)
    fixed_mass = sum(m.mass * count for m, count in molecules)
    count, density = solvent_count(box, args.density, fixed_mass, solvent.mass)
    molecules.append((solvent, count))
    atom_count = sum(len(m.atoms) * n for m, n in molecules)
    if atom_count > 99999:
        raise ValueError(f"{atom_count} atoms exceeds the 99999-atom PDB serial limit.")
    volume = float(np.prod(box))
    volume_sum = sum(m.volume * n for m, n in molecules)
    report = {
        "status": "prepared", "box_angstrom": box.tolist(), "pbc": [True] * 3,
        "warnings": [],
        "cell_volume_angstrom3": volume, "target_density_g_ml": args.density,
        "achieved_density_g_ml": density, "atom_count": atom_count,
        "total_mass_u": sum(m.mass * n for m, n in molecules),
        "sum_molecular_vdw_volumes_angstrom3": volume_sum,
        "estimated_vdw_packing_fraction": volume_sum / volume,
        "volume_method": "Monte Carlo sphere union (single atoms analytic)",
        "volume_samples_per_molecule": args.volume_samples,
        "vdw_radius_source": "ase.data.vdw_radii, with explicit overrides",
        "vdw_radius_overrides_angstrom": overrides,
        "seed": args.seed, "packmol_tolerance_angstrom": args.tolerance,
        "packing_boundary_padding_angstrom": 0.0,
        "fixed_centers_angstrom": {role: position.tolist() for role, position in fixed_centers.items()},
        "solute_counterion_vdw_gap_angstrom": args.counterion_gap if ion is not None else None,
        "molecules": [{
            "role": m.role, "source": (source_labels or {}).get(m.role, str(m.source)), "count": n,
            "atoms_per_molecule": len(m.atoms), "formula": m.atoms.get_chemical_formula(),
            "atomic_masses_u": m.atoms.get_masses().tolist(),
            "molar_mass_g_mol": m.mass, "vdw_volume_angstrom3": m.volume,
            "vdw_volume_standard_error_angstrom3": m.volume_error,
            "vdw_radii_angstrom": dict(zip(m.atoms.get_chemical_symbols(), m.radii.tolist())),
        } for m, n in molecules],
    }
    _report(f"Box: {box.tolist()} angstrom; volume: {volume:.3f} angstrom^3")
    for molecule, number in molecules:
        _report(f"{molecule.role}: {number} x {molecule.atoms.get_chemical_formula()}, "
              f"M = {molecule.mass:.5f} g/mol, vdW volume = "
              f"{molecule.volume:.3f} +/- {molecule.volume_error:.3f} angstrom^3 (sampling SE)")
    _report(f"Density: requested {args.density:.6f}, achieved {density:.6f} g/mL; {atom_count} atoms")
    _report(f"Sum of molecular vdW volumes / cell volume: {volume_sum / volume:.4f}")
    for role, position in fixed_centers.items():
        _report(f"{role} geometric center (fixed during packing): {position.round(4).tolist()} angstrom")
    if volume_sum >= volume:
        warning = "Summed vdW volumes exceed the cell volume; packing may be difficult."
        report["warnings"].append(warning)
        _report(warning)
    generated_paths = [directory / name for name in GENERATED_FILES]
    source_paths = {molecule.source for molecule, _ in molecules}
    for path in generated_paths:
        if path.resolve() in source_paths:
            raise ValueError(f"Generated file would overwrite an input PDB: {path}; change OUTPUT_DIR.")
    directory.mkdir(parents=True, exist_ok=True)
    # Remove only this script's previous artifacts so a failed/dry run cannot
    # leave an old cell or packing result looking like output from the new run.
    for path in generated_paths:
        path.unlink(missing_ok=True)
    for molecule, _ in molecules:
        io.write(directory / f"{molecule.role}.pdb", molecule.atoms, format="proteindatabank")
    (directory / "packmol.inp").write_text(
        packmol_input(molecules, box, args.tolerance, args.seed, args.nloop, fixed_centers)
    )
    summary_path = directory / "summary.json"
    summary_path.write_text(json.dumps(report, indent=2) + "\n")
    if args.dry_run:
        _report(f"Prepared inputs and report in {directory} (Packmol was not run).")
        return report
    try:
        expected = np.concatenate([np.tile(m.atoms.numbers, n) for m, n in molecules])
        molecule_ids = np.repeat(
            np.arange(sum(n for _, n in molecules)),
            [len(m.atoms) for m, n in molecules for _ in range(n)],
        )
        for attempt in range(2):
            run_packmol(executable, directory, args.timeout)
            atoms = io.read(directory / "packed.pdb", format="proteindatabank")
            if not np.array_equal(atoms.numbers, expected) or not np.isfinite(atoms.positions).all():
                raise RuntimeError("Packmol output atom count/order/elements or coordinates are invalid.")
            if np.any(atoms.positions < -0.01) or np.any(atoms.positions > box + 0.01):
                raise RuntimeError("Packmol placed atoms outside the requested box.")
            atoms.set_cell(box)
            atoms.set_pbc(True)
            offset = 0
            for molecule, number in molecules:
                if molecule.role in fixed_centers:
                    planned = molecule.atoms.positions + fixed_centers[molecule.role]
                    if not np.allclose(
                        atoms.positions[offset:offset + len(molecule.atoms)],
                        planned, rtol=0, atol=0.003,
                    ):
                        raise RuntimeError(f"Packmol moved the fixed {molecule.role} from its planned position.")
                offset += len(molecule.atoms) * number
            if ion is not None:
                delta = (atoms.positions[len(solute.atoms):len(solute.atoms) + len(ion.atoms)][None, :, :]
                         - atoms.positions[:len(solute.atoms)][:, None, :])
                delta -= box * np.rint(delta / box)
                surface_gaps = np.linalg.norm(delta, axis=2) - solute.radii[:, None] - ion.radii[None, :]
                actual_gap = float(surface_gaps.min())
                if actual_gap < args.counterion_gap - 0.005:
                    raise RuntimeError("Packed solute/counterion violate SOLUTE_COUNTERION_GAP.")
                report["actual_solute_counterion_vdw_gap_angstrom"] = actual_gap
            clash = closest_clash(atoms, molecule_ids, args.tolerance)
            if clash is None:
                break
            i, j, distance, _ = clash
            if attempt or np.any(box <= args.tolerance):
                raise RuntimeError(
                    f"Packed atoms {i + 1} and {j + 1} clash at {distance:.4f} angstrom "
                    f"(required {args.tolerance:g}); see packed.pdb and packmol.log."
                )
            padding = args.tolerance / 2
            warning = (f"Packing contact at {distance:.4f} angstrom; retrying with "
                       f"{padding:g} angstrom face padding.")
            report["warnings"].append(warning)
            _report(warning)
            report["packing_boundary_padding_angstrom"] = padding
            for name in ("packmol.inp", "packmol.log", "packed.pdb"):
                (directory / name).rename(directory / f"initial_{name}")
            (directory / "packmol.inp").write_text(
                packmol_input(molecules, box, args.tolerance, args.seed, args.nloop, fixed_centers, padding)
            )
        atoms.set_masses(np.concatenate([np.tile(m.atoms.get_masses(), n) for m, n in molecules]))
        io.write(directory / "cell.pdb", atoms, format="proteindatabank")
        io.write(directory / "cell.xyz", atoms, format="extxyz",
                 columns=["symbols", "positions", "masses"], write_results=False)
    except (OSError, ValueError, RuntimeError) as exc:
        report.update(status="failed", error=str(exc))
        summary_path.write_text(json.dumps(report, indent=2) + "\n")
        exc.solvation_report = report
        raise
    report["status"] = "complete"
    summary_path.write_text(json.dumps(report, indent=2) + "\n")
    _report(f"Wrote {directory / 'cell.pdb'} and {directory / 'cell.xyz'}")
    return report
