"""PLUMED input and an ASE adapter with explicit MD steps and bias stress."""

from itertools import product
from numbers import Integral
import os
from pathlib import Path
import re

import numpy as np
from ase import units
from ase.calculators.calculator import Calculator, all_changes
from ase.calculators.plumed import Plumed
from ase.parallel import broadcast, world
from ase.stress import full_3x3_to_voigt_6_stress

from ._mlmd_io import output_path, positive


def flatten_input(lines):
    result, block = [], []
    for raw in lines:
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.endswith("...") and not line.startswith("..."):
            if block:
                raise ValueError("Nested PLUMED blocks are invalid.")
            block = [line[:-3].strip()]
        elif line.startswith("..."):
            if not block:
                raise ValueError("PLUMED block closes without an opening action.")
            result.append(" ".join(block))
            block = []
        elif block:
            block.append(line)
        else:
            result.append(line)
    if block:
        raise ValueError("Unterminated PLUMED block.")
    if not result:
        raise ValueError("PLUMED input is empty.")
    return result


def input_lines(config, atoms, md_config):
    structured = config.cvs is not None or config.pause_when is not None
    if structured and (config.plumed_file is not None or config.input_lines is not None):
        raise ValueError("Structured cvs/pause_when cannot be combined with custom PLUMED input.")
    if config.pause_when is not None and config.cvs is None:
        raise ValueError("pause_when requires structured cvs; a one-CV sequence is supported.")
    if config.cvs is not None:
        from ._mlmd_metadynamics import build_input_lines, normalize_spec
        spec = normalize_spec(config.cvs, config.pause_when, atom_count=len(atoms))
        return build_input_lines(spec, config, atoms, md_config)
    if config.plumed_file is not None and config.input_lines is not None:
        raise ValueError("Choose plumed_file or input_lines.")
    if config.plumed_file is not None:
        return flatten_input(Path(config.plumed_file).expanduser().read_text().splitlines())
    if config.input_lines is not None:
        return flatten_input(config.input_lines)
    labels = [config.cv_label, config.metad_label]
    if config.wall_type is not None:
        labels.append(config.wall_label)
    if any(not isinstance(label, str) or not re.fullmatch(r"[A-Za-z_]\w*", label)
           for label in labels) or len(set(labels)) != len(labels):
        raise ValueError("Generated PLUMED labels must be distinct identifiers.")
    metad_arg = config.cv_label if config.metad_arg is None else config.metad_arg
    wall_arg = config.cv_label if config.wall_arg is None else config.wall_arg
    for name, value in (("metad_arg", metad_arg), ("wall_arg", wall_arg),
                        ("colvar_arg", config.colvar_arg)):
        if value is not None and (not isinstance(value, str) or not re.fullmatch(
                r"(?:\*|[A-Za-z_][\w.*]*)(?:,(?:\*|[A-Za-z_][\w.*]*))*", value)):
            raise ValueError(f"{name} must contain comma-separated PLUMED references.")
    for name in ("calc_rct", "grid_auto"):
        if getattr(config, name) is not None and not isinstance(getattr(config, name), bool):
            raise ValueError(f"{name} must be True, False, or None (automatic).")
    cv = config.cv.upper()
    arity = {"DISTANCE": 2, "ANGLE": 3, "TORSION": 4}
    if cv not in arity or len(config.atoms) != arity[cv]:
        raise ValueError("Generated CV must be DISTANCE (2), ANGLE (3), or TORSION (4 atoms).")
    if len(set(config.atoms)) != len(config.atoms) or any(
            isinstance(i, bool) or not isinstance(i, Integral) or not 1 <= i <= len(atoms)
            for i in config.atoms):
        raise ValueError("PLUMED atoms must be unique one-based atom indices.")
    for name in ("sigma", "height_kj_mol", "biasfactor"):
        positive(name, getattr(config, name))
    for name in ("pace", "colvar_stride"):
        positive(name, getattr(config, name), integer=True)
    if config.biasfactor <= 1:
        raise ValueError("Well-tempered biasfactor must be greater than one.")
    temperature = md_config.temperature_K if config.temperature_K is None else config.temperature_K
    positive("metadynamics temperature_K", temperature)
    hills = output_path(config.hills_file, overwrite=md_config.overwrite)
    colvar = output_path(config.colvar_file, overwrite=md_config.overwrite)
    if hills == colvar:
        raise ValueError("HILLS and COLVAR must be different files.")
    if any(c.isspace() for c in str(hills) + str(colvar)):
        raise ValueError("Generated PLUMED output paths must not contain whitespace.")
    nopbc = " NOPBC" if not atoms.pbc.any() else ""
    if atoms.pbc.any() and not atoms.pbc.all():
        raise ValueError("PLUMED requires either full 3D PBC or a nonperiodic system.")
    lines = [f"{config.cv_label}: {cv} ATOMS={','.join(map(str, config.atoms))}{nopbc}"]
    columns = f"{config.cv_label},{config.metad_label}.bias"
    if config.wall_type is not None:
        if config.wall_type.upper() not in ("UPPER_WALLS", "LOWER_WALLS"):
            raise ValueError("wall_type must be UPPER_WALLS or LOWER_WALLS.")
        for name in ("wall_kappa", "wall_exp", "wall_eps"):
            positive(name, getattr(config, name))
        if not np.isfinite([config.wall_at, config.wall_offset]).all():
            raise ValueError("Wall location and offset must be finite.")
        lines.append(f"{config.wall_label}: {config.wall_type.upper()} ARG={wall_arg} AT={config.wall_at} "
                     f"KAPPA={config.wall_kappa} EXP={config.wall_exp} "
                     f"EPS={config.wall_eps} OFFSET={config.wall_offset}")
        columns += f",{config.wall_label}.bias"
    metad = (f"{config.metad_label}: METAD ARG={metad_arg} PACE={config.pace} HEIGHT={config.height_kj_mol} "
             f"SIGMA={config.sigma} BIASFACTOR={config.biasfactor} TEMP={temperature} FILE={hills}")
    grid_max, grid_bins = config.grid_max, config.grid_bins
    grid_supplied = grid_max is not None or grid_bins is not None
    supports_auto_grid = (cv == "DISTANCE" and metad_arg == config.cv_label
                          and atoms.pbc.all() and md_config.ensemble.upper() != "NPT")
    grid_auto = config.grid_auto
    if grid_auto is None:
        grid_auto = supports_auto_grid and not grid_supplied and config.calc_rct is not False
    calc_rct = config.calc_rct if config.calc_rct is not None else bool(grid_auto or grid_supplied)
    if grid_auto:
        if not supports_auto_grid:
            raise ValueError("grid_auto requires fixed-cell, fully periodic DISTANCE; "
                             "use explicit bounds for NPT or disable the grid.")
        if atoms.cell.rank != 3 or not np.isfinite(atoms.cell.array).all():
            raise ValueError("grid_auto requires a finite, full-rank cell.")
        positive("grid_spacing", config.grid_spacing)
        if not np.isfinite(config.grid_min) or config.grid_min > 0:
            raise ValueError("Automatic distance grid_min must be finite and <= 0.")
        corners = np.asarray(list(product((-0.5, 0.5), repeat=3))) @ atoms.cell.array
        bound = float(np.linalg.norm(corners, axis=1).max()) / 10
        upper = np.ceil((bound + max(5 * config.sigma, 0.1 * bound)) / 0.5) * 0.5
        grid_bins = int(np.ceil((upper - config.grid_min) / config.grid_spacing))
        grid_max = config.grid_min + grid_bins * config.grid_spacing
    if calc_rct or grid_max is not None or grid_bins is not None:
        if grid_max is None or grid_bins is None:
            raise ValueError("A grid requires both grid_max and grid_bins (or grid_auto=True).")
        positive("grid_bins", grid_bins, integer=True)
        if not np.isfinite([config.grid_min, grid_max]).all() or config.grid_min >= grid_max:
            raise ValueError("Require finite grid_min < grid_max.")
        metad += f" GRID_MIN={config.grid_min} GRID_MAX={grid_max} GRID_BIN={grid_bins}"
    if calc_rct:
        metad += " CALC_RCT"
        columns += f",{config.metad_label}.rbias,{config.metad_label}.rct"
    if config.colvar_arg is not None:
        selected = []
        for reference in config.colvar_arg.split(","):
            if not calc_rct and reference in (
                    f"{config.metad_label}.rbias", f"{config.metad_label}.rct"):
                continue
            label = reference.split(".", 1)[0]
            if config.wall_type is None and label == config.wall_label and label not in labels:
                continue
            if reference != "*" and label not in labels:
                raise ValueError(f"Unknown generated PRINT reference: {reference}.")
            selected.append(reference)
        if not selected:
            raise ValueError("PRINT requires at least one available column.")
        columns = ",".join(selected)
    lines.extend([metad, f"PRINT ARG={columns} STRIDE={config.colvar_stride} FILE={colvar}"])
    return lines


def _engine_input(lines, *, start_step, timestep_fs, restart):
    """Prepare initialization-only actions without changing checkpoint input.

    PLUMED skips hill deposition on its first METAD update. A paused initial
    frame must still perform that update, or a later eligible PACE step loses
    its hill. The temporary time gate only bypasses the pause at initialization.
    """
    from ._mlmd_metadynamics import parse_marker

    marker = parse_marker(lines)
    engine = [line for line in lines if not line.lstrip().startswith("#")]
    if marker is None:
        return engine, False
    positive("start_step", start_step, integer=True, zero=True)
    after_start_ps = (int(start_step) + 0.25) * float(timestep_fs) / 1000.0
    prepared = []
    for line in engine:
        if line == "UPDATE_IF ARG=nb_hit LESS_THAN=0.5":
            prepared.extend([
                "nb_runtime_time: TIME",
                "nb_runtime_gate: CUSTOM ARG=nb_hit,nb_runtime_time "
                f"FUNC=x*step(y-({after_start_ps:.17g})) PERIODIC=NO",
                "UPDATE_IF ARG=nb_runtime_gate LESS_THAN=0.5",
            ])
        elif line == "UPDATE_IF ARG=nb_hit END":
            prepared.append("UPDATE_IF ARG=nb_runtime_gate END")
        elif restart and line.startswith("PRINT "):
            # The checkpoint already includes this boundary's COLVAR record.
            prepared.append(f"{line} UPDATE_FROM={after_start_ps:.17g}")
        else:
            prepared.append(line)
    return prepared, True


class BiasedCalculator(Plumed):
    """Evaluate as often as ASE needs, but update the bias once per MD step.

    ASE's standard PLUMED wrapper discards virial and counts evaluations as
    steps. Here PLUMED receives the actual integration step, and its virial
    contributes to stress (dE/dstrain / volume), including during NPT.
    """

    implemented_properties = ["energy", "free_energy", "forces", "stress"]

    def __init__(self, calc, atoms, config, md_config, lines, *, restart=False, start_step=0):
        try:
            import plumed  # noqa: F401
        except ImportError as exc:
            raise ImportError("Metadynamics requires 'matmalib[metadynamics]' and the "
                              "native PLUMED kernel; see README installation instructions.") from exc
        self.md_step = 0
        self.updated_step = -1
        self.need_stress = md_config.ensemble.upper() == "NPT"
        engine_lines, initialize = _engine_input(
            lines, start_step=start_step, timestep_fs=md_config.timestep_fs, restart=restart)
        log = os.devnull if config.log_file is None else str(output_path(
            config.log_file, overwrite=md_config.overwrite))
        super().__init__(calc=calc, input=engine_lines, atoms=atoms,
                         timestep=md_config.timestep_fs * units.fs,
                         kT=md_config.temperature_K * units.kB, log=log, restart=restart)
        if initialize:
            self.md_step = start_step
            try:
                self.update_bias(atoms, checkpoint=True)
            except BaseException:
                self.close()
                raise

    def calculate(self, atoms=None, properties=None, system_changes=all_changes):
        Calculator.calculate(self, atoms, properties, system_changes)
        stress = self.calc.get_stress(self.atoms) if self.need_stress or "stress" in (properties or ()) else None
        energy = float(self.calc.get_potential_energy(self.atoms))
        forces = np.array(self.calc.get_forces(self.atoms), dtype=float, order="C", copy=True)
        if world.rank == 0:
            pl = self.plumed
            pl.cmd("setStep", self.md_step)
            # PLUMED also supports CVs that depend on the potential energy;
            # pass unbiased forces/virial, not zero arrays.
            if stress is not None:
                from ase.stress import voigt_6_to_full_3x3_stress
                stress = np.asarray(stress)
                full_stress = stress if stress.shape == (3, 3) else voigt_6_to_full_3x3_stress(stress)
                virial = np.ascontiguousarray(
                    full_stress * self.atoms.get_volume(), dtype=float)
            else:
                virial = np.zeros((3, 3))
            positions = np.asarray(self.atoms.positions, dtype=float).copy()
            masses = self.atoms.get_masses()
            box = None
            if self.atoms.pbc.all():
                box = self.atoms.cell.array.copy()
                pl.cmd("setBox", box)
            pl.cmd("setPositions", positions)
            pl.cmd("setEnergy", energy)
            pl.cmd("setMasses", masses)
            pl.cmd("setForces", forces)
            pl.cmd("setVirial", virial)
            pl.cmd("prepareCalc")
            pl.cmd("performCalcNoUpdate")
            bias = np.zeros(1)
            pl.cmd("getBias", bias)
            result = energy + float(bias[0]), forces, virial
            # PLUMED retains these pointers until update().
            self._buffers = box, positions, masses, forces, virial
        else:
            result = None
        total, forces, virial = broadcast(result)
        self.results = {"energy": total, "free_energy": total, "forces": forces}
        if stress is not None:
            self.results["stress"] = full_3x3_to_voigt_6_stress(virial / self.atoms.get_volume())

    def update_bias(self, atoms, *, checkpoint=False):
        if self.updated_step == self.md_step:
            return
        # Refresh PLUMED's current frame even if atoms did not move this step.
        # Do not invalidate cached forces solely for a time change before an
        # integrator reuses the previous step's final force.
        self.calculate(atoms, ["energy", "forces"])
        if world.rank == 0:
            if checkpoint:
                self.plumed.cmd("doCheckPoint", 1)
            self.plumed.cmd("update")
        self.updated_step = self.md_step

    def close(self):
        if world.rank == 0:
            self.plumed.finalize()
