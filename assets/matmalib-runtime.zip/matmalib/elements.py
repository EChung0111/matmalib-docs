"""Shared atomic-number and symbol dictionaries for elements 1–118.

Symbols follow the IUPAC periodic table:
https://iupac.org/what-we-do/periodic-table-of-elements/
"""

_SYMBOLS = (
    "H He "
    "Li Be B C N O F Ne "
    "Na Mg Al Si P S Cl Ar "
    "K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr "
    "Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe "
    "Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu "
    "Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn "
    "Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr "
    "Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og"
).split()

ELEMENT_SYMBOLS = {str(number): symbol for number, symbol in enumerate(_SYMBOLS, 1)}
ELEMENT_NUMBERS = {symbol: number for number, symbol in enumerate(_SYMBOLS, 1)}
