"""Sugar stereochemistry and torsions adapted from CarPpy's conformer analysis.

Backbone neighbor rules follow CarP/conformer.py at commit
4589b228cf8772b0f2bd6ccae8bb2f41ad1e7d70. Signed tetrahedral volumes replace
conformation-dependent dihedral tests; unsupported chemistry stays Unknown.
"""

import numpy as np

from ._geometry import dihedral


_HEXOSES = {
    (True, True, True): "All", (False, True, True): "Alt",
    (True, False, True): "Glc", (False, False, True): "Man",
    (True, True, False): "Gul", (False, True, False): "Ido",
    (True, False, False): "Gal", (False, False, False): "Tal",
}
_DEOXY = {"Glc": "Qui", "Man": "Rha", "Gal": "Fuc", "Alt": "6dAlt", "Gul": "6dGul", "Tal": "6dTal"}


def _orientation(xyz, center, neighbors):
    vectors = xyz[list(neighbors)] - xyz[center]
    lengths = np.linalg.norm(vectors, axis=1)
    if np.any(lengths == 0):
        return None
    volume = np.linalg.det(vectors / lengths[:, None])
    return None if abs(volume) < 1e-3 else int(np.sign(volume))


def identify_sugars(glycan):
    """Identify common aldohexopyranoses, their D/L form and alpha/beta anomer.

    Supports the eight hexose stereochemistries, C2 amino/N-acetyl variants,
    C6 deoxy variants, and uronic acids. Unsupported backbones, ambiguous
    substituents, and degenerate stereocenters retain name Unknown. This
    identifies base residues, not a complete inventory of protecting groups.
    """
    xyz = glycan.xyz
    elements = [atom.type for atom in glycan.atoms]
    graph = getattr(glycan, "graph", None)
    results = []
    for monomer in glycan.monomers:
        info = dict(name="Unknown", configuration=None, anomer=None, ring_type=monomer.ring_type)
        results.append(info)
        assignment = monomer.atom_assignment
        required = {"O", "C1", "C2", "C3", "C4", "C5", "C6"}
        if graph is None or len(monomer.ring_indices) != 6 or not required.issubset(assignment):
            continue
        if set(monomer.ring_indices) != {assignment[name] for name in ("O", "C1", "C2", "C3", "C4", "C5")}:
            continue
        ring = set(monomer.ring_indices)
        substituents = {}
        for position in (1, 2, 3, 4):
            choices = [i for i in graph[assignment[f"C{position}"]]
                       if i not in ring and elements[i] in ("O", "N")]
            if len(choices) == 1:
                substituents[position] = choices[0]
        if not {2, 3, 4}.issubset(substituents):
            continue
        if any(elements[substituents[position]] != "O" for position in (3, 4)):
            continue
        signs = [_orientation(xyz, assignment[f"C{n}"],
                             (assignment[f"C{n-1}"], assignment[f"C{n+1}"],
                              assignment["O"] if n == 5 else substituents[n]))
                 for n in range(2, 6)]
        if None in signs:
            continue
        info["configuration"] = "D" if signs[-1] < 0 else "L"
        if 1 in substituents:
            anomer = _orientation(xyz, assignment["C1"], (assignment["O"], assignment["C2"], substituents[1]))
            if anomer is not None:
                info["anomer"] = "beta" if anomer != signs[-1] else "alpha"
        base = _HEXOSES[tuple(sign == signs[-1] for sign in signs[:3])]
        terminal_neighbors = [i for i in graph[assignment["C6"]]
                              if i != assignment["C5"] and elements[i] != "H"]
        if not terminal_neighbors:
            base = _DEOXY.get(base)
        elif len(terminal_neighbors) == 2 and all(elements[i] == "O" for i in terminal_neighbors):
            base += "A"
        elif len(terminal_neighbors) != 1 or elements[terminal_neighbors[0]] != "O":
            continue
        if base is None:
            continue
        hetero = substituents[2]
        if elements[hetero] == "N":
            other = [i for i in graph[hetero] if i != assignment["C2"] and elements[i] != "H"]
            if not other:
                if base.endswith("A") or base in _DEOXY.values():
                    continue
                base += "N"
            elif len(other) == 1 and elements[other[0]] == "C":
                carbonyl = other[0]
                oxygens = [i for i in graph[carbonyl] if elements[i] == "O"]
                carbons = [i for i in graph[carbonyl] if elements[i] == "C"]
                if len(oxygens) != 1 or len(carbons) != 1 or base.endswith("A"):
                    continue
                methyl = carbons[0]
                if any(i != carbonyl and elements[i] != "H" for i in graph[methyl]):
                    continue
                if np.linalg.norm(xyz[oxygens[0]] - xyz[carbonyl]) >= 0.9 * np.linalg.norm(xyz[methyl] - xyz[carbonyl]):
                    continue
                base += "NAc"
            else:
                continue
        info["name"] = base
    return results


def linkage_positions(glycan, link):
    """Carbon-position labels for a detected glycosidic bond."""
    result = []
    for endpoint in ("donor", "acceptor"):
        assignment = glycan.monomers[link[endpoint]].atom_assignment
        label = next((name[1:] for name, atom in assignment.items()
                      if name.startswith("C") and atom == link[f"{endpoint}_atom"]), "?")
        result.append(label)
    return tuple(result)


def glycosidic_torsions(glycan, *, degrees=True):
    """Return phi/psi and exocyclic omega with their exact atom quadruplets.

    Phi: O_ring(donor)-C_anomeric-O_link-C_acceptor.
    Psi: C_anomeric-O_link-C_acceptor-C_previous (or acceptor ring O at C1).
    Omega for a terminal-carbon linkage: O_link-C_terminal-C_ring-O_ring.
    These are heavy-atom conventions; no periodic-boundary unwrapping occurs.
    """
    results = []
    for link in glycan.glycosidic_bonds:
        donor = glycan.monomers[link["donor"]]
        acceptor = glycan.monomers[link["acceptor"]]
        positions = linkage_positions(glycan, link)
        if "?" in positions or "O" not in donor.atom_assignment:
            raise ValueError("Torsions require named backbone atom assignments.")
        acceptor_position = int(positions[1])
        previous = acceptor.atom_assignment.get(f"C{acceptor_position - 1}")
        if link["acceptor_atom"] == acceptor.ring_indices[1]:
            previous = acceptor.atom_assignment["O"]
        if previous is None:
            raise ValueError("Cannot determine the acceptor backbone for this linkage.")
        phi = (donor.atom_assignment["O"], link["donor_atom"], link["bridge_atom"], link["acceptor_atom"])
        psi = (link["donor_atom"], link["bridge_atom"], link["acceptor_atom"], previous)
        atom_sets = {"phi": phi, "psi": psi}
        if link["acceptor_atom"] not in acceptor.ring_indices and previous == acceptor.ring_indices[-1]:
            atom_sets["omega"] = (link["bridge_atom"], link["acceptor_atom"], previous, acceptor.atom_assignment["O"])
        result = dict(link, donor_position=positions[0], acceptor_position=positions[1],
                      atom_indices=atom_sets, angle_unit="degrees" if degrees else "radians")
        result.update({name: float(dihedral(glycan.xyz[list(indices)], degrees=degrees))
                       for name, indices in atom_sets.items()})
        results.append(result)
    return results


def backbone_torsions(glycan, *, degrees=True):
    """Return hydroxymethyl omega (O_ring-C_ring-C_tail-O_tail) per monomer.

    A missing or ambiguous terminal oxygen gives omega=None, not an arbitrary
    choice. The terminal carbon is the carbon immediately after the last ring
    carbon, so the definition also applies to supported furanose backbones.
    """
    results = []
    for monomer in glycan.monomers:
        result = dict(monomer=monomer.id, omega=None, atom_indices=None,
                      angle_unit="degrees" if degrees else "radians")
        results.append(result)
        assignment = monomer.atom_assignment
        terminal = monomer.ring_indices[-1]
        name = next((name for name, atom in assignment.items() if atom == terminal and name.startswith("C")), None)
        if name is None or not hasattr(glycan, "graph"):
            continue
        tail = assignment.get(f"C{int(name[1:]) + 1}")
        if tail is None:
            continue
        oxygens = [i for i in glycan.graph[tail] if glycan.atoms[i].type == "O"]
        if len(oxygens) != 1:
            continue
        indices = (assignment["O"], terminal, tail, oxygens[0])
        result.update(omega=float(dihedral(glycan.xyz[list(indices)], degrees=degrees)), atom_indices=indices)
    return results
