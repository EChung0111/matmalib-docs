"""Connectivity-based sugar assignments adapted from CarPpy.

Source: EChung0111/CarPpy, CarP/conformer.py, commit
4589b228cf8772b0f2bd6ccae8bb2f41ad1e7d70: connectivity_matrix,
sort_ring_atoms, pyranose_basis, furanose_basis, and glycosidic_link_check.
See tests/data/README.md for source attribution and adaptation details.
"""

from itertools import combinations

import networkx as nx
import numpy as np
from scipy.spatial import cKDTree


def bond_graph(atoms, *, conn_mat=None, graph=None, distXX=1.65, distXH=1.15):
    """Copy supplied topology, or infer CarPpy distance-cutoff connectivity.

    Nodes are positions in the atom list. Hydrogens attach to their nearest
    heavy atom within distXH; H-H contacts never join molecular fragments.
    Default distances assume angstroms, as in CarPpy.
    """
    count = len(atoms)
    if conn_mat is not None:
        matrix = np.asarray(conn_mat)
        if (matrix.shape != (count, count) or not np.all(np.isfinite(matrix))
                or not np.array_equal(matrix, matrix.T) or np.any(np.diag(matrix))
                or np.any(matrix < 0)):
            raise ValueError("conn_mat must be a finite, symmetric, nonnegative atom connectivity matrix with a zero diagonal.")
        return nx.from_numpy_array(matrix != 0)
    if graph is not None:
        if (graph.is_directed() or graph.is_multigraph()
                or set(graph.nodes) != set(range(count)) or nx.number_of_selfloops(graph)):
            raise ValueError("graph must be an undirected atom graph with nodes 0 through n_atoms-1.")
        return graph.copy()
    if any(not np.isfinite(value) or value <= 0 for value in (distXX, distXH)):
        raise ValueError("Bond distance cutoffs must be finite and positive.")
    xyz = np.asarray([atom.coord for atom in atoms], dtype=float)
    if xyz.shape != (count, 3) or not count or not np.all(np.isfinite(xyz)):
        raise ValueError("Sugar detection requires finite (n_atoms, 3) coordinates.")
    elements = [atom.type for atom in atoms]
    graph = nx.Graph()
    graph.add_nodes_from(range(count))
    hydrogen_neighbors = {}
    for first, second in sorted(cKDTree(xyz).query_pairs(max(distXX, distXH))):
        distance = np.linalg.norm(xyz[first] - xyz[second])
        if distance == 0:
            raise ValueError("Overlapping atoms prevent bond inference; supply connectivity explicitly.")
        if elements[first] == elements[second] == "H":
            continue
        if "H" in (elements[first], elements[second]):
            if distance < distXH:
                hydrogen, heavy = (first, second) if elements[first] == "H" else (second, first)
                candidate = (distance, heavy)
                if candidate < hydrogen_neighbors.get(hydrogen, (np.inf, -1)):
                    hydrogen_neighbors[hydrogen] = candidate
        elif distance < distXX:
            graph.add_edge(first, second)
    graph.add_edges_from((hydrogen, heavy) for hydrogen, (_, heavy) in hydrogen_neighbors.items())
    return graph


def sugar_rings(graph, elements):
    """Find substituted C/O five- and six-membered rings and orient them.

    Like CarPpy, use a single ring oxygen and its neighbors to identify the
    anomeric end. Enumerate bounded carbon paths rather than relying on the
    arbitrary order of a cycle basis (important for protected sugars).
    """
    carbon_graph = graph.subgraph(i for i in graph if elements[i] == "C")
    rings = []
    seen = set()
    for oxygen in sorted(i for i in graph if elements[i] == "O"):
        neighbors = sorted(i for i in graph[oxygen] if elements[i] != "H")
        if len(neighbors) != 2 or any(elements[i] != "C" for i in neighbors):
            continue
        for first, last in combinations(neighbors, 2):
            for path in nx.all_simple_paths(carbon_graph, first, last, cutoff=4):
                if len(path) not in (4, 5):
                    continue
                members = frozenset([oxygen, *path])
                if members in seen:
                    continue
                seen.add(members)
                if graph.subgraph(members).number_of_edges() != len(members):
                    continue  # A chorded cycle has no unique cyclic atom order.
                substituents = {
                    carbon: [i for i in graph[carbon] if i not in members
                             and elements[i] in ("O", "N", "S")]
                    for carbon in path
                }
                # A bare cyclic ether is not a carbohydrate. This also avoids
                # treating phenyl protecting groups as sugar rings.
                if sum(bool(value) for value in substituents.values()) < 2:
                    continue
                anomeric = [i for i in neighbors if substituents[i]]
                if len(anomeric) != 1:
                    raise ValueError(
                        f"Ambiguous anomeric carbon in ring {sorted(members)}; "
                        "supply ordered rings and monomers explicitly."
                    )
                if path[0] != anomeric[0]:
                    path = list(reversed(path))
                rings.append((oxygen, *path))
    rings.sort(key=lambda ring: min(ring))
    if not rings:
        raise ValueError("No supported sugar rings found; check connectivity or supply ordered rings and monomers explicitly.")
    if len(set(i for ring in rings for i in ring)) != sum(map(len, rings)):
        raise ValueError("Overlapping sugar ring candidates; supply ordered rings and monomers explicitly.")
    return tuple(rings)


def ring_assignment(ring, graph, elements, all_ring_atoms):
    """Name ring/backbone atoms, using O plus CarPpy-style C1, C2, ... keys.

    Aldoses start at C1. An exocyclic carbon at the anomeric center identifies
    the C1 branch of a ketose, so its ring starts at C2. Follow the terminal
    carbon chain to include C6 (and longer unbranched ketose side chains).
    Explicit rings define the traversal direction, even when not O-first.
    """
    oxygens = [i for i in ring if elements[i] == "O"]
    if len(oxygens) != 1 or any(elements[i] not in ("C", "O") for i in ring):
        raise ValueError("Sugar atom assignment requires one ring oxygen and otherwise carbon atoms.")
    start = ring.index(oxygens[0])
    ordered = ring[start:] + ring[:start]
    if any(not graph.has_edge(a, b) for a, b in zip(ordered, ordered[1:] + ordered[:1])):
        raise ValueError("Ring atom order does not follow the supplied or inferred bonds.")
    anomeric = ordered[1]
    branches = [i for i in graph[anomeric] if i not in all_ring_atoms and elements[i] == "C"]
    if len(branches) > 1:
        raise ValueError("Ambiguous anomeric carbon branches; supply monomer assignments explicitly.")
    offset = 2 if branches else 1
    assignment = {"O": ordered[0]}
    assignment.update({f"C{i}": atom for i, atom in enumerate(ordered[1:], offset)})
    if branches:
        assignment["C1"] = branches[0]
    current = ordered[-1]
    number = offset + len(ordered) - 2
    visited = all_ring_atoms | set(branches)
    while True:
        tail = [i for i in graph[current] if i not in visited and elements[i] == "C"]
        if len(tail) != 1:
            break
        current = tail[0]
        visited = visited | {current}
        number += 1
        assignment[f"C{number}"] = current
    return assignment, anomeric


def monomer_memberships(graph, elements, rings, assignments, anomeric_atoms):
    """Separate monomers at glycosidic donor-carbon/heteroatom bonds.

    The linking heteroatom belongs to the acceptor. For an anomeric-to-
    anomeric linkage the lower monomer index is treated as donor, keeping
    membership deterministic and disjoint. Other attached substituents stay
    with the connected monomer; disconnected solvent remains unassigned.
    """
    carbon_owner = {}
    for index, assignment in enumerate(assignments):
        for label, atom in assignment.items():
            if label.startswith("C"):
                if atom in carbon_owner:
                    raise ValueError("Sugar carbon assignments overlap; supply monomers explicitly.")
                carbon_owner[atom] = index
    separated = graph.copy()
    links = []
    bridges = set()
    for donor, anomeric in enumerate(anomeric_atoms):
        for bridge in sorted(graph[anomeric]):
            if elements[bridge] not in ("O", "N", "S") or bridge in rings[donor]:
                continue
            for carbon in sorted(graph[bridge]):
                acceptor = carbon_owner.get(carbon)
                if acceptor is None or acceptor == donor:
                    continue
                key = (bridge, min(anomeric, carbon), max(anomeric, carbon))
                if key in bridges:
                    continue
                bridges.add(key)
                separated.remove_edge(anomeric, bridge)
                links.append(dict(donor=donor, acceptor=acceptor, donor_atom=anomeric,
                                  acceptor_atom=carbon, bridge_atom=bridge))
    memberships = [None] * len(rings)
    ring_owner = {atom: index for index, ring in enumerate(rings) for atom in ring}
    for component in nx.connected_components(separated):
        owners = {ring_owner[i] for i in component if i in ring_owner}
        if len(owners) > 1:
            raise ValueError("Cannot separate monomers at glycosidic bonds; supply monomers explicitly.")
        if owners:
            memberships[owners.pop()] = tuple(sorted(component))
    return tuple(memberships), links


def assign_sugars(atoms, *, rings=None, conn_mat=None, graph=None, distXX=1.65, distXH=1.15):
    """Return ordered rings, memberships, names, atom graph, and link records."""
    graph = bond_graph(atoms, conn_mat=conn_mat, graph=graph, distXX=distXX, distXH=distXH)
    elements = [atom.type for atom in atoms]
    if rings is None:
        rings = sugar_rings(graph, elements)
    all_ring_atoms = {atom for ring in rings for atom in ring}
    assignments, anomeric_atoms = zip(*(
        ring_assignment(ring, graph, elements, all_ring_atoms) for ring in rings
    ))
    memberships, links = monomer_memberships(graph, elements, rings, assignments, anomeric_atoms)
    return rings, memberships, assignments, graph, links
