"""Two-CV free energies from PLUMED's normalized metadynamics bias.

Coordinates are DISTANCE in nm or ANGLE/TORSION in radians. ``metad.rbias``
must be in kJ/mol, PLUMED's default energy unit; the ASE adapter converts MD units.
The estimator follows PLUMED's normalized-bias reweighting convention:
https://www.plumed.org/doc-v2.10/user-doc/html/_r_e_w_e_i_g_h_t__m_e_t_a_d.html

Single-CV profiles remain available through ``mlmd.analyze_metadynamics``.
"""

from collections.abc import Mapping, Sequence
from dataclasses import asdict, is_dataclass
import json
from numbers import Integral
from os import PathLike
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any

import numpy as np

R_KJ_MOL_K = 0.00831446261815324


def read_colvar(path):
    """Read a PLUMED COLVAR table while enforcing a consistent FIELDS header."""
    from ._mlmd_analysis_core import read_plumed

    table = read_plumed(path)
    return {name: table.column(name) for name in table.fields}


def _cv_metadata(cv_specs):
    if not isinstance(cv_specs, Sequence) or isinstance(cv_specs, (str, bytes)) or len(cv_specs) != 2:
        raise ValueError("Two ordered CV specifications are required")
    metadata = []
    for original in cv_specs:
        if is_dataclass(original) and not isinstance(original, type):
            original = asdict(original)
        if not isinstance(original, Mapping):
            raise TypeError("Each CV specification must be a mapping or CVConfig")
        label = original.get("label")
        kind = str(original.get("type", "")).upper()
        if not isinstance(label, str) or not label or kind not in {"DISTANCE", "ANGLE", "TORSION"}:
            raise ValueError("Each CV needs a label and DISTANCE, ANGLE, or TORSION type")
        unit = "nm" if kind == "DISTANCE" else "rad"
        source_unit = original.get("unit")
        allowed_units = (None, "nm", "angstrom", "A", "Å") if kind == "DISTANCE" else (None, "rad")
        if source_unit not in allowed_units:
            raise ValueError(f"{label} must use nm/angstrom for distance or rad for angles")
        divisor = 10.0 if source_unit in ("angstrom", "A", "Å") else 1.0
        metadata.append(dict(label=label, type=kind, unit=unit,
                             **{name: None if original.get(name) is None else float(original[name]) / divisor
                                for name in ("grid_min", "grid_max")}))
    if metadata[0]["label"] == metadata[1]["label"]:
        raise ValueError("CV labels must be distinct")
    return metadata


def _grid(metadata, coordinates, bins, ranges: Sequence[Sequence[float] | None] | None):
    if isinstance(bins, Integral) and not isinstance(bins, bool):
        bins = (int(bins), int(bins))
    if not isinstance(bins, Sequence) or len(bins) != 2 or any(
            isinstance(value, bool) or not isinstance(value, Integral) or value <= 0 for value in bins):
        raise ValueError("bins must be a positive integer or two positive integers")
    ranges = (None, None) if ranges is None else ranges
    if not isinstance(ranges, Sequence) or len(ranges) != 2:
        raise ValueError("ranges must contain two bounds pairs or None values")
    edges = []
    for index, (spec, requested) in enumerate(zip(metadata, ranges)):
        if spec["type"] == "TORSION":
            if requested is not None and not np.allclose(requested, [-np.pi, np.pi], rtol=0, atol=1e-12):
                raise ValueError("TORSION free energies require the complete periodic range [-pi, pi]")
            bounds = (-np.pi, np.pi)
        elif requested is not None:
            bounds = requested
        elif spec["grid_min"] is not None and spec["grid_max"] is not None:
            bounds = (spec["grid_min"], spec["grid_max"])
        else:
            low, high = float(coordinates[:, index].min()), float(coordinates[:, index].max())
            if low == high:
                padding = max(abs(low) * 0.01, 0.001)
                low, high = max(0.0, low - padding), high + padding
                if spec["type"] == "ANGLE":
                    high = min(np.pi, high)
            bounds = (low, high)
        if not isinstance(bounds, Sequence) or len(bounds) != 2:
            raise ValueError(f"{spec['label']} needs a pair of range limits")
        lower, upper = map(float, bounds)
        if not np.isfinite([lower, upper]).all() or lower >= upper:
            raise ValueError(f"Invalid FES range for {spec['label']}")
        if spec["type"] == "DISTANCE" and lower < 0:
            raise ValueError("DISTANCE ranges cannot be negative")
        if spec["type"] == "ANGLE" and (lower < 0 or upper > np.pi):
            raise ValueError("ANGLE ranges must lie within [0, pi]")
        edges.append(np.linspace(lower, upper, int(bins[index]) + 1))
    return tuple(edges)


def _relative_weights(rbias, beta):
    if not len(rbias):
        return np.empty(0), None
    maximum = float(np.max(rbias))
    # Finite extreme values can overflow their subtraction towards -inf. Those
    # weights correctly underflow to zero; the maximum always retains weight 1.
    with np.errstate(over="ignore", under="ignore", invalid="raise"):
        weights = np.exp((rbias - maximum) * beta)
    return weights, maximum


def _ess(weights):
    if not len(weights):
        return 0.0
    return float(weights.sum() ** 2 / np.dot(weights, weights))


def _free_energy(density, thermal_energy):
    result = np.full(density.shape, np.inf, dtype=float)
    positive = density > 0
    if positive.any():
        result[positive] = -thermal_energy * np.log(density[positive])
        result[positive] -= result[positive].min()
    return result


def _surface(coordinates, rbias, edges, beta, thermal_energy) -> dict[str, Any]:
    in_grid = np.ones(len(coordinates), dtype=bool)
    for index, edge in enumerate(edges):
        in_grid &= (coordinates[:, index] >= edge[0]) & (coordinates[:, index] <= edge[-1])
    all_weights, _ = _relative_weights(rbias, beta)
    weights, reference = _relative_weights(rbias[in_grid], beta)
    selected = coordinates[in_grid]
    counts = np.histogram2d(selected[:, 0], selected[:, 1], bins=edges)[0].astype(np.int64)
    weighted_counts = np.histogram2d(selected[:, 0], selected[:, 1], bins=edges, weights=weights)[0]
    total = float(weighted_counts.sum())
    probability = weighted_counts / total if total > 0 else np.zeros_like(weighted_counts)
    widths = tuple(np.diff(edge) for edge in edges)
    density = probability / (widths[0][:, None] * widths[1][None, :])
    marginals = []
    for index in range(2):
        marginal_probability = probability.sum(axis=1 - index)
        marginal_density = marginal_probability / widths[index]
        marginals.append(dict(probability=marginal_probability, density=marginal_density,
                              free_energy=_free_energy(marginal_density, thermal_energy)))
    diagnostics = dict(
        samples=int(len(coordinates)), samples_in_grid=int(in_grid.sum()),
        samples_outside_grid=int((~in_grid).sum()),
        outside_weight_fraction=(float(all_weights[~in_grid].sum() / all_weights.sum())
                                 if len(all_weights) else 0.0),
        weight_ESS_all=_ess(all_weights), weight_ESS_in_grid=_ess(weights),
        occupied_bins=int(np.count_nonzero(counts)), empty_bins=int(np.count_nonzero(counts == 0)),
        zero_weight_bins=int(np.count_nonzero(weighted_counts == 0)),
        relative_weight_reference_kj_mol=reference,
    )
    return dict(counts=counts, weighted_counts=weighted_counts, probability=probability,
                density=density, free_energy=_free_energy(density, thermal_energy),
                marginals=tuple(marginals), diagnostics=diagnostics)


def analyze_two_cv(colvar, cv_specs, *, temperature_K, bins=(80, 80),
                   ranges: Sequence[Sequence[float] | None] | None = None,
                   start_ps=0.0, time_column="time", bias_column="metad.rbias",
                   energy_unit="kJ/mol", window_ends_ps=None, output_dir=None,
                   overwrite=False):
    """Estimate a normalized-bias reweighted 2D density, FES and 1D marginals.

    ``colvar`` is a mapping of named one-dimensional arrays, or a COLVAR path.
    ``cv_specs`` is an ordered pair of CVConfig objects or mappings. All outputs
    use fixed bins, including cumulative time windows. Probability is conditional
    on the specified grid; out-of-grid samples and weight fraction are reported.
    Empty bins have infinite free energy, with no smoothing or pseudocounts.
    CV values use nm/rad, time uses ps, and the normalized input bias uses kJ/mol.
    Without explicit bounds, nonperiodic ranges follow the selected observations;
    torsions always retain their complete periodic domain. Raw bias alone cannot
    replace the normalized bias required by this estimator.
    Existing output files require ``overwrite=True``; input files are protected.
    """
    source_colvar = None
    if isinstance(colvar, (str, PathLike)):
        source_colvar = str(Path(colvar).expanduser().resolve())
        colvar = read_colvar(source_colvar)
    if not isinstance(colvar, Mapping):
        raise TypeError("colvar must be a column mapping or COLVAR path")
    metadata = _cv_metadata(cv_specs)
    if not np.isfinite(temperature_K) or temperature_K <= 0:
        raise ValueError("temperature_K must be finite and positive")
    if not np.isfinite(start_ps):
        raise ValueError("start_ps must be finite")
    if energy_unit not in {"kJ/mol", "kcal/mol"}:
        raise ValueError("energy_unit must be kJ/mol or kcal/mol")
    names = [time_column, bias_column, *(spec["label"] for spec in metadata)]
    missing = [name for name in names if name not in colvar]
    if missing:
        raise ValueError(f"Missing COLVAR columns: {missing}; normalized metad.rbias is required")
    arrays = [np.asarray(colvar[name], dtype=float) for name in names]
    if any(array.ndim != 1 for array in arrays) or len({len(array) for array in arrays}) != 1:
        raise ValueError("COLVAR columns must be equally sized one-dimensional arrays")
    times = arrays[0]
    if not len(times) or not np.isfinite(times).all() or np.any(np.diff(times) <= 0):
        raise ValueError("COLVAR times must be finite and strictly increasing")
    keep = times >= float(start_ps)
    if not keep.any():
        raise ValueError("No COLVAR samples remain after start_ps")
    times = times[keep]
    rbias = arrays[1][keep]
    coordinates = np.column_stack([array[keep] for array in arrays[2:]])
    if not np.isfinite(rbias).all() or not np.isfinite(coordinates).all():
        raise ValueError("Selected CVs and normalized biases must be finite")
    boundary_rounding = {}
    for index, spec in enumerate(metadata):
        values = coordinates[:, index]
        if spec["type"] == "TORSION":
            coordinates[:, index] = (values + np.pi) % (2 * np.pi) - np.pi
        elif spec["type"] == "ANGLE":
            # PLUMED's default six-decimal printing can round pi slightly upward.
            if np.any(values < -5e-7) or np.any(values > np.pi + 5e-7):
                raise ValueError(f"ANGLE {spec['label']} contains values outside [0, pi]")
            boundary_rounding[spec["label"]] = int(np.count_nonzero((values < 0) | (values > np.pi)))
            coordinates[:, index] = np.clip(values, 0, np.pi)
        elif np.any(values < 0):
            raise ValueError(f"DISTANCE {spec['label']} contains negative values")
    edges = _grid(metadata, coordinates, bins, ranges)
    beta = 1.0 / (R_KJ_MOL_K * float(temperature_K))
    thermal_energy = R_KJ_MOL_K * float(temperature_K) / (4.184 if energy_unit == "kcal/mol" else 1.0)
    result = _surface(coordinates, rbias, edges, beta, thermal_energy)
    if result["diagnostics"]["samples_in_grid"] == 0:
        raise ValueError("No selected samples lie inside the requested FES grid")
    result.update(cv_specs=metadata, edges=edges,
                  centers=tuple((edge[:-1] + edge[1:]) / 2 for edge in edges),
                  temperature_K=float(temperature_K), energy_unit=energy_unit,
                  bias_column=bias_column, bias_unit="kJ/mol", time_column=time_column,
                  source_colvar=source_colvar,
                  start_ps=float(start_ps), time_range_ps=[float(times[0]), float(times[-1])],
                  boundary_rounding_corrections=boundary_rounding,
                  notes=["Probability is normalized within the requested grid.",
                         "Weight ESS does not account for time correlation and is not a convergence test.",
                         "No radial Jacobian or standard-state correction is applied.",
                         "Empty or underflowed bins retain infinite free energy."])
    if window_ends_ps is None:
        ends = np.linspace(times[0], times[-1], 5)[1:] if len(times) > 1 else times.copy()
    else:
        ends = np.asarray(window_ends_ps, dtype=float)
        if ends.ndim != 1 or not len(ends) or not np.isfinite(ends).all() or np.any(np.diff(ends) <= 0):
            raise ValueError("window_ends_ps must be a finite, increasing sequence")
        if ends[0] < times[0] or ends[-1] > times[-1]:
            raise ValueError("Cumulative window ends must lie in the selected time range")
    windows = []
    for end in np.unique(ends):
        mask = times <= end
        window = _surface(coordinates[mask], rbias[mask], edges, beta, thermal_energy)
        window.update(end_ps=float(end), edges=edges)
        windows.append(window)
    result["windows"] = windows
    if output_dir is not None:
        result["artifacts"] = save_two_cv(result, output_dir, overwrite=overwrite)
    return result


def _plot_scale(spec, distance_unit):
    if distance_unit not in ("nm", "angstrom"):
        raise ValueError("distance_unit must be 'nm' or 'angstrom'")
    return 10.0 if spec["type"] == "DISTANCE" and distance_unit == "angstrom" else 1.0


def _axis_label(spec, distance_unit="nm"):
    unit = "Å" if _plot_scale(spec, distance_unit) == 10 else spec["unit"]
    return f"{spec['label']} ({unit})"


def plot_two_cv(result, *, vmax=None, distance_unit="nm"):
    """Plot FES and marginals; distance_unit changes display coordinates only."""
    import matplotlib.pyplot as plt

    scales = [_plot_scale(spec, distance_unit) for spec in result["cv_specs"]]
    figure = plt.figure(figsize=(10, 8), layout="constrained")
    grid = figure.add_gridspec(2, 3, height_ratios=(1, 4), width_ratios=(4, 1, 0.16))
    main = figure.add_subplot(grid[1, 0])
    top = figure.add_subplot(grid[0, 0], sharex=main)
    right = figure.add_subplot(grid[1, 1], sharey=main)
    info = figure.add_subplot(grid[0, 1:])
    info.axis("off")
    color_axis = figure.add_subplot(grid[1, 2])
    x, y = (values * scale for values, scale in zip(result["edges"], scales))
    surface = np.ma.masked_invalid(result["free_energy"].T)
    image = main.pcolormesh(x, y, surface, shading="flat", cmap="viridis", vmin=0, vmax=vmax)
    energy_label = f"ΔF ({result['energy_unit']})"
    figure.colorbar(image, cax=color_axis, label=energy_label)
    main.set(xlabel=_axis_label(result["cv_specs"][0], distance_unit),
             ylabel=_axis_label(result["cv_specs"][1], distance_unit),
             xlim=(x[0], x[-1]), ylim=(y[0], y[-1]))
    top.plot(result["centers"][0] * scales[0],
             np.ma.masked_invalid(result["marginals"][0]["free_energy"]), color="#006d77")
    right.plot(np.ma.masked_invalid(result["marginals"][1]["free_energy"]),
               result["centers"][1] * scales[1], color="#006d77")
    top.set_ylabel(energy_label)
    right.set_xlabel(energy_label)
    top.tick_params(labelbottom=False)
    right.tick_params(labelleft=False)
    top.grid(alpha=0.2)
    right.grid(alpha=0.2)
    diagnostics = result["diagnostics"]
    info.text(0, 0.95, f"Frames: {diagnostics['samples']:,}\n"
              f"Weight ESS: {diagnostics['weight_ESS_in_grid']:,.0f}\n"
              f"Empty bins: {diagnostics['empty_bins']:,}\n"
              f"Outside grid: {diagnostics['samples_outside_grid']:,}", va="top", fontsize=10)
    figure.suptitle("Normalized-bias reweighted free energy and marginals")
    return figure


def plot_two_cv_windows(result, *, vmax=None, distance_unit="nm"):
    """Compare windows on common edges, optionally displaying distances in Å."""
    import matplotlib.pyplot as plt
    from matplotlib.colors import Normalize

    scales = [_plot_scale(spec, distance_unit) for spec in result["cv_specs"]]
    edges = tuple(values * scale for values, scale in zip(result["edges"], scales))
    windows = result["windows"]
    if not windows:
        raise ValueError("No cumulative windows are available")
    columns = min(2, len(windows))
    rows = (len(windows) + columns - 1) // columns
    figure, axes = plt.subplots(rows, columns, figsize=(6 * columns, 4.7 * rows),
                                squeeze=False, layout="constrained")
    finite = [window["free_energy"][np.isfinite(window["free_energy"])] for window in windows]
    maximum = max((float(values.max()) for values in finite if len(values)), default=1.0)
    normalizer = Normalize(vmin=0, vmax=vmax if vmax is not None else max(maximum, 1e-12))
    images = []
    used_axes = []
    for axis, window in zip(axes.flat, windows):
        image = axis.pcolormesh(*edges, np.ma.masked_invalid(window["free_energy"].T),
                               shading="flat", cmap="viridis", norm=normalizer)
        images.append(image)
        axis.set(xlabel=_axis_label(result["cv_specs"][0], distance_unit),
                 ylabel=_axis_label(result["cv_specs"][1], distance_unit),
                 title=f"Through {window['end_ps']:g} ps · {window['diagnostics']['samples']:,} frames")
        used_axes.append(axis)
    for axis in list(axes.flat)[len(windows):]:
        axis.axis("off")
    figure.colorbar(images[-1], ax=used_axes, label=f"ΔF ({result['energy_unit']})")
    figure.suptitle("Cumulative sampling windows — shared grid")
    return figure


def _prepare_outputs(output_dir, names, *, sources=(), overwrite=False):
    """Resolve artifact paths and protect source files before staging output."""
    directory = Path(output_dir).expanduser().resolve()
    inputs = [Path(path).expanduser().resolve() for path in sources if path is not None]
    artifacts = {key: directory / name for key, name in names.items()}
    for path in artifacts.values():
        if any(path.resolve() == source or (path.exists() and source.exists() and path.samefile(source))
               for source in inputs):
            raise ValueError("Analysis output would overwrite an input file")
        if path.is_dir():
            raise ValueError(f"Cannot replace analysis file: {path} is a directory")
        if not overwrite and (path.exists() or path.is_symlink()):
            raise FileExistsError(path)
    return directory, artifacts


def save_two_cv(result, output_dir, *, overwrite=False):
    """Stage the grid, profiles and figures before publishing protected outputs."""
    names = {"grid": "two_cv_fes.npz", "table": "two_cv_fes.csv", "summary": "two_cv_summary.json",
             "plot": "two_cv_fes.png", "windows_plot": "two_cv_windows.png"}
    directory, artifacts = _prepare_outputs(
        output_dir, names, sources=(result.get("source_colvar"),), overwrite=overwrite)
    directory.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".metad-2d-", dir=directory) as temporary:
        staged = {key: Path(temporary) / name for key, name in names.items()}
        _write_two_cv_artifacts(result, staged)
        for key, source in staged.items():
            if overwrite:
                source.replace(artifacts[key])
            else:
                artifacts[key].hardlink_to(source)
    return {key: str(path) for key, path in artifacts.items()}


def _write_two_cv_artifacts(result, artifacts):
    import matplotlib.pyplot as plt

    arrays = {key: result[key] for key in ("counts", "weighted_counts", "probability", "density", "free_energy")}
    for index in range(2):
        arrays[f"edges_{index}"] = result["edges"][index]
        arrays[f"centers_{index}"] = result["centers"][index]
        arrays.update({f"marginal_{index}_{key}": value for key, value in result["marginals"][index].items()})
    for index, window in enumerate(result["windows"]):
        arrays[f"window_{index}_end_ps"] = np.array(window["end_ps"])
        arrays[f"window_{index}_free_energy"] = window["free_energy"]
        arrays[f"window_{index}_probability"] = window["probability"]
    np.savez_compressed(artifacts["grid"], **arrays)
    xx, yy = np.meshgrid(*result["centers"], indexing="ij")
    np.savetxt(artifacts["table"], np.column_stack([xx.ravel(), yy.ravel(), result["free_energy"].ravel(),
        result["probability"].ravel(), result["density"].ravel(), result["counts"].ravel()]), delimiter=",",
        header=f"{result['cv_specs'][0]['label']},{result['cv_specs'][1]['label']},free_energy,probability,density,count",
        comments="")
    summary = {key: result[key] for key in ("cv_specs", "temperature_K", "energy_unit", "bias_column", "bias_unit",
        "time_column", "start_ps", "time_range_ps", "boundary_rounding_corrections", "notes", "diagnostics")}
    summary["source_colvar"] = result.get("source_colvar")
    summary.update(edges=[edge.tolist() for edge in result["edges"]],
                   windows=[dict(end_ps=window["end_ps"], **window["diagnostics"]) for window in result["windows"]],
                   free_energy_definition="-RT ln(probability density), minimum shifted to zero",
                   artifacts={key: path.name for key, path in artifacts.items()})
    with artifacts["summary"].open("x") as stream:
        json.dump(summary, stream, indent=2, allow_nan=False)
        stream.write("\n")
    for key, plotter in (("plot", plot_two_cv), ("windows_plot", plot_two_cv_windows)):
        figure = plotter(result)
        try:
            figure.savefig(artifacts[key], dpi=180, bbox_inches="tight")
        finally:
            plt.close(figure)
