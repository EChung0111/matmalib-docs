"""Geometry primitives shared by carbohydrate analysis."""

import numpy as np


def dihedral(coordinates, *, degrees=True):
    """Signed torsion for (..., 4, 3) coordinates, in [-180, 180] degrees."""
    xyz = np.asarray(coordinates, dtype=float)
    if xyz.shape[-2:] != (4, 3) or not np.all(np.isfinite(xyz)):
        raise ValueError("Dihedral coordinates must have shape (..., 4, 3) and be finite.")
    axis = xyz[..., 2, :] - xyz[..., 1, :]
    length = np.linalg.norm(axis, axis=-1, keepdims=True)
    if np.any(length == 0):
        raise ValueError("A dihedral is undefined for coincident central atoms.")
    axis = axis / length
    first = xyz[..., 0, :] - xyz[..., 1, :]
    last = xyz[..., 3, :] - xyz[..., 2, :]
    first = first - np.sum(first * axis, axis=-1, keepdims=True) * axis
    last = last - np.sum(last * axis, axis=-1, keepdims=True) * axis
    if np.any(np.linalg.norm(first, axis=-1) <= 1e-12 * length[..., 0]) or np.any(
        np.linalg.norm(last, axis=-1) <= 1e-12 * length[..., 0]
    ):
        raise ValueError("A dihedral is undefined for collinear atoms.")
    angle = np.arctan2(np.sum(np.cross(axis, first) * last, axis=-1),
                       np.sum(first * last, axis=-1))
    return np.degrees(angle) if degrees else angle
