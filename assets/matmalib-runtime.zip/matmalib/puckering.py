"""Cremer–Pople coordinates for ordered five- and six-membered rings."""

import numpy as np

from ._geometry import dihedral
from ._pucker_reference import CARPPY_PUCKERS

__all__ = ["cremer_pople", "ring_dihedrals", "classify_ring_pucker"]


def cremer_pople(coordinates, *, degrees=True):
    """Calculate ring puckering for one geometry or a batch of geometries.

    ``coordinates`` has shape ``(..., ring_size, 3)`` with atoms in cyclic
    order. All rings in a batch must have the same size (five or six).
    Coordinates must describe whole, unwrapped rings. Amplitudes retain the
    input length unit; angles are degrees by default, or radians when
    ``degrees=False``.

    The returned dictionary contains ``Q``, ``q2``, and ``phi``. Six-membered
    rings also have the signed amplitude ``q3`` and polar angle ``theta``.
    ``phi`` lies in [0, 360) and ``theta`` in [0, 180] (or [0, 2*pi) and
    [0, pi]). Undefined angles are NaN: phi for planar rings and pure chairs,
    and theta for planar rings. A degenerate mean plane raises ValueError.

    Uses the original Cremer–Pople convention (JACS 97, 1354–1358, 1975,
    https://doi.org/10.1021/ja00839a011): the mean-plane normal is R' x R'',
    with sine-weighted R' and cosine-weighted R''. The phase is defined by
    q2*cos(phi) = sqrt(2/N)*sum(z*cos(4*pi*j/N)) and
    q2*sin(phi) = -sqrt(2/N)*sum(z*sin(4*pi*j/N)), for j starting at zero.
    Changing the starting atom or traversal direction changes the angles.
    """
    xyz = np.asarray(coordinates, dtype=float)
    if xyz.ndim < 2 or xyz.shape[-1] != 3 or xyz.shape[-2] not in (5, 6):
        raise ValueError("Expected coordinates with shape (..., 5 or 6, 3).")
    if not np.all(np.isfinite(xyz)):
        raise ValueError("Ring coordinates must be finite.")

    size = xyz.shape[-2]
    centered = xyz - xyz.mean(axis=-2, keepdims=True)
    phase = 2 * np.pi * np.arange(size) / size
    sine_vector = np.einsum("...ij,i->...j", centered, np.sin(phase))
    cosine_vector = np.einsum("...ij,i->...j", centered, np.cos(phase))
    normal = np.cross(sine_vector, cosine_vector)
    normal_length = np.linalg.norm(normal, axis=-1)
    scale = np.sum(centered**2, axis=(-2, -1))
    tolerance = 64 * np.finfo(float).eps
    if np.any(normal_length <= tolerance * scale):
        raise ValueError("Ring geometry has a degenerate Cremer–Pople mean plane.")
    normal = normal / normal_length[..., None]
    heights = np.einsum("...ij,...j->...i", centered, normal)

    cosine_mode = np.sqrt(2 / size) * np.einsum(
        "...i,i->...", heights, np.cos(2 * phase)
    )
    sine_mode = -np.sqrt(2 / size) * np.einsum(
        "...i,i->...", heights, np.sin(2 * phase)
    )
    q2 = np.hypot(cosine_mode, sine_mode)
    amplitude_tolerance = tolerance * np.sqrt(scale)
    phi = np.mod(np.arctan2(sine_mode, cosine_mode), 2 * np.pi)
    # Modulo can round a small negative angle up to exactly 2*pi.
    phi = np.where(phi >= 2 * np.pi, 0.0, phi)
    phi = np.where(q2 <= amplitude_tolerance, np.nan, phi)
    result = {"Q": q2, "q2": q2, "phi": np.degrees(phi) if degrees else phi}

    if size == 6:
        q3 = np.einsum("...i,i->...", heights, (-1.0) ** np.arange(size)) / np.sqrt(size)
        amplitude = np.hypot(q2, q3)
        theta = np.where(
            amplitude <= amplitude_tolerance, np.nan, np.arctan2(q2, q3)
        )
        result.update(Q=amplitude, q3=q3, theta=np.degrees(theta) if degrees else theta)

    return result


def ring_dihedrals(coordinates):
    """CarPpy's three ring-puckering angles, in degrees (not CP theta).

    Input shape is (..., 6, 3), in O, C1, C2, C3, C4, C5 order. These are
    the transformed diagonal dihedrals used by CarPpy's ring_canon routine.
    """
    xyz = np.asarray(coordinates, dtype=float)
    if xyz.shape[-2:] != (6, 3):
        raise ValueError("CarPpy ring dihedrals require ordered six-membered rings.")
    indices = np.array([[5, 3, 1, 2], [1, 5, 3, 4], [3, 1, 5, 0]])
    angles = dihedral(xyz[..., indices, :])
    return np.sign(angles) * (180 - np.abs(angles))


def classify_ring_pucker(coordinates, *, degrees=True, planar_tolerance=1e-6, max_distance=None):
    """Return CP coordinates plus a nearest canonical pucker and its distance.

    Six-membered rings use CarPpy's 38 canonical three-angle references; names
    use C1–C5 and 6 for O, with O first in the input. ``carppy_theta`` is the
    measured three-angle vector and ``distance`` is its Euclidean distance
    from the reference, in degrees. It is distinct from the CP polar theta.

    Five-membered rings use 20 ideal envelope/twist phases with indices 0–4
    in input order. ``0E`` raises atom 0; ``0T1`` raises 0 and lowers 1 relative
    to the CP normal. Distance is the wrapped phase difference in degrees.
    Angles in the returned CP coordinates follow ``degrees``.

    ``planar_tolerance`` uses the coordinate length unit. Planar rings are
    labelled planar. ``max_distance`` can reject a remote nearest reference
    with label unassigned; nearest_label still records the nearest candidate.
    These assignments describe proximity to ideal conformations, not exact
    conformational identities.
    """
    xyz = np.asarray(coordinates, dtype=float)
    if xyz.shape not in ((5, 3), (6, 3)):
        raise ValueError("Pucker classification requires one five- or six-membered ring.")
    if not np.isfinite(planar_tolerance) or planar_tolerance < 0:
        raise ValueError("planar_tolerance must be finite and nonnegative.")
    if max_distance is not None and (not np.isfinite(max_distance) or max_distance < 0):
        raise ValueError("max_distance must be finite and nonnegative.")
    result = cremer_pople(xyz, degrees=degrees)
    if result["Q"] <= planar_tolerance:
        return dict(result, label="planar", nearest_label=None, family="planar", distance=np.nan)
    if len(xyz) == 6:
        measured = ring_dihedrals(xyz)
        labels = list(CARPPY_PUCKERS)
        distances = np.linalg.norm(np.asarray(list(CARPPY_PUCKERS.values())) - measured, axis=1)
        best = int(np.argmin(distances))
        label = labels[best]
        family = next(name for code, name in (("C", "chair"), ("B", "boat"),
                      ("S", "skew"), ("H", "half-chair"), ("E", "envelope")) if code in label)
        result["carppy_theta"] = measured
        result["method"] = "carppy-three-angle"
    else:
        phase = float(result["phi"] if degrees else np.degrees(result["phi"]))
        angular = 4 * np.pi * np.arange(5) / 5
        labels, phases, families = [], [], []
        for index in range(5):
            for sign in (1, -1):
                height = np.zeros(5)
                height[index] = sign
                labels.append(f"{index}E" if sign == 1 else f"E{index}")
                phases.append(np.degrees(np.arctan2(-height @ np.sin(angular), height @ np.cos(angular))))
                families.append("envelope")
                other = (index + 1) % 5
                height[other] = -sign
                labels.append(f"{index}T{other}" if sign == 1 else f"{other}T{index}")
                phases.append(np.degrees(np.arctan2(-height @ np.sin(angular), height @ np.cos(angular))))
                families.append("twist")
        distances = np.abs((phase - np.asarray(phases) + 180) % 360 - 180)
        best = int(np.argmin(distances))
        label, family = labels[best], families[best]
        result["method"] = "cremer-pople-phase"
    distance = float(distances[best])
    result.update(label=label if max_distance is None or distance <= max_distance else "unassigned",
                  nearest_label=label, family=family, distance=distance)
    return result
