"""Public data/output adapter for metadynamics analysis."""

from argparse import Namespace
from dataclasses import asdict
from os import PathLike
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np

from .core import Data
from ._mlmd_io import positive
from . import _mlmd_analysis_core as core


def _protect_inputs(directory, names, sources):
    inputs = {Path(source).expanduser().resolve() for source in sources if source is not None}
    if inputs.intersection(directory / name for name in names):
        raise ValueError("Analysis output would overwrite an input file.")


def analyze(api, config, output_format):
    if output_format not in ("data", "files"):
        raise ValueError("output_format must be 'data' or 'files'.")
    if (output_format == "files" or config.plot) and config.output_dir is None:
        raise ValueError("File/plot output requires output_dir.")
    args = Namespace(**asdict(config))
    positive("bins", args.bins, integer=True)
    positive("smooth_window", args.smooth_window, integer=True, zero=True)
    if args.keep_wall and args.upper_wall is not None:
        raise ValueError("Choose keep_wall or upper_wall.")
    if isinstance(args.colvar, (str, PathLike)):
        args.colvar = [args.colvar]
    if args.hills is not None and args.fes_file is not None:
        raise ValueError("Choose hills or fes_file.")
    if args.energy_unit is not None and args.energy_unit not in core.ENERGY_TO_KJ:
        raise ValueError("energy_unit must be kJ/mol, kcal/mol, or eV.")
    if args.time_unit is not None and args.time_unit not in core.TIME_TO_S:
        raise ValueError("time_unit must be fs, ps, ns, or s.")
    if args.start_time is not None and not np.isfinite(args.start_time):
        raise ValueError("start_time must be finite.")
    if args.end_time is not None and (not np.isfinite(args.end_time) or (
            args.start_time is not None and args.end_time <= args.start_time)):
        raise ValueError("end_time must be finite and greater than start_time.")
    directory = Path(args.output_dir).expanduser().resolve() if args.output_dir else None
    names = ("free_energy.csv", "free_energy_smoothed.csv", "summary.json", "free_energy.png")
    if directory is not None and not args.overwrite:
        if any((directory / name).exists() for name in names):
            raise FileExistsError("Analysis output exists; choose a new directory or set overwrite=True.")
    if directory is not None:
        sources = [args.hills, args.fes_file, args.plumed_input, *(args.colvar or [])]
        _protect_inputs(directory, names, sources)
    summary, profile = core.analyze(args)
    if directory is not None:
        # Defaults can discover COLVAR/HILLS through plumed_input after the
        # initial preflight; protect those sources before replacing any output.
        sources = [item["file"] for item in summary["inputs"]]
        sources.append(summary.get("bias_reconstruction", {}).get("hills_file"))
        _protect_inputs(directory, names, sources)
    summary["cv_unit"] = args.cv_unit
    raw = np.empty(0) if profile is None else profile.free_energy.copy()
    x = np.empty(0) if profile is None else profile.x.copy()
    smooth = None if profile is None else core.smooth_profile(profile, args.smooth_window)
    data = Data(operation="metadynamics_analysis", path=str(directory or summary.get("source", "")),
                data=np.column_stack((x, raw)), x=x, free_energy=raw,
                free_energy_smoothed=smooth, energy_unit="kJ/mol", cv=args.cv,
                cv_unit=args.cv_unit, temperature_K=args.temperature,
                summary=summary, profile=profile, smooth_window=args.smooth_window,
                warnings=summary["warnings"], output_dir=directory)
    api.data = data
    if directory is not None:
        # Stage both the tables and Plot output before replacing previous
        # results, preserving the original script's behavior on plot failures.
        directory.mkdir(parents=True, exist_ok=True)
        for name in names:
            if (directory / name).is_dir():
                raise ValueError(f"Cannot replace analysis file: {directory / name} is a directory")
        with TemporaryDirectory(prefix=".metad-output-", dir=directory) as temporary:
            staged = Path(temporary)
            core._write_results(staged, summary, profile, args.cv, args.cv_unit,
                                plot=False, smooth_window=args.smooth_window)
            if args.plot and profile is not None:
                from .viz import Plot
                import matplotlib.pyplot as plt
                fig, _ = Plot().fes_1d(data)
                try:
                    fig.savefig(staged / "free_energy.png", dpi=180)
                finally:
                    plt.close(fig)
            for name in names:
                source, target = staged / name, directory / name
                if source.is_file():
                    source.replace(target)
                else:
                    target.unlink(missing_ok=True)
    return directory if output_format == "files" else data
