import matmalib.core as matmacore
import math
import numpy as np
import re
from numbers import Integral as _Integral, Real as _Real
from scipy.linalg import expm
from .elements import ELEMENT_SYMBOLS as _ELEMENT_SYMBOLS
from ._geometry import dihedral as _dihedral


class StateEditor:

    def __init__(self, state):

        self.state = state

    @staticmethod
    def get_distance(atom_list, state=None):

        """ Finds the distance between two atoms
        :param atom_list: Two Atom objects or two zero-based atom positions.
        :param state: State used to resolve integer atom positions.
        :return: (float) the distance between 2 atoms
        """

        from .core import Atom

        # If at1 or at2 are integers, extract these values from the supplied state.
        if len(atom_list) != 2: print(
            f"Warning! {len(atom_list)} atoms specified for function get_distance, expected 2.")

        if all(isinstance(at, int) for at in atom_list) and state != None:
            at1 = state.atoms[atom_list[0]]
            at2 = state.atoms[atom_list[1]]

        elif all(isinstance(at, Atom) for at in atom_list):
            at1 = atom_list[0]
            at2 = atom_list[1]

        else:
            raise ValueError('Error: Specify all Atoms, or all integers for atom list!')

        dist = 0
        for dim in range(3):
            dist += (at1.coord[dim] - at2.coord[dim]) ** 2

        return math.sqrt(dist)

    @staticmethod
    def adjacent_atoms(conn_mat, at):

        """returns all adjacent atoms to a specific atom in a conformation
        :param conn_mat: the connectivity matrix
        :param at: index of the selected atom
        :return: indices of all atoms adjacent to the selected atom
        """

        return np.nonzero(conn_mat[at, :])[0]

    @staticmethod
    def get_angle(atom_list, state=None):

        """Calculate an angle between three atoms:
        angle = acos(dot(X,Y)/(norm(X)*norm(Y)))
        :param atom_list: Three Atom objects or three zero-based atom positions.
        :param state: State used to resolve integer atom positions.
        :return: A tuple of angle in degrees and rotation-axis vector.
        """

        from .core import Atom

        if len(atom_list) != 3: print(
            f"Warning! {len(atom_list)} atoms specified for function get_distance, expected 3.")

        if all(isinstance(at, int) for at in atom_list) and state != None:
            at1 = state.atoms[atom_list[0]]
            at2 = state.atoms[atom_list[1]]
            at3 = state.atoms[atom_list[2]]

        elif all(isinstance(at, Atom) for at in atom_list):
            at1 = atom_list[0]
            at2 = atom_list[1]
            at3 = atom_list[2]

        else:
            raise ValueError('Error: Specify all Atoms, or all integers for atom list!')

        r1 = [x - y for x, y in zip(at1.coord, at2.coord)]
        r2 = [x - y for x, y in zip(at3.coord, at2.coord)]

        norm1 = StateEditor.get_distance([at1, at2])
        norm2 = StateEditor.get_distance([at2, at3])

        norm = norm1 * norm2
        dot = np.dot(r1, r2) / norm
        angle = math.acos(dot)
        axor = np.cross(r1, r2)

        return angle * 180 / np.pi, axor

    @staticmethod
    def get_dihedral(atom_list, state=None, ax: bool = False):
        """Measure the signed torsion of four ordered atoms, in degrees.

        Uses the same atan2 convention as glycan torsions: a positive
        right-handed rotation of the fourth atom about the second-to-third
        atom direction increases the angle. Values lie in [-180, 180].
        This corrects the opposite sign and translation-dependent sign bug
        in the legacy implementation.

        :param atom_list: Four Atom objects or four zero-based atom positions.
        :param state: State used to resolve integer atom positions.
        :param ax: Also return the unnormalized cross product of the two
            plane normals, retained for compatibility. It is zero for
            exactly planar torsions; it is not a stable rotation axis.
        :returns: Signed degrees, or (degrees, plane-normal cross product).
        :raises ValueError: For invalid selections, nonfinite coordinates,
            coincident central atoms, or collinear triples.
        """

        from .core import Atom

        if len(atom_list) != 4:
            raise ValueError("A dihedral requires exactly four atoms.")
        if all(isinstance(at, _Integral) for at in atom_list) and state is not None:
            if any(at < 0 or at >= len(state.atoms) for at in atom_list):
                raise ValueError("Dihedral atom positions are out of range.")
            atoms = [state.atoms[at] for at in atom_list]
        elif all(isinstance(at, Atom) for at in atom_list):
            atoms = atom_list
        else:
            raise ValueError("Specify all Atom objects, or all integer positions with a State.")

        coordinates = np.asarray([at.coord for at in atoms], dtype=float)
        angle = float(_dihedral(coordinates))
        if ax:
            bonds = np.diff(coordinates, axis=0)
            normals = (np.cross(bonds[0], bonds[1]), np.cross(bonds[1], bonds[2]))
            return angle, np.cross(*normals)
        return angle

    @staticmethod
    def measure(atom_list, state=None):

        if len(atom_list) == 2:
            return StateEditor.get_distance(atom_list, state=state)
        elif len(atom_list) == 3:
            return StateEditor.get_angle(atom_list, state=state)
        elif len(atom_list) == 4:
            return StateEditor.get_dihedral(atom_list, state=state)

    @staticmethod
    def determine_carried_atoms(state, atom_list):

        import networkx as nx
        from .core import Atom

        """Find all atoms necessary to be carried over during rotation
        of an atom
        :param at1: (list) the xyz coordinates of an atom
        :param at2: (list) the xyz coordinates of another atom
        :param conn_matt: the connectivity matrix of a conformer
        """
        #   1. Zero the connections in connectivity matrix
        # tmp_conn = np.copy(conf.conn_mat)

        if len(atom_list) != 2: print(
            f"Warning! {len(atom_list)} atoms specified for function get_distance, expected 2.")

        if all(isinstance(at, int) for at in atom_list) and state != None:
            at1 = state.atoms[atom_list[0]]
            at2 = state.atoms[atom_list[1]]

        elif all(isinstance(at, Atom) for at in atom_list):
            at1 = atom_list[0]
            at2 = atom_list[1]

        else:
            raise ValueError('Error: Specify all Atoms, or all integers for atom list!')

        coord1 = at1.coord
        coord2 = at2.coord

        broke_bond = False
        if state.conn_mat[at1.id, at2.id] == 1 or state.conn_mat[at2.id, at1.id] == 1:
            StateEditor.disconnect_atoms(state, at1.id, at2.id)
            broke_bond = True

        # cm = state.graph # This doesn't work.
        cm = nx.graph.Graph(state.conn_mat)

        if nx.is_connected(cm):
            print("Matrix still connected")
            return

        #   2. Determine the connected atoms:
        for subgraph in nx.connected_components(cm):
            if at2.id in subgraph:
                # print('subgraph:',subgraph)
                carried_atoms = [state.atoms[at] for at in subgraph]
        if broke_bond: StateEditor.connect_atoms(state, at1.id, at2.id)

        return carried_atoms

    @staticmethod
    def connect_atoms(state, at1: int, at2: int):

        """Connects two atoms in the conn_mat
        :param state: State with an associated conn_mat.
        :param at1: First zero-based matrix index.
        :param at2: Second zero-based matrix index.
        :return: None
        """

        state.conn_mat[at1, at2] = 1
        state.conn_mat[at2, at1] = 1

    @staticmethod
    def disconnect_atoms(state, at1: int, at2: int):

        """Disconnects two atoms in the conn_mat
        :param state: State with an associated conn_mat.
        :param at1: First zero-based matrix index.
        :param at2: Second zero-based matrix index.
        :return: None
        """

        state.conn_mat[at1, at2] = 0
        state.conn_mat[at2, at1] = 0

    def set_distance(self, atom_list, new_distance):

        """Set a new distance between two atoms
        :param atom_list: Two zero-based atom positions.
        :param new_distance: value of bond distance to be set
        """

        if len(atom_list) != 2 or not all(isinstance(at, int) for at in atom_list):
            raise ValueError("The position needs to be defined by 2 integers")

        at1 = self.state.atoms[atom_list[0]]
        at2 = self.state.atoms[atom_list[1]]

        # Identify displacement vector:

        displacement_vector = at2.coord - at1.coord
        norm_vector = np.sqrt(np.sum(displacement_vector ** 2))
        normalized_vector = displacement_vector / norm_vector

        old_distance = StateEditor.get_distance([at1, at2], state=self.state)
        translation = normalized_vector * (new_distance - old_distance)

        carried_atoms = StateEditor.determine_carried_atoms(self.state, [at1.id, at2.id])

        for at in carried_atoms:
            self.state.atoms[at.id].coord += translation

        # return xyz

    def set_angle(self, atom_list, new_ang):

        """Set a new angle between three atoms
        :param atom_list: Three zero-based atom positions.
        :param new_ang: Bond angle in degrees to be set.
        """

        if len(atom_list) != 3 or not all(isinstance(at, int) for at in atom_list):
            raise ValueError("The position needs to be defined by 3 integers")

        at1 = self.state.atoms[atom_list[0]]
        at2 = self.state.atoms[atom_list[1]]
        at3 = self.state.atoms[atom_list[2]]

        #   Determine the axis of rotation:

        old_ang, axor = StateEditor.get_angle([at1, at2, at3], state=self.state)
        norm_axor = np.sqrt(np.sum(axor ** 2))
        normalized_axor = axor / norm_axor

        #   Each carried_atom is rotated by euler-rodrigues formula:
        #   Also, I move the midpoint of the bond to the mid atom
        #   the rotation step and then move the atom back.

        rot_angle = np.pi * (new_ang - old_ang) / 180.
        translation = at2.coord

        # apply rotations to at3.
        rot = expm(np.cross(np.eye(3), normalized_axor * (rot_angle)))
        carried_atoms = StateEditor.determine_carried_atoms(self.state, [at2.id, at3.id])

        for at in carried_atoms:
            at.coord = np.dot(rot, at.coord - translation)
            at.coord = at.coord + translation

    def set_dihedral(self, atom_list, new_dih, incr=False, axis_pos="bond", threshold=0.1):
        """Rotate the moving fragment using the signed dihedral convention.

        In bond mode, rotate the component on the third atom's side of the
        central bond about the second-to-third atom direction. The first
        atom must remain fixed and the fourth must belong to that component.
        Cutting the bond must separate its endpoints; rings are rejected.
        Connectivity is never modified. Exact planar targets are supported.

        The legacy terminal mode rotates only atoms beyond the fourth atom
        about a parallel axis through that atom. It leaves the defining
        quartet fixed, so it does not set that quartet's measured torsion.

        :param atom_list: Four zero-based atom positions.
        :param new_dih: Finite target angle in degrees, or an increment.
        :param incr: Treat new_dih as an increment to the current dihedral.
        :param axis_pos: Use the central bond ('bond') or terminal pivot ('term').
        :param threshold: Finite nonnegative tolerance in degrees for a no-op.
        :returns: None; modifies the State's atom coordinates in place.
        :raises ValueError: For invalid inputs, degenerate geometry, or a
            bond that does not separate the required fixed and moving atoms.
        """
        import networkx as nx

        if len(atom_list) != 4 or not all(isinstance(at, _Integral) for at in atom_list):
            raise ValueError("A dihedral must be defined by four integer atom positions.")
        if len(set(atom_list)) != 4 or any(at < 0 or at >= len(self.state.atoms) for at in atom_list):
            raise ValueError("Supply four distinct atom positions within the State.")
        if axis_pos not in ("bond", "term"):
            raise ValueError("axis_pos must be 'bond' or 'term'.")
        if not isinstance(new_dih, _Real) or not np.isfinite(new_dih):
            raise ValueError("The dihedral target must be a finite real number.")
        if not isinstance(threshold, _Real) or not np.isfinite(threshold) or threshold < 0:
            raise ValueError("threshold must be finite and nonnegative.")

        old_dih = self.get_dihedral(atom_list, state=self.state)
        delta = float(new_dih % 360.0)
        if not incr:
            delta -= old_dih
        delta = (delta + 180.0) % 360.0 - 180.0
        if abs(delta) <= threshold:
            return

        atoms = [self.state.atoms[at] for at in atom_list]
        axis = np.asarray(atoms[2].coord, dtype=float) - atoms[1].coord
        axis /= np.linalg.norm(axis)
        translation = ((atoms[1].coord + atoms[2].coord) / 2
                       if axis_pos == "bond" else atoms[3].coord.copy())

        matrix = np.asarray(getattr(self.state, "conn_mat", None), dtype=float)
        size = len(self.state.atoms)
        if (matrix.shape != (size, size) or not np.all(np.isfinite(matrix))
                or not np.array_equal(matrix, matrix.T)):
            raise ValueError("Supply a finite symmetric connectivity matrix indexed by atom position.")
        graph = nx.from_numpy_array(matrix)
        fixed, moving = atom_list[1:3] if axis_pos == "bond" else atom_list[2:4]
        if not graph.has_edge(fixed, moving):
            raise ValueError("The selected rotation bond is missing from the connectivity matrix.")
        graph.remove_edge(fixed, moving)
        carried = nx.node_connected_component(graph, moving)
        if fixed in carried:
            raise ValueError("Cannot rotate a ring bond: cutting it does not separate the atoms.")
        if axis_pos == "bond":
            if atom_list[0] in carried or atom_list[3] not in carried:
                raise ValueError("The first and fourth atoms must lie on opposite sides of the rotation bond.")
        else:
            carried.remove(atom_list[3])
            if carried.intersection(atom_list):
                raise ValueError("Terminal rotation must leave the defining quartet fixed.")
        if not carried:
            return

        carried = sorted(carried)
        coordinates = np.asarray([self.state.atoms[at].coord for at in carried], dtype=float)
        if coordinates.shape != (len(carried), 3) or not np.all(np.isfinite(coordinates)):
            raise ValueError("The moving atoms must have finite three-dimensional coordinates.")
        rotation = expm(np.cross(np.eye(3), axis * np.radians(delta)))
        rotated = (coordinates - translation) @ rotation.T + translation
        for index, coordinate in zip(carried, rotated):
            self.state.atoms[index].coord = coordinate


class StateBuilder:

    def __init__(self, path, software):
        self.path = path
        self.software = software

    @staticmethod
    def element_symbol(A):
        """Return the symbol for an atomic number (1–118)."""
        return _ELEMENT_SYMBOLS[str(A)]

    def gaussian(self):

        """
        Parses log files from Gaussian 16 and appends information inside the log file to the mol object.

        """
        flags = {'freq_flag': False, 'nmr_flag': False, 'opt_flag': False, 'jcoup_flag': False, 'normal_mode': False,
                 'read_geom': False}
        job_type = None

        # temprorary variables to hold the data
        freq = []
        ints = []
        vibs = []
        geom = []
        atoms = []
        nmr = []
        self.NAtoms = None
        mode_num = -1
        mode_lines = -1
        atom_index = 0
        final_geom = False

        for line in open(self.path, 'r').readlines():

            if not job_type and re.search('^ #', line):

                if "opt" in line:
                    if "freq" in line:
                        job_type = 'optfreq'
                    else:
                        job_type = 'opt'
                elif "freq" in line:
                    if "opt" in line:
                        job_type = 'optfreq'

                    else:
                        job_type = 'freq'
                        flags["freq_flag"] = True

                elif "nmr" in line:
                    job_type = 'nmr'
                else:
                    job_type = 'sp'

            if self.NAtoms is None and re.search('^ NAtoms=', line):
                self.NAtoms = int(line.split()[1])

            if job_type == 'optfreq' or job_type == "freq":

                if flags['freq_flag'] == False and re.search('Normal termination', line): flags['freq_flag'] = True
                # We skip the opt part of optfreq job, all info is in the freq part

                if flags['freq_flag'] == True:

                    if re.search('SCF Done', line):
                        self.E = float(line.split()[4])
                    elif re.search('Sum of electronic and zero-point Energies', line):
                        self.Ezpe = float(line.split()[6])
                    elif re.search('Sum of electronic and thermal Enthalpies', line):
                        self.H = float(line.split()[6])
                    elif re.search('Sum of electronic and thermal Free Energies', line):
                        self.F = float(line.split()[7])

                    elif re.search('Standard orientation:', line):
                        final_geom = True

                    elif re.search('Coordinates', line) and len(geom) == 0:
                        flags['read_geom'] = True

                    elif flags['read_geom'] == True and re.search(
                            r'^\s*\d+\s+\d+\s+\d+\s+[+-]?\d+\.\d{6}\s+[+-]?\d+\.\d{6}\s+[+-]?\d+\.\d{6}\s*$',
                            line) and final_geom:

                        if len(line.split()) != 6:
                            continue

                        geom.append([float(x) for x in line.split()[3:6]])
                        coord = [float(x) for x in line.split()[3:6]]
                        type = StateBuilder.element_symbol(line.split()[1])
                        atom = matmacore.Atom(coord, type)

                        atoms.append(atom)
                        atom_index = atom_index + 1

                        if int(line.split()[0]) == self.NAtoms:
                            flags['read_geom'] = False

                    elif re.search(' Deg. of freedom', line):
                        self.NVibs = int(line.split()[3])

                    elif re.search('^ Frequencies', line):
                        freq_line = line.strip()
                        for f in freq_line.split()[2:5]: freq.append(float(f))
                        flags['normal_mode'] = False

                    elif re.search('^ IR Inten', line):
                        ir_line = line.strip()
                        for i in ir_line.split()[3:6]: ints.append(float(i))

                    if 'Atom  AN' in line:
                        flags['normal_mode'] = True  # locating normal modes of a frequency
                        mode_1 = []
                        mode_2 = []
                        mode_3 = []
                        # continue


                    elif re.search(r'^\s*\d+\s+\d+(?:\s+[+-]?\d+\.\d+){3,}\s*$', line) and flags['normal_mode'] == True:

                        if len(line.split()) >= 5:
                            mode_1.append([float(x) for x in line.split()[2:5]])

                        if len(line.split()) >= 8:
                            mode_2.append([float(x) for x in line.split()[5:8]])

                        if len(line.split()) >= 11:
                            mode_3.append([float(x) for x in line.split()[8:11]])

                        mode_num += 1

                    elif mode_num > mode_lines and flags['normal_mode'] == True:

                        flags['normald_mode'] = False
                        for m in [mode_1, mode_2, mode_3]: vibs.append(np.array(m))

            elif job_type == 'opt':

                if re.search('SCF Done', line): E = float(line.split()[4])
                if re.search('Optimization completed.', line):
                    self.E = E;
                    flags['opt_flag'] = True
                if flags['opt_flag'] == True:
                    if re.search('Standard orientation:', line):
                        flags['read_geom'] = True
                        final_geom = True

                    elif flags['read_geom'] == True and re.search(
                            r'^\s*\d+\s+\d+\s+\d+\s+[+-]?\d+\.\d{6}\s+[+-]?\d+\.\d{6}\s+[+-]?\d+\.\d{6}\s*$',
                            line) and final_geom:

                        if len(line.split()) != 6:
                            continue

                        geom.append([float(x) for x in line.split()[3:6]])
                        coord = [float(x) for x in line.split()[3:6]]
                        type = StateBuilder.element_symbol(line.split()[1])
                        atom = matmacore.Atom(coord, type)

                        atoms.append(atom)
                        atom_index = atom_index + 1

                        if int(line.split()[0]) == self.NAtoms:
                            flags['read_geom'] = False

            elif job_type == 'nmr':

                if re.search('SCF Done', line):
                    self.E = float(line.split()[4])
                elif re.search('Coordinates', line) and len(geom) == 0:
                    flags['read_geom'] = True

                elif flags['read_geom'] == True and re.search(
                        r'^\s*\d+\s+\d+\s+\d+\s+[+-]?\d+\.\d{6}\s+[+-]?\d+\.\d{6}\s+[+-]?\d+\.\d{6}\s*$',
                        line):

                    if len(line.split()) != 6:
                        continue

                    geom.append([float(x) for x in line.split()[3:6]])
                    coord = [float(x) for x in line.split()[3:6]]
                    type = StateBuilder.element_symbol(line.split()[1])
                    atom = matmacore.Atom(coord, type)

                    atoms.append(atom)
                    atom_index = atom_index + 1

                    if int(line.split()[0]) == self.NAtoms:
                        flags['read_geom'] = False

                elif re.search('Total nuclear spin-spin coupling J', line):
                    spin = [[] for i in range(self.NAtoms)]
                    flags['jcoup_flag'] = True

                elif flags['jcoup_flag'] == True and re.search(r'-?\d\.\d+[Dd][+\-]\d\d?', line):
                    for x in line.split()[1:]:
                        spin[int(line.split()[0]) - 1].append(float(x.replace('D', 'E')))

                elif flags['jcoup_flag'] == True and re.search('End of Minotr F.D. properties file', line):
                    flags['jcoup_flag'] = False

            elif job_type == 'sp':

                if re.search('SCF Done', line):
                    self.E = float(line.split()[4])
                elif re.search('Standard orientation:', line):
                    flags['read_geom'] = True

                elif flags['read_geom'] == True and re.search(
                        r'^\s*\d+\s+\d+\s+\d+\s+[+-]?\d+\.\d{6}\s+[+-]?\d+\.\d{6}\s+[+-]?\d+\.\d{6}\s*$',
                        line):

                    if len(line.split()) != 6:
                        continue

                    geom.append([float(x) for x in line.split()[3:6]])
                    coord = [float(x) for x in line.split()[3:6]]
                    type = StateBuilder.element_symbol(line.split()[1])
                    atom = matmacore.Atom(coord, type)

                    atoms.append(atom)
                    atom_index = atom_index + 1

                    if int(line.split()[0]) == self.NAtoms:
                        flags['read_geom'] = False

        # postprocessing:
        if job_type == 'freq' or job_type == 'optfreq':
            self.Freq = np.array(freq)
            self.Ints = np.array(ints)
            self.Vibs = np.zeros((self.NVibs, self.NAtoms, 3))

            for i in range(self.NVibs): self.Vibs[i, :, :] = vibs[i]

        if job_type == 'nmr':
            for at in spin:
                while len(at) < self.NAtoms: at.append(0)
            self.nmr = np.tril(spin)

        for i, atom in enumerate(atoms):
            atoms[i].id = i

        self.atoms = atoms

    def cp2k_geom(self):

        """ Parses information from CP2K. Right now only works for AIMD Trajectories, plan to implement opt compatability later.
        """

        with open(self.path, 'r') as geom:
            first_line = geom.readline()
            NAtoms = int(first_line.split()[0])

            raw_coords = geom.readlines()[-NAtoms:]

            coords = np.array([line.split()[1:] for line in raw_coords], dtype=float)
            types = np.array([line.split()[0] for line in raw_coords])

            geom.close()

        index = 0
        atoms = []
        for coord, type in zip(coords, types):
            atom = matmacore.Atom(coord, type, index)
            atoms.append(atom)
            index += 1

        self.NAtoms = NAtoms
        self.atoms = atoms

    def orca(self):

        """ Parses information from ORCA input.log file
        """

        with open(self.path, "r") as f:
            for line in f:
                if "Geometry Optimization Run" in line:
                    output_file = "input.orca.xyz"

                    with open("/".join([self.path, output_file]), "r") as f2:
                        first_line = f2.readline()
                        Natoms = int(first_line.split()[0])

                        second_line = f2.readlines()[0:1]
                        energy = np.array([i.split()[-1] for i in second_line], dtype=float)

                        raw_coords = f2.readlines()[-Natoms:]

                        coords = np.array([line.split()[1:] for line in raw_coords], dtype=float)
                        types = np.array([line.split()[0] for line in raw_coords])

                    self.Natoms = Natoms
                    self.xyz = coords
                    self.type_list = atoms

                    index = 0
                    atoms = []
                    for coord, type in zip(coords, types):
                        atom = matmacore.Atom(coord, type, index)
                        atoms.append(atom)
                        index += 1

                    self.atoms = atoms

                    self.E = energy

                elif "Single Point Calculation" and "FINAL SINGLE POINT ENERGY" in line:
                    # print(line.split()[-1])
                    job_type = "sp"
                    energy = np.array(line.split()[-1], dtype=float)
                    self.E = energy
                    return self

                else:
                    print("Unable to read ORCA log file")

    def build(self):

        from .core import State

        if self.software == 'cp2k':
            self.cp2k_geom()
        elif self.software == 'gaussian':
            self.gaussian()
        elif self.software == 'orca':
            self.orca()
        else:
            raise ValueError(f"Unsupported software: {self.software}")
        state = State(**self.__dict__)
        state.connectivity_matrix()
        state.system_split()
        return state


class DataBuilder:

    def __init__(self, path, software, **kwargs):

        self.path = path
        self.software = software

        for k, v in kwargs.items():
            setattr(self, k, v)

    def cp2k_md(self, colvar=None, timestep=None):

        from .core import State
        from .core import Atom

        self.time_unit = 'fs'  # Default unit in CP2K

        if getattr(self, 'observable', None) == 'cremer_pople':
            from .glycan import _xyz_frames, cremer_pople_trajectory
            timestep = getattr(self, 'timestep', None) if timestep is None else timestep
            if timestep is None:
                raise ValueError('Specify timestep for reading CP2K trajectories.')
            result = cremer_pople_trajectory(
                _xyz_frames(self.path), getattr(self, 'rings', None), timestep=timestep,
                degrees=getattr(self, 'degrees', True), path=self.path, software='cp2k',
                conn_mat=getattr(self, 'conn_mat', None), distXX=getattr(self, 'distXX', 1.65),
                distXH=getattr(self, 'distXH', 1.15), classify=getattr(self, 'classify', False),
            )
            self.__dict__.update(result.__dict__)
            return

        if re.search('.xyz', self.path):
            # Reads colvars straight from the xyz file. Requires specification of timestep and colvar coordinate.

            colvar = getattr(self, 'colvar', None) if colvar is None else colvar
            timestep = getattr(self, 'timestep', None) if timestep is None else timestep

            if colvar == None:
                raise ValueError('Error: Specify the atoms for your collective variables.')

            if timestep == None:
                raise ValueError('Error: Specify timestep for reading CP2K trajectories.')

            with open(self.path, 'r') as geom:
                line_1 = geom.readline()
                self.Natoms = int(line_1.split()[0])

                line_cnt = self.Natoms + 2
                line_num = 1
                conf_array = []
                conf_raw_coord = []

                for line in geom:

                    for col in colvar:
                        if line_num % line_cnt == (col + 2) % line_cnt:
                            conf_raw_coord.append(line.split())

                    if len(conf_raw_coord) == len(colvar):
                        conf_array.append(conf_raw_coord)
                        conf_raw_coord = []

                    line_num += 1

            conf_array = np.array(conf_array)
            mol_space = []
            colvar_data = []

            for conf in conf_array:
                index = 0
                state = State()
                atoms = []

                for row in conf:
                    type = row[0]
                    xyz = [float(i) for i in row[1:]]

                    atom = Atom(coord=xyz, type=type, index=index)
                    atoms.append(atom)

                    index += 1

                state.atoms = atoms
                mol_space.append(state)

                col_data = StateEditor.measure(atoms)
                colvar_data.append(col_data)

            time = [i / (1 / timestep) for i in range(len(colvar_data))]

            data = np.array(list(zip(time, colvar_data)))
            self.data = data

        elif re.search('.metadynLog', self.path):
            # Reads colvars from the metadynLog file.

            data = np.loadtxt(self.path)

            self.time_unit = 'fs'
            self.data = data

    def gromacs(self):
        """ Parses information from gromacs *.xvg file
        """

        # I don't use Gromacs enough to know how the output looks like. Right now, I am just reading the .xvg file:

        if re.search('.xvg', self.path):

            with open(self.path, 'r') as f:
                i = 0
                for line in f.readlines():
                    if re.search('#', line) or re.search('@', line):
                        i = i + 1

                    if re.search('xaxis', line):
                        time_unit = line.split()[-1].strip('()"')
                        self.time_unit = time_unit
                f.close()

            data = np.loadtxt(self.path, skiprows=i)

            self.data = data

        if re.search('.xpm', self.path):

            f = open(self.path, 'r')
            pattern = None;
            matrix_lett = [];
            matrix_dict = {}
            grid = None
            for line in f.readlines():

                if re.search(r'(\d\s\d\b)', line) and grid is None:
                    grid = int(line.split()[1])
                    pattern = grid * '[A-Z]'

                if pattern and re.search(pattern, line):
                    replL1 = line.replace('",', '')
                    replL2 = line.replace('"', '')
                    matrix_lett.append('\n'.join(replL2.split()))

                if re.search('((".*")[0-9])', line):
                    replL1 = line.replace('"', ' ')
                    letters, energy = values = str(replL1.split()[0]), float(replL1.split()[4])
                    matrix_dict.update(dict.fromkeys(letters, energy))

            matrix = np.zeros([grid, grid])
            for i in range(grid):
                for j in range(grid):
                    matrix[grid - i - 1, j] = matrix_dict[matrix_lett[i][j]]

            self.data = matrix

    def csv(self, skiprows=0, dtype=float, delimiter: str = ','):
        """
        Parse the CSV file at this builder's path into its data attribute.
        :param skiprows: (int) Number of rows to skip
        :param dtype: (type) Data type
        :param delimiter: (str) Delimiter
        """

        skiprows = getattr(self, 'skiprows', skiprows)
        dtype = getattr(self, 'dtype', dtype)
        delimiter = getattr(self, 'delimiter', delimiter)

        self.data = np.loadtxt(self.path, skiprows=skiprows, dtype=dtype, delimiter=delimiter)

    def build(self):

        from .core import Data

        if self.software == 'cp2k':
            self.cp2k_md()
        elif self.software == 'gromacs':
            self.gromacs()
        elif self.software == 'csv':
            self.csv()
        else:
            raise ValueError(f"Unsupported software: {self.software}")

        return Data(**self.__dict__)
