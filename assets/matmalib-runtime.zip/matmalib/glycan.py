"""Carbohydrate systems, CarPpy-based atom assignments, and puckering analysis."""

from itertools import chain
from numbers import Integral

import networkx as nx
import numpy as np

from ._carbohydrates import assign_sugars
from .core import Atom, Data, Fragment, State
from .puckering import cremer_pople, classify_ring_pucker

__all__ = ["Glycan", "cremer_pople_trajectory"]


def _indices(values, *, name, size=None):
    values = tuple(values)
    if not values or any(isinstance(i, bool) or not isinstance(i, Integral) for i in values):
        raise ValueError(f"{name} must contain integer atom indices.")
    if len(set(values)) != len(values):
        raise ValueError(f"{name} contains duplicate atom indices.")
    if any(i < 0 or (size is not None and i >= size) for i in values):
        raise ValueError(f"{name} contains an out-of-range atom index.")
    return tuple(int(i) for i in values)


def _rings(rings, size=None):
    result = tuple(_indices(ring, name="Ring", size=size) for ring in rings)
    if not result or any(len(ring) not in (5, 6) for ring in result):
        raise ValueError("Supply at least one ordered five- or six-membered ring.")
    if len(set(i for ring in result for i in ring)) != sum(map(len, result)):
        raise ValueError("Sugar rings must not share atoms.")
    return result


class Glycan(State):
    """A carbohydrate State whose monomers are Fragment objects.

    ``rings`` and ``monomers`` are parallel sequences of zero-based positions
    in ``atoms`` (not Atom.id values). Each ring must be in cyclic order;
    each monomer lists all atoms assigned to that sugar. Assign bridging
    atoms to only one monomer. Unassigned atoms remain in the State and are
    available through ``unassigned_atoms`` (for example solvent or counterions).

    With no assignments, detect sugars using CarPpy's connectivity-based
    approach. Supplied ``conn_mat`` or ``graph`` uses atom-list positions;
    otherwise bonds are inferred with ``distXX=1.65`` and ``distXH=1.15``
    (angstrom defaults). Automatic rings start at O, followed by the anomeric
    carbon and the remaining ring carbons. Ketoses start at C2, aldoses at C1.
    Supply both rings and monomers to bypass detection for unusual chemistry.
    """

    def __init__(self, atoms, *, rings=None, monomers=None, distXX=1.65, distXH=1.15, **kwargs):
        super().__init__(**kwargs)
        self.atoms = list(atoms)
        self.NAtoms = len(self.atoms)
        assignments = None
        links = []
        if monomers is not None and rings is None:
            raise ValueError("Supply ordered rings when specifying monomers explicitly.")
        if rings is not None:
            rings = _rings(rings, self.NAtoms)
        if rings is None or monomers is None:
            rings, detected_members, assignments, graph, links = assign_sugars(
                self.atoms, rings=rings, conn_mat=getattr(self, "conn_mat", None),
                graph=getattr(self, "graph", None), distXX=distXX, distXH=distXH,
            )
            if monomers is None:
                monomers = detected_members
            self.graph = graph
            self.Nmols = nx.number_connected_components(graph)
        self.rings = _rings(rings, self.NAtoms)
        memberships = tuple(
            _indices(group, name="Monomer", size=self.NAtoms) for group in monomers
        )
        if len(memberships) != len(self.rings):
            raise ValueError("Supply one monomer atom assignment per ring.")
        assigned = set()
        fragments = []
        for index, (ring, members) in enumerate(zip(self.rings, memberships)):
            if not set(ring).issubset(members):
                raise ValueError(f"Monomer {index} does not contain its ring atoms.")
            if assigned.intersection(members):
                raise ValueError("Monomers must not share atoms.")
            assigned.update(members)
            fragment = Fragment()
            fragment.id = index
            fragment.atom_indices = members
            fragment.ring_indices = ring
            fragment.atoms = [self.atoms[i] for i in members]
            fragment.ring_atoms = [self.atoms[i] for i in ring]
            fragment.ring_type = "pyranose" if len(ring) == 6 else "furanose"
            fragment.atom_assignment = dict(assignments[index]) if assignments is not None else {}
            fragment.named_atoms = {name: self.atoms[i] for name, i in fragment.atom_assignment.items()}
            if hasattr(self, "graph"):
                fragment.graph = self.graph.subgraph(members).copy()
            fragments.append(fragment)
        self.monomers = fragments
        self.fragments = fragments
        self.unassigned_atoms = [atom for i, atom in enumerate(self.atoms) if i not in assigned]
        self.glycosidic_bonds = links

    @classmethod
    def from_state(cls, state, *, rings=None, monomers=None, **kwargs):
        """Wrap a State, retaining its metadata and sharing its Atom objects."""
        metadata = dict(state.__dict__)
        metadata.pop("atoms", None)
        metadata.pop("rings", None)
        metadata.pop("monomers", None)
        metadata.update(kwargs)
        return cls(state.atoms, rings=rings, monomers=monomers, **metadata)

    @classmethod
    def from_file(cls, path, software="xyz", *, rings=None, monomers=None, **kwargs):
        """Read a system and detect sugars; XYZ/CP2K uses the last saved frame."""
        if software in ("xyz", "cp2k"):
            state = None
            for state in _xyz_frames(path):
                pass
            if state is None:
                raise ValueError("The trajectory contains no frames.")
            state.path = str(path)
            state.software = software
            state.id = str(path)
        else:
            state = State.from_file(str(path), software)
        return cls.from_state(state, rings=rings, monomers=monomers, **kwargs)

    def cremer_pople(self, *, degrees=True):
        """Return one puckering dictionary per monomer for the current geometry."""
        xyz = self.xyz
        return [cremer_pople(xyz[list(ring)], degrees=degrees) for ring in self.rings]

    def identify_ring_puckers(self, **kwargs):
        """Return CP coordinates, canonical pucker labels, and distances per ring.

        Six-membered labels follow CarPpy's positional convention: 1–5 are
        the ring carbons after O, and 6 is O. For ketoses these positions are
        not the chemical carbon numbers. Five-membered labels use 0–4 in
        ring order. See classify_ring_pucker for tolerances and conventions.
        """
        xyz = self.xyz
        return [classify_ring_pucker(xyz[list(ring)], **kwargs) for ring in self.rings]

    def identify_sugars(self):
        """Return base-residue names, D/L configuration and alpha/beta anomer.

        Common aldohexopyranoses and their C2 amino/N-acetyl, C6 deoxy and
        uronic-acid variants are supported. Other chemistry remains Unknown.
        """
        from ._glycan_analysis import identify_sugars
        return identify_sugars(self)

    def glycosidic_torsions(self, *, degrees=True):
        """Return phi/psi/omega and their atom quadruplets for each linkage."""
        from ._glycan_analysis import glycosidic_torsions
        return glycosidic_torsions(self, degrees=degrees)

    def backbone_torsions(self, *, degrees=True):
        """Return hydroxymethyl omega and its atom quadruplet per monomer."""
        from ._glycan_analysis import backbone_torsions
        return backbone_torsions(self, degrees=degrees)

    def snfg(self, **kwargs):
        """Return an SNFG (figure, axes); accepts draw_snfg plotting options."""
        from .snfg import draw_snfg
        return draw_snfg(self, **kwargs)

    def cremer_pople_trajectory(self, frames, **kwargs):
        """Analyze frames using this Glycan's fixed atom assignments.

        Accepts a Space, an iterable of States, or coordinate arrays with shape
        (n_frames, n_atoms, 3). Every frame must use this State's atom order.
        See :func:`cremer_pople_trajectory` for output and time conventions.
        """
        elements = tuple(atom.type for atom in self.atoms)

        def checked_frames():
            for index, frame in enumerate(getattr(frames, "states", frames)):
                if isinstance(frame, State):
                    if tuple(atom.type for atom in frame.atoms) != elements:
                        raise ValueError(f"Frame {index} has different elements or atom order.")
                    xyz = frame.xyz
                else:
                    xyz = np.asarray(frame, dtype=float)
                if xyz.shape != (self.NAtoms, 3):
                    raise ValueError(f"Frame {index} must have shape ({self.NAtoms}, 3).")
                yield xyz

        result = cremer_pople_trajectory(checked_frames(), self.rings, **kwargs)
        result.glycan = self
        return result


def cremer_pople_trajectory(
    frames, rings=None, *, timestep=1.0, times=None, time_unit="fs", degrees=True,
    path="", software=None, elements=None, conn_mat=None, distXX=1.65, distXH=1.15,
    classify=False,
):
    """Analyze ordered rings in a trajectory and return a plotting-ready Data.

    ``frames`` is a Space, an iterable of States, or an iterable of full
    coordinate arrays. Without ``rings``, detect sugars on the first State
    (or supply ``elements`` for coordinate arrays). ``conn_mat`` can provide
    reference connectivity; otherwise CarPpy distance cutoffs infer bonds.
    ``rings`` lists zero-based atom positions in cyclic order, held fixed for
    every frame. Frames must have identical atom order
    and whole, unwrapped rings; no periodic-boundary correction is performed.

    ``data[:, 0]`` contains explicit ``times`` or ``arange(n_frames)*timestep``.
    ``columns`` names every column: time, then monomer_0.Q, monomer_0.theta,
    monomer_0.phi, monomer_0.q2, monomer_0.q3, and so on. Five-membered rings
    omit theta and q3. Angles default to degrees; lengths retain input units.
    Frames are consumed once, without storing the full coordinate trajectory.
    With ``classify=True``, also attach ``pucker_labels``, ``pucker_families``,
    and ``pucker_distances`` arrays of shape (n_frames, n_rings), following
    classify_ring_pucker's positional naming and degree-distance conventions.
    The numeric data columns are unchanged.
    """
    frames = iter(getattr(frames, "states", frames))
    glycan = None
    if rings is None:
        first = next(frames, None)
        if first is None:
            raise ValueError("The trajectory contains no frames.")
        if isinstance(first, State):
            reference = first
        else:
            xyz = np.asarray(first, dtype=float)
            if elements is None:
                raise ValueError("Supply elements or explicit rings for coordinate-array trajectories.")
            elements = tuple(elements)
            if xyz.shape != (len(elements), 3):
                raise ValueError("elements must match the coordinate array's atom count.")
            reference = State(atoms=[Atom(coord=coord, type=element, index=i)
                                    for i, (coord, element) in enumerate(zip(xyz, elements))])
        if isinstance(reference, Glycan) and conn_mat is None:
            glycan = reference
        else:
            options = dict(distXX=distXX, distXH=distXH)
            if conn_mat is not None:
                options["conn_mat"] = conn_mat
            glycan = Glycan.from_state(reference, **options)
        rings = glycan.rings
        frames = chain((first,), frames)
    rings = _rings(rings)
    if times is None and (not np.isfinite(timestep) or timestep <= 0):
        raise ValueError("timestep must be finite and positive.")
    names = [list(("Q", "theta", "phi", "q2", "q3") if len(ring) == 6
                  else ("Q", "phi", "q2")) for ring in rings]
    columns = ("time",) + tuple(
        f"monomer_{i}.{name}" for i, fields in enumerate(names) for name in fields
    )
    rows = []
    pucker_labels, pucker_families, pucker_distances = [], [], []
    shape = None
    elements = None
    for index, frame in enumerate(frames):
        if isinstance(frame, State):
            current_elements = tuple(atom.type for atom in frame.atoms)
            if elements is not None and elements != current_elements:
                raise ValueError(f"Frame {index} has different elements or atom order.")
            elements = current_elements
            xyz = frame.xyz
        else:
            xyz = np.asarray(frame, dtype=float)
        if xyz.ndim != 2 or xyz.shape[1] != 3 or not np.all(np.isfinite(xyz)):
            raise ValueError(f"Frame {index} must contain finite (n_atoms, 3) coordinates.")
        if shape is None:
            shape = xyz.shape
            _rings(rings, size=len(xyz))
        elif xyz.shape != shape:
            raise ValueError(f"Frame {index} has a different number of atoms.")
        row = []
        labels, families, distances = [], [], []
        for ring, fields in zip(rings, names):
            try:
                analyze = classify_ring_pucker if classify else cremer_pople
                result = analyze(xyz[list(ring)], degrees=degrees)
            except ValueError as exc:
                raise ValueError(f"Frame {index}, ring {ring}: {exc}") from exc
            row.extend(result[name] for name in fields)
            if classify:
                labels.append(result["label"])
                families.append(result["family"])
                distances.append(result["distance"])
        rows.append(row)
        if classify:
            pucker_labels.append(labels)
            pucker_families.append(families)
            pucker_distances.append(distances)
    if not rows:
        raise ValueError("The trajectory contains no frames.")
    if times is None:
        times = np.arange(len(rows)) * timestep
    times = np.asarray(times, dtype=float)
    if times.shape != (len(rows),) or not np.all(np.isfinite(times)):
        raise ValueError("times must contain one finite value per frame.")
    data = Data(
        data=np.column_stack((times, rows)), columns=columns, rings=rings,
        time_unit=time_unit, angle_unit="degrees" if degrees else "radians",
        path=str(path), software=software, glycan=glycan,
    )
    if classify:
        data.pucker_labels = np.asarray(pucker_labels)
        data.pucker_families = np.asarray(pucker_families)
        data.pucker_distances = np.asarray(pucker_distances)
    return data


def _xyz_frames(path):
    """Stream XYZ/CP2K frames, rejecting truncated or malformed frames."""
    with open(path) as stream:
        index = 0
        while True:
            header = stream.readline()
            if not header:
                return
            if not header.strip():
                continue
            try:
                count = int(header.strip())
            except ValueError as exc:
                raise ValueError(f"Frame {index}: invalid XYZ atom count.") from exc
            if count <= 0 or not stream.readline():
                raise ValueError(f"Frame {index}: missing atoms or XYZ comment line.")
            atoms = []
            for atom_index in range(count):
                fields = stream.readline().split()
                if len(fields) != 4:
                    raise ValueError(f"Frame {index}, atom {atom_index}: invalid XYZ row.")
                try:
                    coord = [float(value) for value in fields[1:]]
                except ValueError as exc:
                    raise ValueError(f"Frame {index}, atom {atom_index}: invalid coordinates.") from exc
                atoms.append(Atom(coord=coord, type=fields[0], index=atom_index))
            yield State(atoms=atoms, NAtoms=count)
            index += 1
