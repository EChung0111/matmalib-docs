"""State/XYZ/PDB adapter for the project's validated periodic Packmol builder."""

from contextlib import ExitStack
import json
from os import PathLike
from pathlib import Path
import sys
from tempfile import TemporaryDirectory

import numpy as np
from ase import Atoms, io

from .core import Data
from ._mlmd_io import finish, positive, read_system, validate_output
from ._mlmd_packing import CellSettings, GENERATED_FILES, build, read_pdb_atoms
from ._mlmd_dynamics import distinct_paths


def _read_molecule(value):
    if isinstance(value, (str, PathLike)) and Path(value).suffix.lower() in (".pdb", ".ent"):
        # Keep the original builder's strict conformation/occupancy validation.
        return read_pdb_atoms(Path(value).expanduser())
    return read_system(value)


def _publish_report(api, report, directory=None, *, persist=False):
    if persist and directory is not None:
        report["work_dir"] = str(directory)
        report["files"] = {name: str(directory / name) for name in GENERATED_FILES
                           if (directory / name).is_file()}
        (directory / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
    api.data = Data(operation="solvation", summary=report, **report)
    return api.data


def solvate(api, solute, solvent, config, output, output_format):
    """Pack molecules or prepare reusable Packmol inputs without running it.

    ``dry_run=True`` requires ``work_dir`` and returns ``Data`` (also available
    as ``api.data``), including molecule counts, diagnostics and input paths.
    A dry run has no final geometry, so output/output_format must be omitted.
    """
    inputs = {"solute": solute, "solvent": solvent}
    if config.counterion is not None:
        inputs["counterion"] = config.counterion
    labels = {role: str(Path(value).expanduser().resolve())
              if isinstance(value, (str, PathLike)) else type(value).__name__
              for role, value in inputs.items()}
    report = {"status": "preparing", "warnings": [], "sources": labels}
    directory, report_ready = None, False
    try:
        if config.dry_run:
            if config.work_dir is None:
                raise ValueError("Solvation dry_run requires work_dir to preserve prepared input files.")
            if output is not None or output_format is not None:
                raise ValueError("Solvation dry_run returns Data; omit output and output_format.")
        path, kind = validate_output(output, output_format, config.overwrite)
        for source in inputs.values():
            distinct_paths(source, path)
        positive("multiplicity", config.multiplicity, integer=True)
        if config.charge is not None and (not np.isscalar(config.charge)
                                         or not np.isfinite(config.charge)):
            raise ValueError("Total charge must be finite.")
        molecules = {role: _read_molecule(value) for role, value in inputs.items()}
        with ExitStack() as stack:
            sources = Path(stack.enter_context(TemporaryDirectory(prefix="mlmd-molecules-")))
            if config.work_dir is None:
                directory = Path(stack.enter_context(TemporaryDirectory(prefix="mlmd-solvation-")))
            else:
                directory = Path(config.work_dir).expanduser().resolve()
                if directory.exists() and not directory.is_dir():
                    raise ValueError("Solvation work_dir must be a directory.")
                generated = [directory / name for name in GENERATED_FILES]
                for source in inputs.values():
                    distinct_paths(source, *generated)
                if any(item.is_dir() and not item.is_symlink() for item in generated):
                    raise ValueError("A solvation generated-file path is a directory; choose another work_dir.")
                if not config.overwrite and any(item.exists() or item.is_symlink() for item in generated):
                    raise FileExistsError("Solvation work_dir contains generated files; set overwrite=True to replace them.")
            for role, atoms in molecules.items():
                template = Atoms(numbers=atoms.numbers, positions=atoms.positions)
                io.write(sources / f"{role}.pdb", template, format="proteindatabank")
            executable = str(config.packmol)
            if executable == "packmol" and (Path(sys.executable).parent / "packmol").is_file():
                executable = str(Path(sys.executable).parent / "packmol")
            settings = CellSettings(
                solute=sources / "solute.pdb", solvent=sources / "solvent.pdb",
                counter_ion=sources / "counterion.pdb" if "counterion" in molecules else None,
                box=config.cell, density=config.density_g_ml, output_dir=directory,
                packmol=executable, tolerance=config.tolerance, nloop=config.nloop,
                timeout=config.timeout, seed=config.seed, dry_run=config.dry_run,
                volume_samples=config.volume_samples, vdw_radius=config.vdw_radii,
                counterion_gap=config.counterion_gap,
            )
            report = build(settings, input_masses={role: atoms.get_masses()
                                                   for role, atoms in molecules.items()},
                           source_labels=labels)
            report_ready = True
            data = _publish_report(api, report, directory, persist=config.work_dir is not None)
            if config.dry_run:
                return data
            atoms = io.read(directory / "cell.xyz", format="extxyz")
            count = report["molecules"][-1]["count"]
            charge = config.charge
            if charge is None:
                charge = sum(value.info.get("charge", 0.0) * (count if role == "solvent" else 1)
                             for role, value in molecules.items())
            if not np.isscalar(charge) or not np.isfinite(charge):
                raise ValueError("Total charge must be finite.")
            atoms.info.update(charge=float(charge), mult=config.multiplicity, solvation_report=report)
            # Keep the reusable work-dir XYZ as complete as the returned State.
            if path != directory / "cell.xyz":
                finish(atoms, directory / "cell.xyz", "xyz")
            return finish(atoms, path, kind)
    except Exception as exc:
        if hasattr(exc, "solvation_report"):
            report = exc.solvation_report
            report_ready = True
        report.update(status="failed", error=str(exc))
        _publish_report(api, report, directory,
                        persist=report_ready and config.work_dir is not None)
        raise
