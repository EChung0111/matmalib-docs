"""Aligned RMSD and conformer clustering, following CarPpy's analysis API.

CarPpy reference: CarP/conf_space.py and CarP/rmsd.py at commit
4589b228cf8772b0f2bd6ccae8bb2f41ad1e7d70. This implementation uses Kabsch
alignment and a condensed distance matrix for SciPy hierarchical clustering.
"""

from dataclasses import dataclass
from numbers import Integral

import numpy as np
from scipy.cluster.hierarchy import fcluster, linkage
from scipy.spatial.distance import squareform

__all__ = ["rmsd", "rmsd_matrix", "cluster_conformers", "ClusterResult"]


def _coordinates(value):
    xyz = np.asarray(value.xyz if hasattr(value, "atoms") else value, dtype=float)
    if xyz.ndim != 2 or xyz.shape[1] != 3 or not len(xyz) or not np.all(np.isfinite(xyz)):
        raise ValueError("Conformers must contain finite (n_atoms, 3) coordinates.")
    return xyz


def _selection(first, atom_indices, heavy_only):
    count = len(_coordinates(first))
    if atom_indices is None:
        indices = np.arange(count)
    else:
        values = tuple(atom_indices)
        if not values or any(isinstance(i, bool) or not isinstance(i, Integral) for i in values):
            raise ValueError("atom_indices must contain integer atom positions.")
        indices = np.asarray(values, dtype=int)
        if len(set(values)) != len(values) or np.any(indices < 0) or np.any(indices >= count):
            raise ValueError("atom_indices must be unique and within the atom list.")
    if heavy_only:
        if not hasattr(first, "atoms"):
            raise ValueError("heavy_only requires State objects with element information.")
        indices = indices[[first.atoms[i].type != "H" for i in indices]]
    if not len(indices):
        raise ValueError("The atom selection is empty.")
    return indices


def _compatible(first, other):
    if _coordinates(first).shape != _coordinates(other).shape:
        raise ValueError("Conformers must contain the same number of atoms in the same order.")
    if hasattr(first, "atoms") and hasattr(other, "atoms"):
        if [a.type for a in first.atoms] != [a.type for a in other.atoms]:
            raise ValueError("Conformer elements or atom order differ.")


def _aligned_rmsd(first, second, align):
    if align:
        first = first - first.mean(axis=0)
        second = second - second.mean(axis=0)
        u, _, vt = np.linalg.svd(second.T @ first)
        correction = np.eye(3)
        correction[-1, -1] = np.linalg.det(u @ vt)
        second = second @ (u @ correction @ vt)
    result = float(np.sqrt(np.mean(np.sum((first - second) ** 2, axis=1))))
    scale = max(np.linalg.norm(first), np.linalg.norm(second), np.finfo(float).tiny)
    return 0.0 if result <= 64 * np.finfo(float).eps * scale else result


def rmsd(first, second, *, atom_indices=None, heavy_only=False, align=True):
    """Return RMSD in input length units, using a proper rotation when aligned.

    Inputs are States or coordinate arrays. Atom correspondence is positional;
    this does not perform symmetry-based atom permutation or mirror reflection.
    Neither input is modified.
    """
    indices = _selection(first, atom_indices, heavy_only)
    _compatible(first, second)
    return _aligned_rmsd(_coordinates(first)[indices], _coordinates(second)[indices], align)


def rmsd_matrix(states, *, atom_indices=None, heavy_only=True, align=True):
    """Symmetric pairwise RMSD matrix for a Space or iterable of States."""
    states = list(getattr(states, "states", states))
    if not states:
        raise ValueError("At least one conformer is required.")
    indices = _selection(states[0], atom_indices, heavy_only)
    xyz = []
    for state in states:
        _compatible(states[0], state)
        xyz.append(_coordinates(state)[indices])
    distances = np.zeros((len(states), len(states)))
    for first in range(len(states)):
        for second in range(first):
            distances[first, second] = distances[second, first] = _aligned_rmsd(xyz[first], xyz[second], align)
    return distances


@dataclass
class ClusterResult:
    """Cluster labels/members use original indices; excluded labels are -1.

    ``distances`` covers all input states. Rows of ``linkage`` refer to
    ``included_indices``. ``representatives`` is a new Space sharing the
    selected State objects; no input conformer is reordered or modified.
    """

    labels: np.ndarray
    members: tuple
    representative_indices: tuple
    representatives: object
    distances: np.ndarray
    linkage: np.ndarray
    included_indices: np.ndarray
    threshold: float
    method: str


def cluster_conformers(states, threshold=1.0, *, method="single", heavy_only=True,
                       atom_indices=None, energy="E", energy_window=None,
                       energy_unit="hartree"):
    """Cluster aligned RMSDs with single, complete, average, or weighted linkage.

    ``threshold`` uses coordinate length units. An optional ``energy_window``
    is in kcal/mol above the minimum; ``energy_unit`` describes stored energies
    (hartree, kcal/mol, or kJ/mol). Complete finite energies are required for
    filtering. Representatives are lowest-energy members when all energies
    are available, otherwise medoids (minimum sum of within-cluster RMSDs).
    Set ``energy=None`` to select medoids even when energies are present.
    """
    from .core import Space

    source = states
    states = list(getattr(states, "states", states))
    if not np.isfinite(threshold) or threshold < 0:
        raise ValueError("threshold must be finite and nonnegative.")
    if method not in ("single", "complete", "average", "weighted"):
        raise ValueError("Use single, complete, average, or weighted linkage for RMSD distances.")
    distances = rmsd_matrix(states, atom_indices=atom_indices, heavy_only=heavy_only)
    energies = None
    if energy is not None:
        values = [getattr(state, energy, None) for state in states]
        if all(value is not None and np.ndim(value) == 0 for value in values):
            try:
                numeric = np.asarray(values, dtype=float)
            except (TypeError, ValueError):
                numeric = np.full(len(values), np.nan)
            if np.all(np.isfinite(numeric)):
                energies = numeric
    included = np.arange(len(states))
    if energy_window is not None:
        if not np.isfinite(energy_window) or energy_window < 0:
            raise ValueError("energy_window must be finite and nonnegative.")
        if energies is None:
            raise ValueError("Energy filtering requires finite energies for every conformer.")
        factors = {"hartree": 627.509474, "kcal/mol": 1.0, "kJ/mol": 1 / 4.184}
        if energy_unit not in factors:
            raise ValueError("energy_unit must be hartree, kcal/mol, or kJ/mol.")
        included = included[(energies - energies.min()) * factors[energy_unit] <= energy_window]
    if len(included) == 1:
        tree, raw = np.empty((0, 4)), np.ones(1, dtype=int)
    else:
        condensed = squareform(distances[np.ix_(included, included)], checks=False)
        tree = linkage(condensed, method=method, optimal_ordering=True)
        raw = fcluster(tree, threshold, criterion="distance")
    groups = sorted((tuple(included[raw == label]) for label in np.unique(raw)), key=min)
    labels = np.full(len(states), -1, dtype=int)
    representatives = []
    for label, group in enumerate(groups):
        labels[list(group)] = label
        scores = energies[list(group)] if energies is not None else distances[np.ix_(group, group)].sum(axis=1)
        representatives.append(int(group[int(np.argmin(scores))]))
    selected = Space(states=[states[i] for i in representatives], theory=getattr(source, "theory", None))
    return ClusterResult(labels, tuple(groups), tuple(representatives), selected, distances,
                         tree, included, float(threshold), method)
