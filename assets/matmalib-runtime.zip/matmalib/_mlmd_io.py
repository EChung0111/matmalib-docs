"""Single-frame conversion and bounded-memory XYZ I/O for mlmd."""

from copy import deepcopy
from numbers import Integral
from os import PathLike
from pathlib import Path
from tempfile import TemporaryFile

import numpy as np

from .core import Atom, State


def positive(name, value, *, zero=False, integer=False):
    if (isinstance(value, (bool, np.bool_)) or not np.isscalar(value)
            or (integer and not isinstance(value, Integral))
            or not np.isfinite(value) or value < 0 or (not zero and value == 0)):
        raise ValueError(f"{name} must be a finite {'nonnegative' if zero else 'positive'} "
                         f"{'integer' if integer else 'number'}.")


def _read_geometry(path):
    """Read the final frame; repair only ASE's known blank-residue layout."""
    from ase import io
    suffix = path.suffix.lower()
    if suffix not in (".xyz", ".extxyz", ".pdb", ".ent"):
        raise ValueError("Input geometry must be XYZ, extended XYZ, or PDB.")
    fmt = "proteindatabank" if suffix in (".pdb", ".ent") else "extxyz"
    atoms = None
    try:
        for frame in io.iread(path, index=":", format=fmt):
            atoms = frame
    except ValueError as original_error:
        if fmt != "extxyz":
            raise
        from ase.io.extxyz import key_val_str_to_dict
        schema = ("species:S:1:pos:R:3:occupancy:R:1:bfactor:R:1:"
                  "residuenames:S:1:atomtypes:S:1:residuenumbers:I:1")
        repaired = 0
        # Repair to a disk-backed stream, never retain a trajectory in RAM.
        with path.open() as source, TemporaryFile(mode="w+") as temporary:
            try:
                for count_line in source:
                    if not count_line.strip():
                        continue
                    count = int(count_line)
                    header = next(source)
                    if count < 0 or key_val_str_to_dict(header.strip()).get("Properties") != schema:
                        raise original_error
                    temporary.write(count_line)
                    temporary.write(header)
                    for _ in range(count):
                        row = next(source)
                        fields = row.split()
                        if len(fields) == 8 and fields[6].lower() == fields[0].lower():
                            [float(value) for value in fields[1:6]]
                            int(fields[7])
                            fields.insert(6, "UNK")
                            row = " ".join(fields) + "\n"
                            repaired += 1
                        elif len(fields) != 9:
                            raise original_error
                        temporary.write(row)
                if not repaired:
                    raise original_error
                temporary.seek(0)
                for frame in io.iread(temporary, index=":", format="extxyz"):
                    atoms = frame
            except (ValueError, TypeError, IndexError, StopIteration):
                raise original_error from None
        atoms.info["input_repair"] = {"blank_residue_names_filled": repaired,
                                      "replacement": "UNK", "input_unchanged": True}
    if atoms is None:
        raise ValueError("Input geometry contains no frames.")
    return atoms


def constraint_records(atoms):
    """Serializable constraints, including the actual SHAKE target lengths."""
    records = []
    for constraint in atoms.constraints:
        record = deepcopy(constraint.todict())
        if record["name"] == "FixBondLengths" and constraint.bondlengths is not None:
            record["kwargs"]["bondlengths"] = np.asarray(constraint.bondlengths).tolist()
        records.append(record)
    return records


def read_system(value):
    from ase import Atoms, io, units
    if isinstance(value, (str, PathLike)):
        path = Path(value).expanduser()
        atoms = _read_geometry(path)
    elif isinstance(value, Atoms):
        atoms = value.copy()
    elif isinstance(value, State):
        atoms = Atoms([atom.type for atom in value.atoms], positions=value.xyz,
                      cell=getattr(value, "cell", None), pbc=getattr(value, "pbc", False))
        atoms.info = deepcopy(getattr(value, "info", {}))
        atoms.info["charge"] = getattr(value, "charge", atoms.info.get("charge", 0.0))
        atoms.info["mult"] = getattr(value, "multiplicity", getattr(value, "mult", atoms.info.get("mult", 1)))
        masses = [atom.mass for atom in value.atoms]
        if all(mass is not None for mass in masses):
            atoms.set_masses(masses)
        if getattr(value, "momenta", None) is not None:
            atoms.set_momenta(value.momenta)
        elif getattr(value, "velocities", None) is not None:
            atoms.set_velocities(np.asarray(value.velocities) / units.fs)
        if getattr(value, "constraints", None) is not None:
            atoms.set_constraint(deepcopy(value.constraints))
    else:
        raise TypeError("Expected an XYZ/PDB path, matmalib State, or ASE Atoms.")
    if not atoms.constraints and atoms.info.get("mlmd_constraints"):
        from ase.constraints import dict2constraint
        atoms.set_constraint([dict2constraint(record) for record in atoms.info["mlmd_constraints"]])
    atoms.calc = None
    if not len(atoms) or not np.isfinite(atoms.positions).all():
        raise ValueError("A system must contain atoms with finite coordinates.")
    return atoms


def prepare(value, config):
    atoms = read_system(value)
    if config.cell is not None:
        cell = config.cell
        atoms.set_cell([cell] * 3 if np.ndim(cell) == 0 else cell)
    if config.pbc is not None:
        atoms.set_pbc(config.pbc)
    if not np.isfinite(atoms.cell).all():
        raise ValueError("Cell must be finite.")
    if atoms.pbc.any() and (atoms.cell.rank != 3 or atoms.get_volume() <= 1e-12):
        raise ValueError("Periodic geometry requires a full cell; set config.cell.")
    charge = atoms.info.get("charge", 0.0) if config.charge is None else config.charge
    mult = atoms.info.get("mult", 1) if config.multiplicity is None else config.multiplicity
    if not np.isscalar(charge) or not np.isfinite(charge):
        raise ValueError("charge must be finite.")
    positive("multiplicity", mult, integer=True)
    atoms.info.update(charge=float(charge), mult=int(mult))
    positive("min_distance", config.min_distance, zero=True)
    if config.min_distance:
        from ase.neighborlist import neighbor_list
        distances = neighbor_list("d", atoms, config.min_distance)
        if len(distances):
            raise ValueError(f"Severe atomic overlap: {distances.min():.5g} angstrom "
                             f"(< {config.min_distance}).")
    from ase.constraints import FixAtoms, FixBondLengths, FixCom
    if config.fixed_atoms:
        indices = tuple(config.fixed_atoms)
        if (len(set(indices)) != len(indices) or any(
                isinstance(i, bool) or not isinstance(i, Integral) or i < 0 or i >= len(atoms)
                for i in indices)):
            raise ValueError("fixed_atoms must be unique zero-based atom indices.")
        existing = {int(i) for constraint in atoms.constraints if isinstance(constraint, FixAtoms)
                    for i in constraint.get_indices()}
        missing = [i for i in indices if i not in existing]
        if missing:
            atoms.set_constraint([*atoms.constraints, FixAtoms(indices=missing)])
    if config.shake_hydrogens:
        from ase.neighborlist import neighbor_list
        positive("shake_cutoff", config.shake_cutoff)
        positive("shake_tolerance", config.shake_tolerance)
        ii, jj = neighbor_list("ij", atoms, config.shake_cutoff)
        pairs = sorted({(int(i), int(j)) for i, j in zip(ii, jj)
                        if i < j and (atoms.numbers[i] == 1 or atoms.numbers[j] == 1)})
        existing_pairs = {tuple(sorted(map(int, pair))) for constraint in atoms.constraints
                          if isinstance(constraint, FixBondLengths) for pair in constraint.pairs}
        pairs = [pair for pair in pairs if pair not in existing_pairs]
        if pairs:
            atoms.set_constraint([*atoms.constraints,
                                  FixBondLengths(pairs, tolerance=config.shake_tolerance)])
    if (config.fix_com or config.shake_hydrogens) and not any(
            isinstance(constraint, FixCom) for constraint in atoms.constraints):
        atoms.set_constraint([*atoms.constraints, FixCom()])
    return atoms


def as_state(atoms):
    from ase import units
    items = []
    for i, (symbol, position, mass) in enumerate(zip(
            atoms.get_chemical_symbols(), atoms.positions, atoms.get_masses())):
        item = Atom(coord=position.copy(), type=symbol, index=i)
        item.mass = float(mass)
        items.append(item)
    state = State(atoms=items, NAtoms=len(items), id="mlmd", cell=atoms.cell.array.copy(),
                  pbc=atoms.pbc.copy(), info=deepcopy(atoms.info),
                  charge=atoms.info.get("charge", 0.0),
                  multiplicity=atoms.info.get("mult", 1))
    state.mult = state.multiplicity
    state.constraints = deepcopy(atoms.constraints)
    if atoms.has("momenta"):
        state.momenta = atoms.get_momenta()
        state.velocities = atoms.get_velocities() * units.fs  # angstrom/fs
    for key in ("solvation_report", "minimization_converged", "minimization_steps"):
        if key in atoms.info:
            setattr(state, key, deepcopy(atoms.info[key]))
    if atoms.calc is not None and "energy" in atoms.calc.results:
        state.energy_eV = float(atoms.calc.results["energy"])
    return state


def output_path(path, *, overwrite=False, xyz=False):
    path = Path(path).expanduser().resolve()
    if xyz and path.suffix.lower() not in (".xyz", ".extxyz"):
        raise ValueError("Geometry/trajectory output must have an .xyz or .extxyz suffix.")
    if path.exists() and not overwrite:
        raise FileExistsError(f"Output already exists: {path}; set overwrite=True to replace it.")
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def validate_output(output, output_format, overwrite=False):
    kind = output_format or ("xyz" if output is not None else "state")
    if kind == "state":
        kind = "system"
    if kind not in ("xyz", "system") or (kind == "xyz" and output is None):
        raise ValueError("output_format must be 'state' or 'xyz'; XYZ requires output=path.")
    path = output_path(output, overwrite=overwrite, xyz=True) if output is not None else None
    return path, kind


def write_frame(stream, atoms):
    from ase import Atoms, io
    # Copy only the current frame; never attach a live calculator to the writer.
    frame = Atoms(numbers=atoms.numbers, positions=atoms.positions,
                  cell=atoms.cell, pbc=atoms.pbc, masses=atoms.get_masses())
    frame.info = deepcopy(atoms.info)
    if atoms.constraints:
        frame.info["mlmd_constraints"] = constraint_records(atoms)
    if atoms.has("momenta"):
        frame.set_momenta(atoms.get_momenta())
    if frame.pbc.any():
        frame.wrap()
    io.write(stream, frame, format="extxyz", write_results=False)
    stream.flush()


def finish(atoms, path, kind):
    if path is not None:
        with path.open("w") as stream:
            write_frame(stream, atoms)
    return as_state(atoms) if kind == "system" else path
