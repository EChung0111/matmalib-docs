"""Validated structured collective variables and generated PLUMED input.

The metadata marker is retained in portable checkpoints but is not a PLUMED
action. Legacy notebook markers remain readable for existing checkpoints.
"""

from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import fields, is_dataclass
import json
import math
from numbers import Integral, Real
from pathlib import Path
import re
from typing import Any


MARKER_PREFIX = "# MATMALIB_METAD_V1 "
LEGACY_MARKER_PREFIX = "# AIMNET_METAD_V1 "
SCHEMA_VERSION = 1
MAX_GRID_POINTS = 2_000_000
MAX_PAUSE_CONDITIONS = 32
MAX_PAUSE_DEPTH = 8
HIT_LABEL = "nb_hit"
_ARITY = {"DISTANCE": 2, "ANGLE": 3, "TORSION": 4}
_ANGSTROM_UNITS = {"angstrom", "A", "Å"}
_GRID_FIELDS = {"grid_min", "grid_max", "grid_bins"}
_INITIAL_STATE = dict(stopped=False, stop_step=None, stop_time_fs=None, trigger_value=None)


def _real(value, name, *, positive=False):
    if isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value):
        raise ValueError(f"{name} must be a finite number")
    result = float(value)
    if positive and result <= 0:
        raise ValueError(f"{name} must be positive")
    return result


def _integer(value, name, *, minimum=1):
    if isinstance(value, bool) or not isinstance(value, Integral) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return int(value)


def _unknown_keys(value, allowed, name):
    if any(not isinstance(key, str) for key in value):
        raise ValueError(f"{name} field names must be strings")
    extra = set(value) - set(allowed)
    if extra:
        raise ValueError(f"Unknown {name} fields: {sorted(extra)}")


def _mapping(value, name):
    if is_dataclass(value) and not isinstance(value, type):
        value = {field.name: getattr(value, field.name) for field in fields(value)}
    if not isinstance(value, Mapping):
        raise ValueError(f"{name} must be a dataclass or dictionary")
    return value


def _distance_unit(unit, name):
    if unit is None:
        return "nm"
    if isinstance(unit, str):
        if unit == "nm":
            return "nm"
        if unit in _ANGSTROM_UNITS:
            return "angstrom"
    raise ValueError(f"{name}: distance unit must be nm or angstrom")


def _normalize_pause(stop_rule, cvs, input_units):
    """Canonicalize a bounded tree of comparisons in the selected CV's units."""
    conditions = 0
    by_label = {cv["label"]: cv for cv in cvs}

    def visit(value, depth):
        nonlocal conditions
        if depth > MAX_PAUSE_DEPTH:
            raise ValueError(f"Pause conditions cannot be nested more than {MAX_PAUSE_DEPTH} levels")
        value = _mapping(value, "pause_when")
        mode = value.get("mode", "pause")
        if mode != "pause":
            raise ValueError("Stop mode must be 'pause': deposition resumes when the condition no longer holds")
        if "operator" in value or "conditions" in value:
            _unknown_keys(value, {"operator", "conditions", "mode"}, "pause group")
            operator = value.get("operator")
            if not isinstance(operator, str) or operator not in {"all", "any"}:
                raise ValueError("Pause group operator must be 'all' or 'any'")
            children = value.get("conditions")
            if (not isinstance(children, Sequence) or isinstance(children, (str, bytes))
                    or not children or len(children) > MAX_PAUSE_CONDITIONS):
                raise ValueError(f"Pause group conditions must contain 1 to {MAX_PAUSE_CONDITIONS} comparisons or groups")
            return dict(operator=operator, conditions=[visit(child, depth + 1) for child in children], mode=mode)
        _unknown_keys(value, {"cv", "comparison", "threshold", "unit", "mode"}, "stop rule")
        if not {"cv", "comparison", "threshold"}.issubset(value):
            raise ValueError("Stop rule requires cv, comparison, and threshold")
        if not isinstance(value["cv"], str) or value["cv"] not in by_label:
            raise ValueError("Stop rule cv must name one of the configured CV labels")
        comparison = value["comparison"]
        if not isinstance(comparison, str) or comparison not in {">=", "<="}:
            raise ValueError("Stop comparison must be '>=' or '<='")
        selected = by_label[value["cv"]]
        unit = value.get("unit")
        if unit is None:
            unit = input_units[selected["label"]]
        threshold = _real(value["threshold"], "stop threshold")
        if selected["type"] == "DISTANCE":
            if _distance_unit(unit, selected["label"]) == "angstrom":
                threshold /= 10
        elif not isinstance(unit, str) or unit not in {"rad", "deg"}:
            raise ValueError(f"{selected['label']}: angular threshold unit must be rad or deg")
        elif unit == "deg":
            threshold = math.radians(threshold)
        if selected["grid_bins"] is not None:
            if not selected["grid_min"] <= threshold <= selected["grid_max"]:
                raise ValueError("Stop threshold must lie inside its CV grid, in that CV's units")
        else:
            domain = {"DISTANCE": (0.0, math.inf), "ANGLE": (0.0, math.pi),
                      "TORSION": (-math.pi, math.pi)}[selected["type"]]
            if not domain[0] <= threshold <= domain[1]:
                raise ValueError("Stop threshold must lie inside its CV's physical domain, in that CV's units")
        conditions += 1
        if conditions > MAX_PAUSE_CONDITIONS:
            raise ValueError(f"Pause controls cannot contain more than {MAX_PAUSE_CONDITIONS} comparisons")
        return dict(cv=value["cv"], comparison=comparison, threshold=threshold, mode=mode)

    return visit(stop_rule, 0)


def normalize_spec(cvs: object, stop_rule=None, atom_count=None) -> dict[str, Any]:
    """Validate one/two CVs with optional grids; return a JSON-safe specification.

    DISTANCE accepts nm or angstrom; canonical values use nm. ANGLE and TORSION
    use radians. Pause thresholds inherit their CV's input unit unless explicit.
    All CVs must be grid-free,
    or each must supply complete bounds and bins. Explicit torsion grids cover
    [-pi, pi]. Grid allocation counts (bins + 1) along each axis and rejects
    over two million points; grid-free specifications have grid_points=None.
    """
    if not isinstance(cvs, Sequence) or isinstance(cvs, (str, bytes)) or len(cvs) not in (1, 2):
        raise ValueError("cvs must contain one or two CV configurations")
    if atom_count is not None:
        atom_count = _integer(atom_count, "atom_count")
    normalized = []
    input_units = {}
    labels = set()
    required = {"label", "type", "atoms", "sigma"}
    for index, cv in enumerate(cvs, 1):
        cv = _mapping(cv, f"CV {index}")
        _unknown_keys(cv, required | _GRID_FIELDS | {"unit"}, f"CV {index}")
        missing = required - set(cv)
        if missing:
            raise ValueError(f"CV {index} is missing {sorted(missing)}")
        label = cv["label"]
        if (not isinstance(label, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", label)
                or label.startswith("nb_")):
            raise ValueError("CV labels must be identifiers; the 'nb_' prefix is reserved")
        if label in labels:
            raise ValueError(f"Duplicate CV label: {label}")
        labels.add(label)
        kind = cv["type"]
        if not isinstance(kind, str) or kind.upper() not in _ARITY:
            raise ValueError(f"{label}: type must be DISTANCE, ANGLE, or TORSION")
        kind = kind.upper()
        atoms = cv["atoms"]
        if not isinstance(atoms, Sequence) or isinstance(atoms, (str, bytes)) or len(atoms) != _ARITY[kind]:
            raise ValueError(f"{label}: {kind} requires {_ARITY[kind]} one-based atom indices")
        atoms = [_integer(atom, f"{label} atom index") for atom in atoms]
        if len(set(atoms)) != len(atoms) or (atom_count is not None and max(atoms) > atom_count):
            raise ValueError(f"{label}: atom indices must be distinct and within the system")
        unit = "nm" if kind == "DISTANCE" else "rad"
        input_unit = _distance_unit(cv.get("unit"), label) if kind == "DISTANCE" else "rad"
        if kind != "DISTANCE" and cv.get("unit") not in (None, unit):
            raise ValueError(f"{label}: {kind} values and widths must be in {unit}")
        input_units[label] = input_unit
        sigma = _real(cv["sigma"], f"{label} sigma", positive=True)
        if input_unit == "angstrom":
            sigma = _real(sigma / 10, f"{label} sigma in nm", positive=True)
        grid_fields = sum(cv.get(name) is not None for name in _GRID_FIELDS)
        if grid_fields not in (0, 3):
            raise ValueError(f"{label}: supply all of grid_min, grid_max and grid_bins, or leave all unset")
        lower = upper = bins = None
        if grid_fields:
            lower = _real(cv["grid_min"], f"{label} grid_min")
            upper = _real(cv["grid_max"], f"{label} grid_max")
            if input_unit == "angstrom":
                lower, upper = lower / 10, upper / 10
            bins = _integer(cv["grid_bins"], f"{label} grid_bins", minimum=2)
            if lower >= upper:
                raise ValueError(f"{label}: grid_min must be smaller than grid_max")
            if kind == "DISTANCE" and lower < 0:
                raise ValueError(f"{label}: a distance grid cannot start below zero")
            if kind == "ANGLE" and not (0 <= lower < upper <= math.pi):
                raise ValueError(f"{label}: ANGLE grid bounds must lie within [0, pi] radians")
            if kind == "TORSION":
                if not (math.isclose(lower, -math.pi, rel_tol=0, abs_tol=1e-10)
                        and math.isclose(upper, math.pi, rel_tol=0, abs_tol=1e-10)):
                    raise ValueError(f"{label}: TORSION requires the full periodic [-pi, pi] grid")
                lower, upper = -math.pi, math.pi
        normalized.append(dict(label=label, type=kind, atoms=atoms, sigma=sigma,
                               grid_min=lower, grid_max=upper, grid_bins=bins, unit=unit))
    gridded = {cv["grid_bins"] is not None for cv in normalized}
    if len(gridded) != 1:
        raise ValueError("All structured CVs must have complete grids, or all must be grid-free")
    grid_points = math.prod(cv["grid_bins"] + 1 for cv in normalized) if True in gridded else None
    if grid_points is not None and grid_points > MAX_GRID_POINTS:
        raise ValueError(f"Metadynamics grid requires up to {grid_points:,} points; limit is {MAX_GRID_POINTS:,}. "
                         "Choose CV-specific bounds and bin counts.")
    rule = None if stop_rule is None else _normalize_pause(stop_rule, normalized, input_units)
    return dict(schema=SCHEMA_VERSION, cvs=normalized, stop_rule=rule,
                state=deepcopy(_INITIAL_STATE), grid_points=grid_points)


def validate_cv_specs(cvs, atom_count=None):
    """Return canonical dictionaries for public CVConfig objects or mappings."""
    return normalize_spec(cvs, atom_count=atom_count)["cvs"]


def _validated_state(state):
    if not isinstance(state, Mapping):
        raise ValueError("Checkpoint deposition state must be a dictionary")
    _unknown_keys(state, _INITIAL_STATE, "deposition state")
    result = {**_INITIAL_STATE, **state}
    if not isinstance(result["stopped"], bool):
        raise ValueError("Deposition stopped flag must be boolean")
    if result["stop_step"] is not None:
        result["stop_step"] = _integer(result["stop_step"], "stop_step", minimum=0)
    if result["stop_time_fs"] is not None:
        result["stop_time_fs"] = _real(result["stop_time_fs"], "stop_time_fs")
        if result["stop_time_fs"] < 0:
            raise ValueError("stop_time_fs must be nonnegative")
    if (result["stop_step"] is None) != (result["stop_time_fs"] is None):
        raise ValueError("stop_step and stop_time_fs must be recorded together")
    if result["trigger_value"] is not None:
        result["trigger_value"] = _real(result["trigger_value"], "trigger_value")
    if result["stopped"]:
        raise ValueError("Pause controls cannot have a permanently stopped checkpoint state")
    return result


def _canonical_spec(spec, atom_count=None) -> dict[str, Any]:
    if (not isinstance(spec, Mapping) or type(spec.get("schema")) is not int
            or spec["schema"] != SCHEMA_VERSION):
        raise ValueError("Unsupported metadynamics marker schema")
    _unknown_keys(spec, {"schema", "cvs", "stop_rule", "state", "grid_points"}, "metadynamics specification")
    result = normalize_spec(spec.get("cvs"), spec.get("stop_rule"), atom_count)
    result["state"] = _validated_state(spec.get("state", _INITIAL_STATE))
    if "grid_points" in spec and spec["grid_points"] != result["grid_points"]:
        raise ValueError("Recorded grid size disagrees with CV grids")
    return result


def marker_line(spec):
    return MARKER_PREFIX + json.dumps(_canonical_spec(spec), separators=(",", ":"), allow_nan=False)


def parse_marker(lines):
    """Read native or legacy notebook metadata; return None for unmarked input."""
    markers = []
    for raw in lines:
        if not isinstance(raw, str):
            raise ValueError("PLUMED input lines must be strings")
        line = raw.strip()
        for prefix in (MARKER_PREFIX, LEGACY_MARKER_PREFIX):
            if line == prefix.rstrip():
                raise ValueError("Malformed metadynamics marker")
            if line.startswith(prefix):
                markers.append(line[len(prefix):])
    if not markers:
        return None
    if len(markers) != 1:
        raise ValueError("Expected exactly one metadynamics marker")
    try:
        decoded = json.loads(markers[0])
    except (TypeError, json.JSONDecodeError) as exc:
        raise ValueError("Malformed metadynamics marker") from exc
    return _canonical_spec(decoded)


def _path_token(value, name):
    path = str(Path(value).expanduser().resolve())
    if any(character.isspace() or character in "#\"'=" for character in path):
        raise ValueError(f"{name} must be a path without whitespace or PLUMED delimiters")
    return path


def _periodic(pbc):
    if isinstance(pbc, bool):
        return pbc
    flags = tuple(pbc)
    if len(flags) != 3 or any(value not in (True, False) for value in flags):
        raise ValueError("PBC must be a boolean or three boolean flags")
    if any(flags) and not all(flags):
        raise ValueError("PLUMED requires full 3D periodicity or a nonperiodic system")
    return all(flags)


def _format(value):
    return format(float(value), ".17g")


def _label(value):
    if (not isinstance(value, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value)
            or value.startswith("nb_")):
        raise ValueError("Generated labels must be identifiers outside the reserved 'nb_' prefix")
    return value


def _structured_options(config, cvs):
    """Reject active scalar controls that disagree with explicit CV definitions."""
    if config.plumed_file is not None or config.input_lines is not None:
        raise ValueError("Structured cvs cannot be combined with custom PLUMED input")
    for name in ("calc_rct", "grid_auto"):
        if getattr(config, name) is not None and not isinstance(getattr(config, name), bool):
            raise ValueError(f"{name} must be True, False, or None")
    if config.grid_auto:
        raise ValueError("grid_auto cannot be True with structured cvs; use grid-free CVs or explicit per-CV grids")
    if config.grid_max is not None or config.grid_bins is not None or config.grid_min != 0.0:
        raise ValueError("Put grid_min, grid_max and grid_bins in each structured CV, not the scalar config")
    first = cvs[0]
    for name, default, expected in (("cv", "DISTANCE", first["type"]),
                                    ("cv_label", "cv", first["label"]),
                                    ("atoms", (1, 2), tuple(first["atoms"])),
                                    ("sigma", 0.02, first["sigma"])):
        actual = getattr(config, name)
        if name == "atoms":
            actual = tuple(actual)
        if actual != default and actual != expected:
            raise ValueError(f"Scalar {name} conflicts with the first structured CV; configure it in cvs")
    labels = [cv["label"] for cv in cvs]
    ordered = ",".join(labels)
    if config.metad_arg not in (None, ordered):
        raise ValueError("metad_arg must match the ordered structured CV labels")
    metad_label = _label(config.metad_label)
    active_labels = [*labels, metad_label]
    if config.wall_type is not None:
        active_labels.append(_label(config.wall_label))
    if len(set(active_labels)) != len(active_labels):
        raise ValueError("Generated CV, metadynamics and wall labels must be distinct")
    has_grid = first["grid_bins"] is not None
    if config.calc_rct is True and not has_grid:
        raise ValueError("calc_rct=True requires explicit per-CV grids; leave calc_rct unset for grid-free metadynamics")
    return labels, metad_label, has_grid and config.calc_rct is not False


def _wall_line(config, labels):
    if config.wall_type is None:
        if config.wall_arg is not None:
            raise ValueError("wall_arg requires an enabled wall_type")
        return None
    if not isinstance(config.wall_type, str) or config.wall_type.upper() not in ("UPPER_WALLS", "LOWER_WALLS"):
        raise ValueError("wall_type must be UPPER_WALLS or LOWER_WALLS")
    argument = config.wall_arg
    if argument is None:
        if len(labels) != 1:
            raise ValueError("A wall on two structured CVs requires wall_arg selecting one CV")
        argument = labels[0]
    if argument not in labels:
        raise ValueError("wall_arg must select exactly one of the structured CV labels")
    values = {name: _real(getattr(config, "wall_" + name), "wall_" + name,
                         positive=name in {"kappa", "exp", "eps"})
              for name in ("at", "kappa", "exp", "eps", "offset")}
    return (f"{config.wall_label}: {config.wall_type.upper()} ARG={argument} "
            + " ".join(f"{name.upper()}={_format(value)}" for name, value in values.items()))


def _print_columns(config, labels, metad_label, calc_rct, wall, pause):
    columns = [*labels, f"{metad_label}.bias"]
    if wall:
        columns.append(f"{config.wall_label}.bias")
    if calc_rct:
        columns.extend([f"{metad_label}.rbias", f"{metad_label}.rct"])
    if pause:
        columns.append(HIT_LABEL)
    if config.colvar_arg is None:
        return columns
    if not isinstance(config.colvar_arg, str) or not config.colvar_arg:
        raise ValueError("colvar_arg must select at least one available PRINT column")
    available = set(columns) | {"*", f"{metad_label}.*"}
    if wall:
        available.update((f"{config.wall_label}.*", f"{config.wall_label}.force2"))
    selected = config.colvar_arg.split(",")
    unknown = [reference for reference in selected if reference not in available]
    if unknown:
        raise ValueError(f"Unavailable generated PRINT references: {unknown}")
    return selected


def _pause_lines(rule):
    def leaf_line(leaf, label):
        threshold = _format(leaf["threshold"])
        expression = (f"step(x-({threshold}))" if leaf["comparison"] == ">="
                      else f"step(({threshold})-x)")
        return f"{label}: CUSTOM ARG={leaf['cv']} FUNC={expression} PERIODIC=NO"

    if "operator" not in rule:
        return [leaf_line(rule, HIT_LABEL)]
    lines, labels, variables = [], [], []

    def expression(node):
        if "operator" not in node:
            index = len(labels)
            label, variable = f"nb_condition_{index}", f"p{index}"
            lines.append(leaf_line(node, label))
            labels.append(label)
            variables.append(variable)
            return variable
        children = [expression(child) for child in node["conditions"]]
        if node["operator"] == "all":
            return "(" + "*".join(children) + ")"
        return "(1-" + "*".join(f"(1-{child})" for child in children) + ")"

    formula = expression(rule)
    lines.append(f"{HIT_LABEL}: CUSTOM ARG={','.join(labels)} VAR={','.join(variables)} "
                 f"FUNC={formula} PERIODIC=NO")
    return lines


def build_input_lines(spec, config, atoms, md_config):
    """Generate marked joint METAD input while retaining native output controls."""
    from ._mlmd_io import output_path

    spec = _canonical_spec(spec, len(atoms))
    cvs = spec["cvs"]
    labels, metad_label, calc_rct = _structured_options(config, cvs)
    wall = _wall_line(config, labels)
    columns = _print_columns(config, labels, metad_label, calc_rct, wall is not None,
                             spec["stop_rule"] is not None)
    pace = _integer(config.pace, "METAD pace")
    stride = _integer(config.colvar_stride, "COLVAR stride")
    height = _real(config.height_kj_mol, "METAD height", positive=True)
    factor = _real(config.biasfactor, "METAD biasfactor", positive=True)
    temperature = md_config.temperature_K if config.temperature_K is None else config.temperature_K
    temperature = _real(temperature, "METAD temperature", positive=True)
    if factor <= 1:
        raise ValueError("Well-tempered METAD biasfactor must exceed one")
    hills, colvar = _path_token(config.hills_file, "HILLS"), _path_token(config.colvar_file, "COLVAR")
    if hills == colvar:
        raise ValueError("HILLS and COLVAR must have different paths")
    suffix = "" if _periodic(atoms.pbc) else " NOPBC"
    lines = [marker_line(spec)]
    for cv in cvs:
        lines.append(f"{cv['label']}: {cv['type']} ATOMS={','.join(map(str, cv['atoms']))}{suffix}")
    if wall is not None:
        lines.append(wall)
    rule = spec["stop_rule"]
    if rule is not None:
        lines.extend(_pause_lines(rule))
        lines.append(f"UPDATE_IF ARG={HIT_LABEL} LESS_THAN=0.5")
    fields = [f"{metad_label}: METAD ARG={','.join(labels)}", f"PACE={pace}", f"HEIGHT={_format(height)}",
              "SIGMA=" + ",".join(_format(cv["sigma"]) for cv in cvs),
              f"BIASFACTOR={_format(factor)}", f"TEMP={_format(temperature)}", f"FILE={hills}"]
    if cvs[0]["grid_bins"] is not None:
        for key, field in (("grid_min", "GRID_MIN"), ("grid_max", "GRID_MAX")):
            values = []
            for cv in cvs:
                value = ("-pi" if key == "grid_min" else "pi") if cv["type"] == "TORSION" else _format(cv[key])
                values.append(value)
            fields.append(field + "=" + ",".join(values))
        fields.append("GRID_BIN=" + ",".join(str(cv["grid_bins"]) for cv in cvs))
    if calc_rct:
        fields.append("CALC_RCT")
    lines.append(" ".join(fields))
    if rule is not None:
        lines.append(f"UPDATE_IF ARG={HIT_LABEL} END")
    lines.append(f"PRINT ARG={','.join(columns)} STRIDE={stride} FILE={colvar}")
    output_path(config.hills_file, overwrite=md_config.overwrite)
    output_path(config.colvar_file, overwrite=md_config.overwrite)
    return lines
