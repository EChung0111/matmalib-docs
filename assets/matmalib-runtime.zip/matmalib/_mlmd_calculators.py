"""AIMNet ensemble construction; no models are loaded at import time."""

from os import PathLike
import os
from pathlib import Path
import re

import numpy as np
from ase.calculators.calculator import Calculator, all_changes
from ase.stress import full_3x3_to_voigt_6_stress

DEFAULT_MODELS = tuple(f"aimnet2-b973c-2025-d3_{i}" for i in range(4))
_MODEL_FAMILIES = {
    "aimnet2": "aimnet2-wb97m-d3", "aimnet2-wb97m": "aimnet2-wb97m-d3",
    "aimnet2-wb97m-d3": "aimnet2-wb97m-d3", "aimnet2-b973c": "aimnet2-b973c-d3",
    "aimnet2-b973c-d3": "aimnet2-b973c-d3", "aimnet2-2025": "aimnet2-b973c-2025-d3",
    "aimnet2-2025-b973c-d3": "aimnet2-b973c-2025-d3",
    "aimnet2-b973c-2025-d3": "aimnet2-b973c-2025-d3",
    "aimnet2-nse": "aimnet2-nse", "aimnet2-pd": "aimnet2-pd", "aimnet2-rxn": "aimnet2-rxn",
}


def _local_model(value):
    path = Path(value).expanduser()
    if path.is_file():
        return str(path.resolve())
    if path.parent != Path('.'):
        return None
    names = [path.name, path.name + ".pt"]
    for name in list(names):
        names.extend((name.replace('-', '_'), name.replace('_', '-')))
    member = re.fullmatch(r"aimnet2-b973c-2025-d3_([0-3])", path.name)
    if member:
        names.append(f"aimnet2_2025_b973c_d3_{member[1]}.pt")
    names = list(dict.fromkeys(names))
    normalized = {name.lower().replace('-', '_') for name in names}
    for directory in (Path.cwd(), Path.cwd() / "checkpoints"):
        if directory.is_dir():
            for name in names:
                candidate = directory / name
                if candidate.is_file():
                    return str(candidate.resolve())
            for candidate in sorted(directory.iterdir()):
                if candidate.is_file() and candidate.name.lower().replace('-', '_') in normalized:
                    return str(candidate.resolve())
    return None


def resolve_models(model_path):
    if model_path is None:
        return [_local_model(name) or name for name in DEFAULT_MODELS]
    paths = [model_path] if isinstance(model_path, (str, PathLike)) else list(model_path)
    if not paths:
        raise ValueError("model_path must contain at least one inference file.")
    resolved = []
    for value in paths:
        path = Path(value).expanduser()
        local = _local_model(path)
        if local is not None:
            resolved.append(local)
            continue
        if isinstance(value, PathLike) or path.suffix or path.parent != Path('.'):
            raise FileNotFoundError(f"MLIP inference file does not exist: {path}")
        name = path.name.lower().replace('_', '-')
        if path.parent == Path('.') and name in _MODEL_FAMILIES:
            resolved.extend(_local_model(member) or member
                            for member in (f"{_MODEL_FAMILIES[name]}_{i}" for i in range(4)))
            continue
        family, _, index = name.rpartition('-')
        if path.parent == Path('.') and family in _MODEL_FAMILIES and index in ('0', '1', '2', '3'):
            member = f"{_MODEL_FAMILIES[family]}_{index}"
            resolved.append(_local_model(member) or member)
            continue
        raise FileNotFoundError(f"MLIP inference file or known AIMNet model alias does not exist: {path}")
    return resolved


class EnsembleCalculator(Calculator):
    implemented_properties = ["energy", "free_energy", "forces", "stress"]

    def __init__(self, calculators):
        super().__init__()
        if not calculators:
            raise ValueError("An ensemble requires at least one calculator.")
        self.calculators = calculators

    def calculate(self, atoms=None, properties=None, system_changes=all_changes):
        super().calculate(atoms, properties, system_changes)
        energies, forces, stresses = [], [], []
        for calc in self.calculators:
            # Stress-first combines all derivatives in one AIMNet evaluation.
            if "stress" in (properties or ()):
                stress = np.asarray(calc.get_stress(self.atoms))
                stresses.append(full_3x3_to_voigt_6_stress(stress) if stress.shape == (3, 3) else stress)
            forces.append(calc.get_forces(self.atoms))
            energies.append(calc.get_potential_energy(self.atoms))
        energy = float(np.mean(energies))
        self.results = {"energy": energy, "free_energy": energy,
                        "forces": np.mean(forces, axis=0),
                        "energy_std": float(np.std(energies)),
                        "forces_std": np.std(forces, axis=0)}
        if stresses:
            self.results["stress"] = np.mean(stresses, axis=0)


def build_calculator(model_path, *, charge, mult, device, compile_model, model_kwargs):
    if compile_model:
        for flag in ("TORCH_COMPILE_DISABLE", "TORCH_DISABLE_NATIVE_JIT"):
            if os.environ.get(flag) == "1":
                raise ValueError(f"Model compilation requested but {flag}=1; set {flag}=0.")
    models = resolve_models(model_path)
    try:
        from aimnet.calculators import AIMNet2ASE, AIMNet2Calculator
    except ImportError as exc:
        raise ImportError("AIMNet simulations require: pip install 'matmalib[aimnet]'.") from exc

    class CachedAIMNet(AIMNet2ASE):
        def calculate(self, atoms=None, properties=None, system_changes=all_changes):
            requested = list(dict.fromkeys([*(properties or ()), "energy", "forces"]))
            super().calculate(atoms, requested, system_changes)
            self.results.setdefault("free_energy", self.results["energy"])

    reserved = {"device", "compile_model"}.intersection(model_kwargs)
    if reserved:
        raise ValueError(f"Pass {sorted(reserved)} directly to mlmd, not model_kwargs.")
    calculators, devices = [], []
    for path in models:
        model = AIMNet2Calculator(path, device=device, compile_model=compile_model, **model_kwargs)
        calculators.append(CachedAIMNet(model, charge=charge, mult=mult))
        devices.append(str(getattr(model, "device", device)))
    result = calculators[0] if len(calculators) == 1 else EnsembleCalculator(calculators)
    result.mlmd_metadata = dict(model_paths=models, model_count=len(models), devices=devices,
                                compile_model=bool(compile_model), charge=charge, multiplicity=mult)
    return result
