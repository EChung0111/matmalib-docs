"""Scientific analysis adapted from Aimnet/analyze_metadynamics.py.

One-dimensional FES, normalized COLVAR reweighting, basin thermodynamics,
and infrequent-metadynamics kinetics retain the original script semantics.
"""


import argparse


from dataclasses import dataclass, field


from datetime import datetime


import json


import math


import os


from pathlib import Path


import re


import shlex


import shutil


import subprocess


import sys


import tempfile


import numpy as np


R = 0.00831446261815324  # kJ mol^-1 K^-1


KB = 1.380649e-23  # J K^-1, exact


H = 6.62607015e-34  # J s, exact


ENERGY_TO_KJ = {"kJ/mol": 1.0, "kcal/mol": 4.184, "eV": 96.48533212331002}


TIME_TO_S = {"fs": 1e-15, "ps": 1e-12, "ns": 1e-9, "s": 1.0}


def read_plumed_actions(path):
    """Read the common single-line / ACTION ... block input syntax, not a preprocessor."""
    actions, pending = [], None
    with open(path) as stream:
        for number, line in enumerate(stream, 1):
            tokens = shlex.split(line, comments=True)
            if not tokens:
                continue
            if tokens[0] == "...":
                if pending is None:
                    raise ValueError(f"{path}:{number}: unexpected block terminator")
                if len(tokens) > 2 or (len(tokens) == 2 and tokens[1] != pending[0]):
                    raise ValueError(f"{path}:{number}: mismatched block terminator")
                actions.append(pending)
                pending = None
                continue
            if pending is not None:
                if "..." in tokens:
                    raise ValueError(f"{path}:{number}: nested PLUMED blocks are unsupported")
                pending.extend(tokens)
                continue
            label = None
            if tokens[0].endswith(":"):
                label = tokens.pop(0)[:-1]
            if not tokens:
                raise ValueError(f"{path}:{number}: missing action after label")
            block = tokens[-1] == "..."
            if block:
                tokens.pop()
            if label is not None:
                tokens.append(f"LABEL={label}")
            if block:
                pending = tokens
            else:
                actions.append(tokens)
    if pending is not None:
        raise ValueError(f"{path}: unterminated {pending[0]} block")
    parsed = []
    for tokens in actions:
        parameters = {}
        for token in tokens[1:]:
            key, separator, value = token.partition("=")
            if key in parameters:
                raise ValueError(f"{path}: duplicate {key} in {tokens[0]}")
            parameters[key] = value if separator else True
        if tokens[0] == "INCLUDE":
            raise ValueError("--plumed-input does not expand INCLUDE; supply a flattened input file")
        parsed.append({"action": tokens[0], "parameters": parameters})
    return parsed


def plumed_unit(value, choices, option):
    """Map named or equivalent numeric PLUMED units to the supported CLI units."""
    aliases = {"kj/mol": "kJ/mol"}
    value = aliases.get(value, value)
    if value in choices:
        return value
    try:
        factor = float(value)
    except (TypeError, ValueError):
        factor = math.nan
    for name, conversion in choices.items():
        if math.isclose(factor, conversion, rel_tol=1e-8, abs_tol=0):
            return name
    raise ValueError(f"Unsupported PLUMED unit {value!r}; supply {option} for the actual data units")


def apply_plumed_defaults(args):
    """Resolve opt-in input defaults without changing explicitly supplied CLI values."""
    config = None
    if args.plumed_input:
        path = Path(args.plumed_input).resolve()
        actions = read_plumed_actions(path)
        metads = [a["parameters"] for a in actions if a["action"] == "METAD"]
        if len(metads) != 1:
            raise ValueError("--plumed-input requires exactly one METAD action")
        metad = metads[0]
        cv = metad.get("ARG", "")
        if not isinstance(cv, str) or not re.fullmatch(r"[A-Za-z_][\w.]*", cv):
            raise ValueError("--plumed-input requires one explicit CV in METAD ARG (no lists or wildcards)")
        args.cv = args.cv or cv
        if args.temperature is None and "TEMP" in metad:
            args.temperature = float(metad["TEMP"])
        unit_actions = [a["parameters"] for a in actions if a["action"] == "UNITS"]
        if len(unit_actions) > 1 or any(u.get("NATURAL") for u in unit_actions):
            raise ValueError("Multiple UNITS actions and natural units are unsupported")
        units = {"ENERGY": "kj/mol", "LENGTH": "nm", "TIME": "ps"}
        if unit_actions:
            units.update(unit_actions[0])
        if args.energy_unit is None:
            args.energy_unit = plumed_unit(units["ENERGY"], ENERGY_TO_KJ, "--energy-unit")
        walls = [a for a in actions if a["action"] in ("UPPER_WALLS", "LOWER_WALLS")]
        config = {"file": str(path), "metadynamics": metad, "units": units, "walls": walls}
        if args.cv_unit is None:
            definitions = [a for a in actions if a["parameters"].get("LABEL") == args.cv.split(".")[0]]
            kind = definitions[0]["action"] if len(definitions) == 1 else None
            if kind == "DISTANCE":
                args.cv_unit = str(units["LENGTH"])
            elif kind in ("ANGLE", "TORSION"):
                args.cv_unit = "rad"
        if args.hills and args.upper_wall is None and not args.keep_wall:
            relevant = [w["parameters"] for w in walls
                        if w["action"] == "UPPER_WALLS"
                        and args.cv in str(w["parameters"].get("ARG", "")).split(",")]
            if len(relevant) > 1:
                raise ValueError("Multiple upper walls need an explicit --upper-wall correction or --keep-wall")
            if relevant:
                wall = relevant[0]
                if wall["ARG"] != args.cv or float(wall.get("EXP", 2)) != 2:
                    raise ValueError("Automatic wall removal requires a single-CV quadratic UPPER_WALLS; "
                                     "use --keep-wall to retain it")
                if "AT" not in wall or "KAPPA" not in wall:
                    raise ValueError("UPPER_WALLS requires AT and KAPPA")
                eps, offset = float(wall.get("EPS", 1)), float(wall.get("OFFSET", 0))
                if not math.isfinite(eps) or eps <= 0 or not math.isfinite(offset):
                    raise ValueError("UPPER_WALLS needs positive finite EPS and finite OFFSET")
                args.upper_wall = [float(wall["AT"]) - offset, float(wall["KAPPA"]) / eps**2]
        if args.time_unit is None:
            args.time_unit = plumed_unit(units["TIME"], {k: v / 1e-12 for k, v in TIME_TO_S.items()},
                                        "--time-unit")
        needs_colvar = not args.colvar and (args.infrequent or not (args.hills or args.fes_file))
        if needs_colvar:
            prints = [a["parameters"] for a in actions if a["action"] == "PRINT"
                      and args.cv in str(a["parameters"].get("ARG", "")).split(",")
                      and "FILE" in a["parameters"]]
            if len(prints) != 1:
                raise ValueError("Supply --colvar: no unique PRINT FILE for the selected CV")
            colvar = str(path.parent / prints[0]["FILE"])
            args.colvar = [colvar]
    missing = [name for name in ("cv", "temperature") if getattr(args, name) is None]
    if missing:
        raise ValueError("Supply " + ", ".join("--" + name for name in missing) + " or --plumed-input")
    args.energy_unit = args.energy_unit or "kJ/mol"
    args.cv_unit = args.cv_unit or "input units"
    args.time_unit = args.time_unit or "ps"
    if not any((args.hills, args.colvar, args.fes_file)):
        raise ValueError("Supply --hills, --colvar, --fes-file or --plumed-input")
    if args.infrequent and not args.colvar:
        raise ValueError("Infrequent kinetics needs --colvar or --plumed-input")
    return config


def infer_bias_columns(args, config, tables, kinetics=False):
    """Use actual output columns, so input flags alone cannot promise missing data."""
    fields = set.intersection(*(set(table.fields) for table in tables))
    label = config["metadynamics"].get("LABEL") if config else None
    if not label:
        labels = {field.rsplit(".", 1)[0] for field in fields
                  if field.endswith((".rbias", ".rct", ".acc"))}
        if len(labels) == 1:
            label = labels.pop()
    if label:
        if kinetics:
            if not args.bias_column and not args.acceleration_column:
                if f"{label}.acc" in fields:
                    args.acceleration_column = f"{label}.acc"
                elif f"{label}.bias" in fields:
                    args.bias_column = f"{label}.bias"
        elif not args.rbias_column:
            if (not args.rct_column and args.bias_column in (None, f"{label}.bias")
                    and f"{label}.rbias" in fields):
                args.rbias_column = f"{label}.rbias"
            elif ({f"{label}.bias", f"{label}.rct"} <= fields
                  and args.bias_column in (None, f"{label}.bias")
                  and args.rct_column in (None, f"{label}.rct")):
                args.bias_column = args.bias_column or f"{label}.bias"
                args.rct_column = args.rct_column or f"{label}.rct"
    if config:
        for wall in config["walls"]:
            wall_label = wall["parameters"].get("LABEL")
            if kinetics:
                if not wall_label or f"{wall_label}.bias" not in fields:
                    raise ValueError("Record every wall's .bias column to check whether it is active before first passage")
        if not kinetics and args.additional_bias is None and not args.keep_wall:
            args.additional_bias = []
            for wall in config["walls"]:
                label = wall["parameters"].get("LABEL")
                if not label or f"{label}.bias" not in fields:
                    raise ValueError("Wall removal needs its .bias column in COLVAR; use --hills or --keep-wall")
                args.additional_bias.append(f"{label}.bias")
    if kinetics and not (args.bias_column or args.acceleration_column):
        raise ValueError("Supply --bias-column or --acceleration-column; no suitable column could be inferred")


@dataclass
class Table:
    fields: list[str]
    values: np.ndarray
    metadata: dict[str, str]
    warnings: list[str] = field(default_factory=list)

    def column(self, name, finite=True):
        if name not in self.fields:
            raise ValueError(f"Missing column {name!r}; available: {', '.join(self.fields)}")
        result = self.values[:, self.fields.index(name)]
        if finite and not np.isfinite(result).all():
            raise ValueError(f"Column {name!r} contains NaN or infinite values")
        return result


def read_plumed(path, *, allow_incomplete_tail=False):
    """Read a snapshot, optionally omitting an unterminated final COLVAR line.

    Even a row with the expected number of numeric fields may end in a partly
    written value, so the newline is required when allow_incomplete_tail is set.
    Other inputs stay strict; schema changes and malformed completed rows fail.
    """
    fields, metadata, rows, warnings = None, {}, [], []
    with open(path) as stream:
        lines = stream.read().splitlines(keepends=True)
    for number, line in enumerate(lines, 1):
        if allow_incomplete_tail and number == len(lines) and not line.endswith("\n"):
            if line.strip():
                warnings.append(f"{path}:{number}: ignored unfinished final line (no newline); "
                                "the file may still be being written. Only complete rows were analyzed.")
            continue
        parts = line.split()
        if not parts:
            continue
        if parts[:2] == ["#!", "FIELDS"]:
            new_fields = parts[2:]
            if not new_fields or len(set(new_fields)) != len(new_fields):
                raise ValueError(f"{path}:{number}: invalid FIELDS header")
            if fields is not None and new_fields != fields:
                raise ValueError(f"{path}:{number}: FIELDS changed across a restart")
            fields = new_fields
        elif parts[:2] == ["#!", "SET"] and len(parts) >= 4:
            metadata[parts[2]] = " ".join(parts[3:])
        elif parts[0].startswith("#"):
            continue
        else:
            if fields is None:
                raise ValueError(f"{path}:{number}: missing #! FIELDS header before data")
            if len(parts) != len(fields):
                raise ValueError(f"{path}:{number}: incomplete or malformed row: "
                                 f"expected {len(fields)} columns, found {len(parts)}")
            try:
                rows.append([float(x) for x in parts])
            except ValueError as exc:
                raise ValueError(f"{path}:{number}: nonnumeric data") from exc
    if not rows:
        raise ValueError(f"{path}: no data rows")
    return Table(fields, np.asarray(rows), metadata, warnings)


def logsumexp(values):
    values = np.asarray(values, dtype=float)
    maximum = np.max(values)
    if maximum == -np.inf:
        return float(maximum)
    return float(maximum + np.log(np.exp(values - maximum).sum()))


def exp_or_none(value):
    return math.exp(value) if -745 < value < 709 else None


def validate_states(reactant, product):
    for name, bounds in (("reactant", reactant), ("product", product)):
        if len(bounds) != 2 or not np.isfinite(bounds).all() or bounds[0] >= bounds[1]:
            raise ValueError(f"{name} needs finite limits LOW < HIGH")
    if max(reactant[0], product[0]) <= min(reactant[1], product[1]):
        raise ValueError("Reactant and product intervals must be disjoint, with a gap")


def ordered_times(table):
    times = table.column("time")
    if len(times) < 2 or np.any(np.diff(times) <= 0):
        raise ValueError("Time must increase strictly; split restarts/replicas into separate files")
    return times


@dataclass
class Profile:
    x: np.ndarray
    free_energy: np.ndarray  # kJ/mol; +inf denotes unsampled histogram bins
    edges: np.ndarray | None = None

    def basin_log_mass(self, bounds, rt):
        if self.edges is not None:
            low, high = self.edges[0], self.edges[-1]
            widths = np.maximum(0.0, np.minimum(self.edges[1:], bounds[1])
                                - np.maximum(self.edges[:-1], bounds[0]))
            selected = widths > 0
            terms = np.log(widths[selected]) - self.free_energy[selected] / rt
        else:
            low, high = self.x[0], self.x[-1]
            x = np.r_[bounds[0], self.x[(self.x > bounds[0]) & (self.x < bounds[1])], bounds[1]]
            f = np.interp(x, self.x, self.free_energy)
            terms = np.log(np.diff(x) / 2) + np.logaddexp(-f[:-1] / rt, -f[1:] / rt)
        if bounds[0] < low or bounds[1] > high:
            raise ValueError(f"Basin {bounds} extends beyond profile range [{low}, {high}]")
        mass = logsumexp(terms) if len(terms) else -np.inf
        if not np.isfinite(mass):
            raise ValueError(f"Basin {bounds} has no sampled probability")
        return mass


def load_profile(table, cv, energy_column, energy_factor):
    if table.metadata.get(f"periodic_{cv}", "false").lower() == "true":
        raise ValueError("Periodic FES grids are unsupported; unwrap a chosen reaction path first")
    x = table.column(cv)
    f = table.column(energy_column) * energy_factor
    order = np.argsort(x)
    x, f = x[order], f[order]
    if len(x) < 3 or np.any(np.diff(x) <= 0):
        raise ValueError("Expected a one-dimensional grid with unique CV values; marginalize 2D grids first")
    return Profile(x, f - f.min())


def reweighted_profile(table, cv, temperature, bins=100, grid_range=None,
                       rbias_column=None, bias_column=None, rct_column=None,
                       additional_bias=(), energy_factor=1.0, start_time=None, end_time=None):
    times = ordered_times(table)
    mask = np.ones(len(times), dtype=bool)
    if start_time is not None:
        mask &= times >= start_time
    if end_time is not None:
        mask &= times <= end_time
    times = times[mask]
    if len(times) < 2:
        raise ValueError("Time selection contains fewer than two samples")
    if not np.allclose(np.diff(times), np.median(np.diff(times)), rtol=1e-4, atol=1e-12):
        raise ValueError("FES histograms require regularly sampled COLVAR data")
    if rbias_column:
        bias = table.column(rbias_column)[mask].copy()
    elif bias_column and rct_column:
        bias = table.column(bias_column)[mask] - table.column(rct_column)[mask]
    else:
        raise ValueError("COLVAR FES needs --rbias-column or both --bias-column and --rct-column; "
                         "raw metad.bias alone is insufficient. For future runs enable METAD CALC_RCT "
                         "with GRID_MIN/GRID_MAX and PRINT metad.rbias. "
                         "Older runs can recover c(t) with --plumed-input, matching HILLS and grid bounds. "
                         "For existing runs set AnalysisConfig.hills.")
    for name in additional_bias:
        bias += table.column(name)[mask]
    x = table.column(cv)[mask]
    logw = bias * energy_factor / (R * temperature)
    # Normalize within each bin in log space: a remote high-weight frame must
    # not underflow the probability of a well-sampled, low-weight basin to zero.
    _, edges = np.histogram(x, bins=bins, range=grid_range)
    index = np.searchsorted(edges, x, side="right") - 1
    index[x == edges[-1]] = bins - 1
    log_mass = np.full(bins, -np.inf)
    counts = np.zeros(bins, dtype=int)
    for i in range(bins):
        chosen = index == i
        counts[i] = chosen.sum()
        if counts[i]:
            log_mass[i] = logsumexp(logw[chosen])
    f = -(R * temperature) * (log_mass - np.log(np.diff(edges)))
    if not np.isfinite(f).any():
        raise ValueError("No samples lie in the requested grid range")
    f -= f[np.isfinite(f)].min()
    log_ess = 2 * logsumexp(logw) - logsumexp(2 * logw)
    details = {"samples": len(x), "start_time": float(times[0]), "end_time": float(times[-1]),
               "weight_effective_sample_size": float(np.exp(log_ess)),
               "empty_bins": int((counts == 0).sum()),
               "samples_outside_grid": int(((index < 0) | (index >= bins)).sum()),
               "effective_sample_size_note": "Weight diagnostic only; does not correct time correlation."}
    return Profile((edges[:-1] + edges[1:]) / 2, f, edges), details


def eyring_rate(barrier_kj_mol, temperature, kappa=1.0):
    log_rate = math.log(kappa * KB * temperature / H) - barrier_kj_mol / (R * temperature)
    return {"rate_s_inv": exp_or_none(log_rate), "log_rate_s_inv": log_rate}


def analyze_basins(profile, temperature, reactant, product, eyring=False, kappa=1.0):
    validate_states(reactant, product)
    rt = R * temperature
    masses = [profile.basin_log_mass(bounds, rt) for bounds in (reactant, product)]
    delta_g = -rt * (masses[1] - masses[0])
    result = {"delta_g_product_minus_reactant_kj_mol": delta_g,
              "delta_g_product_minus_reactant_kcal_mol": delta_g / 4.184,
              "delta_g_definition": "-RT ln(integrated product probability / integrated reactant probability)",
              "log_population_ratio_product_over_reactant": masses[1] - masses[0],
              "reactant_range": list(reactant), "product_range": list(product),
              "warnings": []}
    minima = []
    for name, bounds in (("reactant", reactant), ("product", product)):
        indices = np.flatnonzero((profile.x >= bounds[0]) & (profile.x <= bounds[1])
                                 & np.isfinite(profile.free_energy))
        if not len(indices):
            raise ValueError(f"No finite grid point in {name} basin; use a finer grid")
        idx = int(indices[np.argmin(profile.free_energy[indices])])
        minima.append(idx)
        result[f"{name}_minimum_cv"] = float(profile.x[idx])
        if idx in (indices[0], indices[-1]):
            result["warnings"].append(f"{name} minimum touches a basin grid boundary; inspect the basin limits.")
    lo, hi = sorted(minima)
    segment = profile.free_energy[lo:hi + 1]
    if not np.isfinite(segment).all():
        result["warnings"].append("Unsampled bins between minima: barrier and Eyring rate are unresolved. "
                                  "No pseudocount or interpolation was used to invent a barrier.")
        return result
    peak = lo + int(np.argmax(segment))
    if peak in (lo, hi):
        result["warnings"].append("No interior barrier is resolved between the two basin minima.")
        return result
    result["transition_state_cv"] = float(profile.x[peak])
    result["barrier_definition"] = "Projected CV-profile peak minus basin minimum; not a standard activation free energy."
    for direction, idx in (("forward", minima[0]), ("reverse", minima[1])):
        barrier = float(profile.free_energy[peak] - profile.free_energy[idx])
        result[f"delta_g_dagger_{direction}_projected_kj_mol"] = barrier
        result[f"delta_g_dagger_{direction}_projected_kcal_mol"] = barrier / 4.184
        if eyring:
            result[f"eyring_proxy_{direction}"] = eyring_rate(barrier, temperature, kappa)
    if eyring:
        result["warnings"].append("Eyring proxy assumes the projected barrier is an activation free energy; "
                                  "it is not a recovered dynamical rate. Basin-integrated Delta G and "
                                  "minimum-based barriers need not imply the same equilibrium constant.")
    return result


def infer_basins(profile, temperature):
    """Split at the strongest two-sided barrier, requiring a depth of at least RT.

    This is a geometric heuristic, not a chemical state assignment. Use raw
    values, and never bridge unsampled bins or let plot smoothing affect it.
    """
    f, x = profile.free_energy, profile.x
    boundaries = np.flatnonzero(np.diff(np.r_[False, np.isfinite(f), False]))
    best = None
    for start, stop in zip(boundaries[::2], boundaries[1::2]):
        for peak in range(start + 1, stop - 1):
            left = start + int(np.argmin(f[start:peak]))
            right = peak + 1 + int(np.argmin(f[peak + 1:stop]))
            depth = min(f[peak] - f[left], f[peak] - f[right])
            if depth >= R * temperature and (best is None or depth > best[0]):
                best = (float(depth), start, stop, peak)
    if best is None:
        return None
    depth, start, stop, peak = best
    lower = profile.edges[start] if profile.edges is not None else x[start]
    upper = profile.edges[stop] if profile.edges is not None else x[stop - 1]
    return {"reactant": [float(lower), float((x[peak - 1] + x[peak]) / 2)],
            "product": [float((x[peak] + x[peak + 1]) / 2), float(upper)],
            "method": "Largest minimum-to-peak depth on both sides within a sampled segment",
            "minimum_depth_kj_mol": R * temperature, "resolved_depth_kj_mol": depth,
            "direction": "Lower-CV basin assigned as reactant; higher-CV basin as product"}


def plumed_command_environment(plumed=None):
    """Find PLUMED and its shared libraries in the active environment."""
    sibling = Path(sys.executable).parent / "plumed"
    executable = plumed or (str(sibling) if sibling.is_file() else shutil.which("plumed"))
    if executable is None:
        raise ValueError("PLUMED executable not found; supply --plumed /path/to/plumed or --fes-file")
    env = os.environ.copy()
    resolved = shutil.which(str(executable)) or str(executable)
    lib = Path(resolved).resolve().parent.parent / "lib"
    if lib.is_dir():
        env["LD_LIBRARY_PATH"] = str(lib) + (os.pathsep + env["LD_LIBRARY_PATH"] if env.get("LD_LIBRARY_PATH") else "")
    return str(executable), env


def recover_colvar_bias(table, args, config, energy_factor):
    """Recover missing c(t) from validated cumulative WTMetaD bias grids.

    Use PLUMED for kernel evaluation and WT height scaling. The normalization
    follows MetaD::computeReweightingFactor (uniform-grid sums), and a hill
    deposited at t is excluded from the sample at t, as in MetaD::calculate.
    The recorded raw bias remains the source for frame weights.
    """
    if args.rbias_column or args.rct_column or not config:
        return table, None
    metad = config["metadynamics"]
    label = metad.get("LABEL")
    raw_column = args.bias_column or (f"{label}.bias" if label else None)
    if raw_column not in table.fields:
        return table, None
    hills_path = Path(config["file"]).parent / metad.get("FILE", "HILLS")
    if not hills_path.is_file():
        return table, None
    if not all(key in metad for key in ("GRID_MIN", "GRID_MAX")):
        raise ValueError("Recovering missing COLVAR c(t) requires explicit METAD GRID_MIN/GRID_MAX "
                         "in plumed.dat, covering the full sampled CV range")
    unsupported = {"INTERVAL", "ADAPTIVE", "TARGET", "RECT", "DAMPFACTOR", "FLYING_GAUSSIAN"}
    if any(key in unsupported or key.startswith("WALKERS") for key in metad):
        raise ValueError("Automatic c(t) recovery supports only single-walker, fixed-width WTMetaD")
    bounds = np.array([float(metad[key]) for key in ("GRID_MIN", "GRID_MAX")])
    if not np.isfinite(bounds).all() or bounds[0] >= bounds[1]:
        raise ValueError("Recovering c(t) requires finite GRID_MIN < GRID_MAX")
    times, cv_values = ordered_times(table), table.column(args.cv)
    if cv_values.min() < bounds[0] or cv_values.max() > bounds[1]:
        raise ValueError("METAD GRID_MIN/GRID_MAX must cover all COLVAR samples to recover c(t)")
    executable, env = plumed_command_environment(args.plumed)
    with tempfile.TemporaryDirectory(prefix="metad-recover-bias-") as tmp:
        directory = Path(tmp)
        snapshot = directory / "HILLS"
        snapshot.write_bytes(hills_path.read_bytes())
        hills = read_plumed(snapshot)
        cvs = [field[6:] for field in hills.fields if field.startswith("sigma_")]
        if (cvs != [args.cv] or hills.metadata.get("multivariate", "false") != "false"
                or hills.metadata.get(f"periodic_{args.cv}", "false").lower() == "true"):
            raise ValueError("Automatic c(t) recovery requires nonperiodic, one-dimensional HILLS")
        if not np.isfinite(hills.values).all():
            raise ValueError("HILLS contains nonfinite data")
        hill_times = hills.column("time")
        sigma = hills.column(f"sigma_{args.cv}")
        gamma = hills.column("biasf")[0]
        if (gamma <= 1 or not np.allclose(hills.column("biasf"), gamma)
                or not math.isclose(float(metad.get("BIASFACTOR", gamma)), gamma)):
            raise ValueError("Recovering c(t) requires one constant BIASFACTOR > 1 matching HILLS")
        if np.any(sigma <= 0) or not np.allclose(sigma, sigma[0]) or np.any(hills.column("height") < 0):
            raise ValueError("Recovering c(t) requires fixed positive sigma and nonnegative hill heights")
        if np.any(np.diff(hill_times) <= 0):
            raise ValueError("HILLS time must increase strictly; merged walkers/restarts are unsupported")
        if hills.column(args.cv).min() < bounds[0] or hills.column(args.cv).max() > bounds[1]:
            raise ValueError("METAD GRID_MIN/GRID_MAX must also cover all deposited hill centers")
        # Accommodate rounding in text timestamps, while excluding the hill at t.
        time_tolerance = min(np.diff(times).min(), np.diff(hill_times).min()
                             if len(hill_times) > 1 else np.diff(times).min()) * 1e-4
        hill_counts = np.searchsorted(hill_times, times - time_tolerance, side="left")
        bins = max(int(metad.get("GRID_BIN", 0)), 200,
                   math.ceil((bounds[1] - bounds[0]) / (sigma.min() / 10)))
        command = [executable, "sum_hills", "--hills", str(snapshot), "--negbias", "--stride", "1",
                   "--outfile", "bias_", "--min", str(bounds[0]), "--max", str(bounds[1]),
                   "--bin", str(bins), "--fmt", "%.16g"]
        completed = subprocess.run(command, cwd=tmp, env=env, capture_output=True, text=True, timeout=300)
        if completed.returncode:
            raise ValueError("PLUMED bias recovery failed:\n" + (completed.stderr + completed.stdout)[-2500:])
        rt = R * args.temperature
        rct, expected_bias = np.zeros(len(times)), np.zeros(len(times))
        for count in np.unique(hill_counts[hill_counts > 0]):
            grid = read_plumed(directory / f"bias_{count - 1}.dat")
            x = grid.column(args.cv)
            bias = -grid.column("file.free") * energy_factor
            derivative = -grid.column(f"der_{args.cv}") * energy_factor
            chosen = hill_counts == count
            rct[chosen] = rt * (logsumexp(gamma * bias / ((gamma - 1) * rt))
                                - logsumexp(bias / ((gamma - 1) * rt)))
            # Cubic Hermite interpolation preserves PLUMED's grid derivatives.
            j = np.clip(np.searchsorted(x, cv_values[chosen], side="right") - 1, 0, len(x) - 2)
            dx = x[j + 1] - x[j]
            u = (cv_values[chosen] - x[j]) / dx
            expected_bias[chosen] = ((2*u**3 - 3*u**2 + 1) * bias[j]
                                     + (u**3 - 2*u**2 + u) * dx * derivative[j]
                                     + (-2*u**3 + 3*u**2) * bias[j + 1]
                                     + (u**3 - u**2) * dx * derivative[j + 1])
    recorded_bias = table.column(raw_column) * energy_factor
    error = float(np.max(np.abs(recorded_bias - expected_bias)))
    if error > 0.01:
        raise ValueError(f"HILLS/COLVAR bias mismatch ({error:.6g} kJ/mol > 0.01); "
                         "cannot recover c(t) from inconsistent or incomplete run files")
    rbias_column = raw_column.rsplit(".", 1)[0] + ".rbias"
    result = Table(table.fields + [rbias_column],
                   np.column_stack((table.values, (recorded_bias - rct) / energy_factor)),
                   table.metadata.copy(), table.warnings.copy())
    args.rbias_column, args.bias_column = rbias_column, None
    details = {"method": "c(t) from cumulative PLUMED negative-bias grids",
               "hills_file": str(hills_path.resolve()), "hills": len(hill_times),
               "biasfactor": float(gamma), "grid_range": bounds.tolist(), "grid_bins": bins,
               "max_raw_bias_error_kj_mol": error,
               "rct_range_kj_mol": [float(rct.min()), float(rct.max())]}
    return result, details


def sum_hills_profile(path, cv, temperature, energy_factor, plumed=None, bins=200, grid_range=None):
    executable, env = plumed_command_environment(plumed)
    with tempfile.TemporaryDirectory(prefix="metad-sum-hills-") as tmp:
        # Validate and reconstruct the same snapshot if the simulation is still
        # appending hills. A partially written final row is rejected by the parser.
        snapshot = Path(tmp) / "HILLS"
        snapshot.write_bytes(Path(path).read_bytes())
        table = read_plumed(snapshot)
        cvs = [field[6:] for field in table.fields if field.startswith("sigma_")]
        if cvs != [cv] or table.metadata.get("multivariate", "false") != "false":
            raise ValueError("--hills requires a one-dimensional, non-multivariate HILLS file for --cv; "
                             "use PLUMED sum_hills to marginalize other grids, then --fes-file")
        if not np.isfinite(table.values).all():
            raise ValueError("HILLS contains nonfinite data")
        if np.any(np.diff(table.column("time")) < 0):
            raise ValueError("HILLS time decreases; resolve restarts before reconstructing a profile")
        if grid_range is None:
            centers = table.column(cv)
            grid_range = [float(centers.min()), float(centers.max())]
            if grid_range[0] == grid_range[1]:
                raise ValueError("Hills cover only one CV value; more sampling is needed to infer a profile range")
        output = Path(tmp) / "fes.dat"
        command = [str(executable), "sum_hills", "--hills", str(snapshot),
                   "--outfile", str(output), "--mintozero", "--bin", str(bins), "--fmt", "%.12g",
                   "--kt", str(R * temperature / energy_factor),
                   "--min", str(grid_range[0]), "--max", str(grid_range[1])]
        completed = subprocess.run(command, cwd=tmp, env=env, capture_output=True, text=True, timeout=300)
        if completed.returncode:
            raise ValueError("PLUMED sum_hills failed:\n" + (completed.stderr + completed.stdout)[-2500:])
        # PLUMED already applies the WTMetaD scaling. Do not multiply by gamma/(gamma-1) again.
        return load_profile(read_plumed(output), cv, "file.free", energy_factor)


def first_passage(table, cv, reactant, product, temperature, time_unit="ps",
                  bias_column=None, acceleration_column=None, energy_factor=1.0):
    validate_states(reactant, product)
    t = ordered_times(table)
    x = table.column(cv)
    if abs(t[0]) > 1e-12 or not reactant[0] <= x[0] <= reactant[1]:
        raise ValueError("Each kinetic run must start at time zero in the reactant basin; "
                         "do not truncate or concatenate a biased trajectory")
    entries = np.flatnonzero((x >= product[0]) & (x <= product[1]))
    event = bool(len(entries))
    end = int(entries[0]) if event else len(t) - 1
    if bool(bias_column) == bool(acceleration_column):
        raise ValueError("Choose exactly one of --bias-column and --acceleration-column")
    # A static wall may change the escape kinetics; adding its energy to the
    # acceleration factor is not a generic correction for that effect.
    metad_bias = bias_column or acceleration_column.rsplit(".", 1)[0] + ".bias"
    for field in table.fields:
        if field.endswith(".bias") and field != metad_bias:
            if np.any(np.abs(table.column(field)[:end + 1]) > 1e-10):
                raise ValueError(f"Additional bias {field} is active before first passage; "
                                 "this script cannot recover unbiased kinetics with that restraint")
    if acceleration_column:
        acc = table.column(acceleration_column)
        if acc[end] < 1.0:
            raise ValueError("Infrequent-metadynamics acceleration must be at least one")
        log_exposure = math.log(t[end] * TIME_TO_S[time_unit]) + math.log(acc[end])
    else:
        if bias_column.endswith((".rbias", ".rct")):
            raise ValueError("Kinetics needs the raw metadynamics bias, not rbias or c(t)")
        bias = table.column(bias_column)[:end + 1] * energy_factor
        if np.any(bias < -1e-10):
            raise ValueError("Infrequent acceleration expects nonnegative raw metadynamics bias")
        b = bias / (R * temperature)
        dt = np.diff(t[:end + 1]) * TIME_TO_S[time_unit]
        terms = np.log(dt / 2) + np.logaddexp(b[:-1], b[1:])
        log_exposure = logsumexp(terms)
    return {"event": event, "biased_duration": float(t[end]),
            "last_sample_before_event": float(t[end - 1]) if event else None,
            "time_unit": time_unit, "unbiased_exposure_s": exp_or_none(log_exposure),
            "log_unbiased_exposure_s": log_exposure,
            "acceleration_factor": exp_or_none(log_exposure - math.log(t[end] * TIME_TO_S[time_unit]))}


def exponential_ks(times, samples=1000, seed=2026):
    """Parametric-bootstrap KS test; refit the exponential mean in every draw."""
    def statistic(values):
        scaled = np.sort(values / np.mean(values, axis=-1, keepdims=True), axis=-1)
        cdf = -np.expm1(-scaled)
        n = values.shape[-1]
        return np.maximum(np.max(np.arange(1, n + 1) / n - cdf, axis=-1),
                          np.max(cdf - np.arange(n) / n, axis=-1))
    times = np.asarray(times)
    observed = float(statistic(times))
    rng = np.random.default_rng(seed)
    exceedances = 0
    for _ in range(samples):
        exceedances += statistic(rng.exponential(size=len(times))) >= observed
    return {"statistic": observed, "bootstrap_p_value": float((1 + exceedances) / (1 + samples)),
            "bootstrap_samples": samples, "note": "A fit diagnostic, not proof of unbiased kinetics."}


def summarize_kinetics(runs, temperature, kappa=1.0):
    events = sum(run["event"] for run in runs)
    exposure = logsumexp([run["log_unbiased_exposure_s"] for run in runs])
    result = {"independent_runs": len(runs), "events": events, "right_censored_runs": len(runs) - events,
              "estimator": "exponential first-passage MLE: events / total accelerated exposure",
              "runs": runs, "warnings": [
                  "Conditional on infrequent bias deposition, negligible transition-state bias, "
                  "independent equilibrated reactant starts and an exponential escape process.",
                  "First entry is resolved only to the COLVAR output interval; raw-bias quadrature "
                  "must be checked by reducing the output stride. Prefer PLUMED's metad.acc."]}
    if events:
        log_rate = math.log(events) - exposure
        result.update(rate_s_inv=exp_or_none(log_rate), log_rate_s_inv=log_rate,
                      mean_first_passage_time_s=exp_or_none(-log_rate),
                      delta_g_dagger_from_rate_kj_mol=R * temperature * (
                          math.log(kappa * KB * temperature / H) - log_rate))
    else:
        result["rate_s_inv"] = None
        result["rate_upper_95_percent_s_inv"] = exp_or_none(math.log(-math.log(0.05)) - exposure)
        result["warnings"].append("No observed escape: only a one-sided exponential rate bound is reported.")
    if len(runs) >= 5 and events == len(runs):
        logs = np.array([run["log_unbiased_exposure_s"] for run in runs])
        result["exponential_fit"] = exponential_ks(np.exp(logs - logs.max()))
    else:
        result["warnings"].append("Exponential-fit test requires at least five uncensored independent runs.")
    return result


def smooth_profile(profile, window):
    """Local cubic least-squares smoothing, separately within sampled segments."""
    if window != 0 and (window < 5 or window % 2 == 0):
        raise ValueError("Smoothing window must be 0 (off) or an odd integer >= 5")
    result = profile.free_energy.copy()
    if window == 0:
        return result
    finite = np.isfinite(result)
    boundaries = np.flatnonzero(np.diff(np.r_[False, finite, False]))
    for start, stop in zip(boundaries[::2], boundaries[1::2]):
        count = min(window, (stop - start - 1) // 2 * 2 + 1)
        if count < 5:
            continue
        for i in range(start, stop):
            left = max(start, min(i - count // 2, stop - count))
            x = profile.x[left:left + count] - profile.x[i]
            x /= np.max(np.abs(x))
            # Use the original data for every fit; shift/scale x for stability.
            coefficients = np.polynomial.polynomial.polyfit(
                x, profile.free_energy[left:left + count], deg=3)
            result[i] = coefficients[0]
    if finite.any():
        result[finite] -= result[finite].min()
    return result


def save_results(directory, summary, profile=None, cv="cv", cv_unit="input units", plot=False,
                 smooth_window=0):
    """Prepare a complete result before replacing this script's previous outputs."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    names = ("free_energy.csv", "free_energy_smoothed.csv", "free_energy.png", "summary.json")
    for name in names:
        if (directory / name).is_dir():
            raise ValueError(f"Cannot replace analysis file: {directory / name} is a directory")
    with tempfile.TemporaryDirectory(prefix=".metad-output-", dir=directory) as tmp:
        staged = Path(tmp)
        _write_results(staged, summary, profile, cv, cv_unit, plot, smooth_window)
        for name in names:
            source, target = staged / name, directory / name
            if source.is_file():
                source.replace(target)
            else:
                # Plot/smoothing may be disabled, or a profile may be unavailable.
                target.unlink(missing_ok=True)


def _write_results(directory, summary, profile, cv, cv_unit, plot, smooth_window):
    directory = Path(directory)
    smoothed = None
    if profile is not None:
        if smooth_window:
            smoothed = smooth_profile(profile, smooth_window)
            summary["smoothing"] = {"method": "local cubic least squares", "window_points": smooth_window,
                                    "scope": "plot and free_energy_smoothed.csv only",
                                    "note": "Short sampled segments use a smaller odd window; "
                                            "segments with fewer than five points are unchanged. "
                                            "Unsampled gaps are preserved; the smoothed minimum is zero."}
    if plot:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    directory.mkdir(parents=True, exist_ok=True)
    if profile is not None:
        np.savetxt(directory / "free_energy.csv", np.column_stack((profile.x, profile.free_energy)),
                   delimiter=",", header=f"{cv},free_energy_kj_mol", comments="", fmt="%.12g")
        if smoothed is not None:
            np.savetxt(directory / "free_energy_smoothed.csv", np.column_stack((profile.x, smoothed)),
                       delimiter=",", header=f"{cv},free_energy_smoothed_kj_mol", comments="", fmt="%.12g")
    if plot:
        fig, ax = plt.subplots(figsize=(8, 4.5), constrained_layout=True)
        f = np.where(np.isfinite(profile.free_energy), profile.free_energy, np.nan)
        if smoothed is not None:
            ax.plot(profile.x, f, color="#9aa5b1", linewidth=1, alpha=0.45, label="Raw FES")
            f = np.where(np.isfinite(smoothed), smoothed, np.nan)
        ax.plot(profile.x, f, color="#235789", linewidth=2,
                label="Smoothed FES" if smoothed is not None else "FES")
        for name, color in (("reactant", "#38995b"), ("product", "#d48122")):
            if f"{name}_range" in summary:
                label = name.capitalize() + (" (inferred)" if summary.get("basin_assignment") == "inferred" else "")
                ax.axvspan(*summary[f"{name}_range"], color=color, alpha=0.15, label=label)
        if "transition_state_cv" in summary:
            ax.axvline(summary["transition_state_cv"], color="#a13c4b", linestyle="--", label="Projected barrier")
        if "reactant_range" in summary or smoothed is not None:
            ax.legend(frameon=False)
        ax.set(xlabel=f"{cv} [{cv_unit}]", ylabel="Relative free energy [kJ/mol]")
        fig.savefig(directory / "free_energy.png", dpi=180)
        plt.close(fig)
    with open(directory / "summary.json", "w") as stream:
        json.dump(summary, stream, indent=2, allow_nan=False)
        stream.write("\n")


def describe_table(path, table):
    """Include the former inspect output in every analysis."""
    ranges = {}
    for name in table.fields:
        values = table.column(name, finite=False)
        finite = values[np.isfinite(values)]
        ranges[name] = [float(finite.min()), float(finite.max())] if len(finite) else None
    return {"file": str(Path(path).resolve()), "rows": len(table.values),
            "metadata": table.metadata, "field_ranges": ranges}


def analyze_profile(args, config, tables, summary):
    """Build the profile and always estimate barriers and Eyring rates when resolved."""
    factor = ENERGY_TO_KJ[args.energy_unit]
    if args.hills or args.fes_file:
        if any(value is not None for value in (args.start_time, args.end_time, args.rbias_column,
                                               args.rct_column)) or args.additional_bias or (args.bias_column and not args.infrequent):
            raise ValueError("Time selection and reweighting columns apply only to a COLVAR population FES")
        source = args.hills or args.fes_file
        table = read_plumed(source)
        summary["inputs"].append(describe_table(source, table))
        if args.hills:
            profile = sum_hills_profile(args.hills, args.cv, args.temperature, factor,
                                       args.plumed, args.bins, args.grid_range)
            summary["method"] = "PLUMED sum_hills (WT scaling applied by PLUMED)"
        else:
            if args.grid_range:
                raise ValueError("--grid-range cannot resample --fes-file; supply the desired grid")
            profile = load_profile(table, args.cv, args.energy_column, factor)
            summary["method"] = "Supplied 1D free-energy grid"
        if args.upper_wall:
            at, kappa_wall = args.upper_wall
            if not np.isfinite(args.upper_wall).all() or kappa_wall < 0:
                raise ValueError("Upper-wall parameters must be finite, with nonnegative KAPPA")
            profile.free_energy -= factor * kappa_wall * np.maximum(profile.x - at, 0) ** 2
            profile.free_energy -= profile.free_energy.min()
            summary["subtracted_upper_wall"] = {"at": at, "kappa": kappa_wall}
        summary["warnings"].append("HILLS/FES results retain any other unremoved restraints; "
                                   "subtracting a wall cannot recover regions that were never sampled.")
    else:
        if len(tables) != 1:
            summary["profile_unavailable"] = (
                "Independent first-passage trajectories are not pooled into an equilibrium FES; "
                "supply --hills or --fes-file for a profile alongside kinetics.")
            return None
        if args.upper_wall:
            raise ValueError("For COLVAR, remove walls with --additional-bias wall.bias")
        if args.rbias_column and args.rct_column:
            raise ValueError("rbias already includes c(t); do not also supply --rct-column")
        source, table = args.colvar[0], tables[0]
        infer_bias_columns(args, config, [table])
        # Kinetic-only data can still yield a rate, but raw bias is not a FES weight.
        normalized = args.rbias_column or (args.bias_column and args.rct_column)
        recoverable = (config and all(key in config["metadynamics"] for key in ("GRID_MIN", "GRID_MAX"))
                       and (Path(config["file"]).parent / config["metadynamics"].get("FILE", "HILLS")).is_file())
        if args.infrequent and not normalized and not recoverable:
            summary["profile_unavailable"] = "COLVAR lacks normalized bias and matching HILLS/grid for FES reweighting."
            return None
        table, recovered = recover_colvar_bias(table, args, config, factor)
        if recovered:
            summary["bias_reconstruction"] = recovered
            summary["warnings"].append("Missing normalized bias was recovered from HILLS; "
                                       "c(t) depends on the configured METAD grid and WTMetaD estimate.")
        profile, details = reweighted_profile(
            table, args.cv, args.temperature, args.bins, args.grid_range,
            args.rbias_column, args.bias_column, args.rct_column, args.additional_bias or [],
            factor, args.start_time, args.end_time)
        summary.update(method="COLVAR time-dependent reweighting", sampling=details,
                       free_energy_definition="-RT ln(reweighted probability density) + constant")
        active_biases = [field for field in table.fields
                         if field.endswith(".bias") and field != args.bias_column
                         and field != (args.rbias_column or "").rsplit(".", 1)[0] + ".bias"
                         and field not in (args.additional_bias or [])]
        if active_biases:
            summary["warnings"].append("Other COLVAR bias columns were not removed: " + ", ".join(active_biases))
    reactant, product = args.reactant, args.product
    summary["basin_assignment"] = "explicit" if reactant else "unresolved"
    if not reactant:
        inferred = infer_basins(profile, args.temperature)
        if inferred:
            reactant, product = inferred["reactant"], inferred["product"]
            summary.update(basin_assignment="inferred", basin_inference=inferred)
            summary["warnings"].append("Basin ranges are inferred geometrically; review their chemical assignments "
                                       "or override with --reactant and --product.")
        else:
            summary["barrier_unavailable"] = (
                "No two basins separated by a fully sampled barrier at least RT above both minima were found. "
                "Provide --reactant and --product to analyze specific states.")
    if reactant:
        basins = analyze_basins(profile, args.temperature, reactant, product, eyring=True, kappa=args.kappa)
        summary["warnings"].extend(basins.pop("warnings"))
        summary.update(basins)
        if "eyring_proxy_forward" not in basins:
            summary["barrier_unavailable"] = "No resolved interior barrier between the basin minima; see warnings."
    summary["source"] = str(Path(source).resolve())
    summary["grid_range"] = [float(profile.x[0]), float(profile.x[-1])]
    summary["grid_points"] = len(profile.x)
    summary["warnings"].extend([
        "Assess convergence using independent runs/time windows and grid resolution; no uncertainty is inferred from one profile.",
        "At fixed volume, basin Delta G denotes Delta F. No standard-state/concentration or radial Jacobian corrections are included."])
    return profile


def analyze(args):
    config = apply_plumed_defaults(args)
    if not math.isfinite(args.temperature) or args.temperature <= 0:
        raise ValueError("Temperature must be finite and positive")
    if not 0 < args.kappa <= 1:
        raise ValueError("kappa must be in (0, 1]")
    if args.bins < 3:
        raise ValueError("Use at least three bins")
    if args.smooth_window != 0 and (args.smooth_window < 5 or args.smooth_window % 2 == 0):
        raise ValueError("--smooth-window must be 0 (off) or an odd integer >= 5")
    if args.grid_range and (not np.isfinite(args.grid_range).all() or args.grid_range[0] >= args.grid_range[1]):
        raise ValueError("--grid-range needs finite LOW < HIGH")
    if bool(args.reactant) != bool(args.product):
        raise ValueError("Supply both --reactant and --product, or neither for inferred basins")
    if args.reactant:
        validate_states(args.reactant, args.product)
    if args.infrequent and not args.reactant:
        raise ValueError("--infrequent requires explicit --reactant and --product ranges")
    if args.acceleration_column and not args.infrequent:
        raise ValueError("--acceleration-column requires --infrequent")
    if len(args.colvar or []) > 1 and not args.infrequent:
        raise ValueError("Multiple COLVAR files require --infrequent for independent first-passage runs")
    if len({Path(p).resolve() for p in args.colvar or []}) != len(args.colvar or []):
        raise ValueError("The same COLVAR file was supplied more than once")
    tables = [read_plumed(path, allow_incomplete_tail=True) for path in args.colvar or []]
    summary = {"cv": args.cv, "temperature_K": args.temperature, "input_energy_unit": args.energy_unit,
               "output_energy_unit": "kJ/mol", "kappa": args.kappa,
               "warnings": [warning for table in tables for warning in table.warnings],
               "inputs": [describe_table(path, table) for path, table in zip(args.colvar or [], tables)]}
    if config:
        summary["plumed_input"] = config
    if args.reactant:
        summary.update(basin_assignment="explicit", reactant_range=args.reactant,
                       product_range=args.product)
    if args.infrequent:
        # Keep kinetic raw-bias choices independent of FES normalized weights.
        kinetic_args = argparse.Namespace(**vars(args))
        infer_bias_columns(kinetic_args, config, tables, kinetics=True)
        runs = [dict(file=str(Path(path).resolve()), **first_passage(
            table, args.cv, args.reactant, args.product, args.temperature, args.time_unit,
            kinetic_args.bias_column if not kinetic_args.acceleration_column else None,
            kinetic_args.acceleration_column, ENERGY_TO_KJ[args.energy_unit]))
                for path, table in zip(args.colvar, tables)]
        kinetics = summarize_kinetics(runs, args.temperature, args.kappa)
        summary["warnings"].extend(kinetics.pop("warnings"))
        summary.update(kinetics)
    profile = analyze_profile(args, config, tables, summary)
    return summary, profile
