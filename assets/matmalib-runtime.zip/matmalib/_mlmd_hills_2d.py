"""Reconstruct a two-CV HILLS surface through PLUMED's in-process interface.

PLUMED handles the well-tempered HILLS convention and periodicity. No extra
biasfactor scaling is applied. References:
https://www.plumed.org/doc-v2.10/user-doc/html/sum_hills.html
https://github.com/plumed/plumed2/blob/v2.10/src/core/CLToolMain.cpp
"""

import hashlib
import json
from numbers import Integral
from pathlib import Path
import tempfile
from typing import Any

import numpy as np

from ._mlmd_analysis_2d import R_KJ_MOL_K, _axis_label, _free_energy, _plot_scale, _prepare_outputs
from ._mlmd_metadynamics import MAX_GRID_POINTS, normalize_spec


def _path(value):
    result = Path(value).expanduser().resolve()
    if any(character.isspace() or character in ",#\"'{};" for character in str(result)):
        raise ValueError("PLUMED paths must not contain whitespace, commas, quotes, or delimiters")
    return result


def _header(path) -> tuple[list[str], dict[str, str], list[str]]:
    path = Path(path)
    fields: list[str] = []
    settings: dict[str, str] = {}
    first_row: list[str] = []
    with path.open() as stream:
        for line in stream:
            if line.startswith("#! FIELDS "):
                fields = line.split()[2:]
            elif line.startswith("#! SET "):
                words = line.split(maxsplit=3)
                if len(words) == 4:
                    settings[words[2]] = words[3].strip()
            elif line.strip() and not line.startswith("#"):
                first_row = line.split()
                break
    if not fields or len(set(fields)) != len(fields) or not first_row:
        raise ValueError(f"{path.name} requires a unique FIELDS header and at least one data row")
    if len(first_row) != len(fields):
        raise ValueError(f"{path.name}: first data row does not match its FIELDS header")
    return fields, settings, first_row


def _sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def _bound(value):
    if value in {"pi", "+pi", "-pi"}:
        return -np.pi if value == "-pi" else np.pi
    return float(value)


def _temperature(temperature_K):
    if temperature_K is not None and (isinstance(temperature_K, bool)
                                      or not np.isfinite(temperature_K) or temperature_K <= 0):
        raise ValueError("temperature_K must be finite and positive")


def _physical_density(result, thermal):
    """Clip quadrature to physical CV domains, interpolating density at boundaries."""
    axes, slices, cropped_axes = [], [], []
    for axis, spec in zip(result["axes"], result["cv_specs"]):
        if spec["type"] == "TORSION":
            axes.append(axis)
            slices.append(slice(None))
            cropped_axes.append(axis)
            continue
        lower = max(0.0, axis[0])
        upper = min(np.pi, axis[-1]) if spec["type"] == "ANGLE" else axis[-1]
        if upper <= lower:
            raise ValueError(f"FES grid for {spec['label']} has no physical domain to integrate")
        selected = np.unique(np.r_[lower, axis[(axis > lower) & (axis < upper)], upper])
        first = max(0, int(np.searchsorted(axis, lower, side="right")) - 1)
        last = min(len(axis), int(np.searchsorted(axis, upper, side="left")) + 1)
        axes.append(selected)
        slices.append(slice(first, last))
        cropped_axes.append(axis[first:last])
    # Discard remote unphysical minima before exponentiation so they cannot
    # underflow every weight in the retained physical domain.
    energy = result["free_energy"][tuple(slices)]
    with np.errstate(under="ignore", over="ignore"):
        density = np.exp(-(energy - energy.min()) / thermal)
    for index, (source, target) in enumerate(zip(cropped_axes, axes)):
        if np.array_equal(source, target):
            continue
        if index == 0:
            density = np.column_stack([np.interp(target, source, column) for column in density.T])
        else:
            density = np.vstack([np.interp(target, source, row) for row in density])
    return tuple(axes), density


def _marginals(result: dict[str, Any], temperature_K):
    """Integrate physical density, including a periodic closing interval."""
    thermal = R_KJ_MOL_K * float(temperature_K) / (4.184 if result["energy_unit"] == "kcal/mol" else 1)
    integration_axes, density = _physical_density(result, thermal)
    weights = []
    for axis, spec in zip(integration_axes, result["cv_specs"]):
        gaps = np.diff(axis)
        if spec["type"] == "TORSION":
            gaps = np.append(gaps, axis[0] + 2 * np.pi - axis[-1])
            if gaps[-1] <= 0:
                raise ValueError("A periodic FES grid must omit its duplicate closing endpoint")
            weights.append((gaps + np.roll(gaps, 1)) / 2)
        else:
            weights.append(np.r_[gaps[0], gaps[:-1] + gaps[1:], gaps[-1]] / 2)
    probability = density * weights[0][:, None] * weights[1][None, :]
    normalization = probability.sum()
    density /= normalization
    probability /= normalization
    marginals = []
    for index in range(2):
        marginal_probability = probability.sum(axis=1 - index)
        marginal_density = marginal_probability / weights[index]
        marginals.append(dict(axis=integration_axes[index], probability=marginal_probability, density=marginal_density,
                              free_energy=_free_energy(marginal_density, thermal)))
    result.update(temperature_K=float(temperature_K), probability=probability, density=density,
                  integration_axes=integration_axes,
                  integration_domain_clipped=any(not np.array_equal(original, integrated)
                                                 for original, integrated in zip(result["axes"], integration_axes)),
                  quadrature_weights=tuple(weights), marginals=tuple(marginals),
                  marginal_definition="Integrate exp(-F/RT) over the physical part of the reconstructed grid; "
                                      "trapezoidal quadrature, including the periodic closing interval",
                  physical_domain_treatment="DISTANCE >= 0; ANGLE in [0, pi]; TORSION periodic on [-pi, pi). "
                                            "Interpolate Boltzmann density at clipped boundaries. "
                                            "Raw FES axes, energies and DAT remain unchanged.")


def read_two_cv_fes(path, cv_specs, *, energy_unit="kcal/mol", temperature_K=None) -> dict[str, Any]:
    """Read a rectangular FES; optionally integrate marginal profiles at a supplied temperature."""
    specs = normalize_spec(cv_specs)["cvs"]
    if len(specs) != 2:
        raise ValueError("Two CV specifications are required for a two-dimensional FES")
    if energy_unit not in {"kJ/mol", "kcal/mol"}:
        raise ValueError("energy_unit must be kJ/mol or kcal/mol")
    _temperature(temperature_K)
    fields, settings, _ = _header(path)
    labels = [spec["label"] for spec in specs]
    if fields[:3] != [*labels, "file.free"]:
        raise ValueError("FES columns do not match the requested two CVs and free energy")
    rows = np.loadtxt(path, comments="#", ndmin=2)
    if rows.shape[1] != len(fields) or not np.isfinite(rows).all():
        raise ValueError("FES contains nonfinite values or an inconsistent column count")
    axes = tuple(np.unique(rows[:, index]) for index in range(2))
    if any(len(axis) < 2 for axis in axes) or len(axes[0]) * len(axes[1]) != len(rows):
        raise ValueError("FES does not contain a complete two-dimensional rectangular grid")
    indices = tuple(np.searchsorted(axes[index], rows[:, index]) for index in range(2))
    flat_indices = indices[0] * len(axes[1]) + indices[1]
    if len(np.unique(flat_indices)) != len(rows):
        raise ValueError("FES contains duplicate grid coordinates")
    for index, spec in enumerate(specs):
        label = spec["label"]
        if int(settings.get(f"nbins_{label}", -1)) != len(axes[index]):
            raise ValueError(f"FES grid size for {label} disagrees with its header")
        periodic = settings.get(f"periodic_{label}")
        if periodic != ("true" if spec["type"] == "TORSION" else "false"):
            raise ValueError(f"FES periodicity disagrees with the {label} CV")
        axis = axes[index]
        for key, observed in ((f"min_{label}", axis[0]),
                              (f"max_{label}", axis[-1] if periodic == "false" else None)):
            if key in settings:
                declared = _bound(settings[key])
                if not np.isfinite(declared) or (observed is not None and
                        not np.isclose(observed, declared, rtol=1e-6, atol=1e-6)):
                    raise ValueError(f"FES coordinates for {label} disagree with its grid header")
        if periodic == "true":
            lower = _bound(settings.get(f"min_{label}", "-pi"))
            upper = _bound(settings.get(f"max_{label}", "pi"))
            if not np.allclose([lower, upper], [-np.pi, np.pi], rtol=0, atol=1e-6):
                raise ValueError("TORSION grids require the full [-pi, pi] periodic domain")
            if axis[0] < lower - 1e-6 or axis[-1] >= upper:
                raise ValueError("TORSION grid coordinates must lie in [-pi, pi)")
            if not np.allclose(axis, np.linspace(lower, upper, len(axis), endpoint=False),
                               rtol=1e-6, atol=1e-6):
                raise ValueError("TORSION coordinates must cover the complete periodic grid")
    surface = np.empty((len(axes[0]), len(axes[1])), dtype=float)
    values = rows[:, 2] / (4.184 if energy_unit == "kcal/mol" else 1.0)
    surface[indices] = values - values.min()
    result: dict[str, Any] = dict(cv_specs=specs, axes=axes, free_energy=surface, energy_unit=energy_unit,
                  source_energy_unit="kJ/mol", grid_settings=settings)
    if temperature_K is not None:
        _marginals(result, temperature_K)
    return result


def plot_two_cv_hills(result, *, distance_unit="nm"):
    """Plot HILLS FES with closed torsion seams and optional distance axes in Å."""
    import matplotlib.pyplot as plt

    scales = [_plot_scale(spec, distance_unit) for spec in result["cv_specs"]]
    axes = list(result["axes"])
    surface = result["free_energy"]
    for index, spec in enumerate(result["cv_specs"]):
        if spec["type"] == "TORSION":
            axes[index] = np.append(axes[index], axes[index][0] + 2 * np.pi)
            surface = np.concatenate((surface, np.take(surface, [0], axis=index)), axis=index)
    if "marginals" in result:
        figure = plt.figure(figsize=(10, 8), layout="constrained")
        grid = figure.add_gridspec(2, 3, height_ratios=(1, 4), width_ratios=(4, 1, 0.16))
        axis = figure.add_subplot(grid[1, 0])
        top = figure.add_subplot(grid[0, 0], sharex=axis)
        right = figure.add_subplot(grid[1, 1], sharey=axis)
        color_axis = figure.add_subplot(grid[1, 2])
        for index, marginal_axis in enumerate((top, right)):
            values = result["marginals"][index]["free_energy"]
            coordinates = result["marginals"][index].get("axis", result["axes"][index])
            if result["cv_specs"][index]["type"] == "TORSION":
                values = np.append(values, values[0])
                coordinates = np.append(coordinates, coordinates[0] + 2 * np.pi)
            coordinates = coordinates * scales[index]
            values = np.ma.masked_invalid(values)
            if index == 0:
                marginal_axis.plot(coordinates, values, color="#006d77")
                marginal_axis.set_ylabel(f"ΔF ({result['energy_unit']})")
                marginal_axis.tick_params(labelbottom=False)
            else:
                marginal_axis.plot(values, coordinates, color="#006d77")
                marginal_axis.set_xlabel(f"ΔF ({result['energy_unit']})")
                marginal_axis.tick_params(labelleft=False)
            marginal_axis.grid(alpha=0.2)
    else:
        figure, axis = plt.subplots(figsize=(8, 6), layout="constrained")
        color_axis = None
    image = axis.pcolormesh(axes[0] * scales[0], axes[1] * scales[1], surface.T,
                           shading="gouraud", cmap="viridis", vmin=0)
    first, second = result["cv_specs"]
    axis.set(xlabel=_axis_label(first, distance_unit), ylabel=_axis_label(second, distance_unit),
             title="FES reconstructed from deposited HILLS")
    if "integration_axes" in result:
        limits = [(values[0] * scale,
                   (values[0] + 2 * np.pi if spec["type"] == "TORSION" else values[-1]) * scale)
                  for values, spec, scale in zip(result["integration_axes"], result["cv_specs"], scales)]
        axis.set(xlim=limits[0], ylim=limits[1])
    figure.colorbar(image, ax=axis, cax=color_axis, label=f"ΔF ({result['energy_unit']})")
    return figure


def reconstruct_two_cv_hills(hills_file, cv_specs, *, output_dir, bins=(80, 80),
                             energy_unit="kcal/mol", overwrite=False, temperature_K=None):
    """Run native ``sum_hills`` in process; save DAT, NPZ, PNG and provenance.

    HILLS must use kJ/mol, with distance CVs in nm and angular CVs in radians.
    This is a bias-based
    estimate, distinct from the normalized-bias reweighted COLVAR distribution.
    Without CV grid bounds, PLUMED infers the extent from HILLS. Existing explicit
    grids are retained; ``bins`` controls reconstruction resolution. Supplying
    ``temperature_K`` adds integrated marginal profiles. Existing outputs require
    ``overwrite=True``.
    """
    specs = normalize_spec(cv_specs)["cvs"]
    if len(specs) != 2:
        raise ValueError("HILLS reconstruction here requires exactly two CVs")
    if energy_unit not in {"kJ/mol", "kcal/mol"}:
        raise ValueError("energy_unit must be kJ/mol or kcal/mol")
    _temperature(temperature_K)
    if isinstance(bins, Integral) and not isinstance(bins, bool):
        bins = (int(bins), int(bins))
    if not isinstance(bins, (tuple, list)) or len(bins) != 2 or any(
            isinstance(value, bool) or not isinstance(value, Integral) or value < 2 for value in bins):
        raise ValueError("bins must be an integer >= 2 or a pair of such integers")
    if (int(bins[0]) + 1) * (int(bins[1]) + 1) > MAX_GRID_POINTS:
        raise ValueError("HILLS reconstruction grid exceeds the two-million-point limit")
    hills = _path(hills_file)
    directory = _path(output_dir)
    fields, settings, first_row = _header(hills)
    labels = [spec["label"] for spec in specs]
    expected = ["time", *labels, *(f"sigma_{label}" for label in labels), "height", "biasf"]
    if fields != expected or settings.get("multivariate", "false") != "false":
        raise ValueError("HILLS columns/order must match the saved two-CV diagonal-Gaussian specification")
    first_values = np.asarray(first_row, dtype=float)
    if not np.isfinite(first_values).all() or first_values[-1] <= 1:
        raise ValueError("HILLS must contain finite well-tempered hills with biasfactor > 1")
    for spec in specs:
        label = spec["label"]
        periodic = f"min_{label}" in settings or f"max_{label}" in settings
        if periodic != (spec["type"] == "TORSION"):
            raise ValueError(f"HILLS periodicity does not match saved CV {label}")
        if periodic and (f"min_{label}" not in settings or f"max_{label}" not in settings or
                         not np.allclose([_bound(settings[f"min_{label}"]), _bound(settings[f"max_{label}"])],
                                         [-np.pi, np.pi], rtol=0, atol=1e-6)):
            raise ValueError("TORSION HILLS require the full [-pi, pi] periodic domain")
    names = {kind: f"fes_hills_2d.{extension}" for kind, extension in
             (("dat", "dat"), ("npz", "npz"), ("plot", "png"), ("metadata", "json"))}
    directory, artifacts = _prepare_outputs(directory, names, sources=(hills,), overwrite=overwrite)
    import plumed

    directory.mkdir(parents=True, exist_ok=True)
    before = hills.stat()
    source_digest = _sha256(hills)
    with tempfile.TemporaryDirectory(prefix=".sum_hills_", dir=directory) as temporary:
        stage = Path(temporary)
        stage_dat = stage / "fes.dat"
        arguments = (f"plumed sum_hills --hills {hills} --outfile {stage_dat} "
                     f"--bin {int(bins[0])},{int(bins[1])} --mintozero")
        explicit_grid = specs[0]["grid_min"] is not None
        if explicit_grid:
            minimum = ",".join("-pi" if spec["type"] == "TORSION" else format(spec["grid_min"], ".17g")
                               for spec in specs)
            maximum = ",".join("pi" if spec["type"] == "TORSION" else format(spec["grid_max"], ".17g")
                               for spec in specs)
            arguments += f" --min {minimum} --max {maximum}"
        engine = plumed.Plumed()
        status = np.zeros(1, dtype=np.intc)
        try:
            engine.cmd("CLTool setArgvLine", arguments)
            engine.cmd("CLTool run", status)
        finally:
            engine.finalize()
        if int(status[0]) != 0 or not stage_dat.is_file():
            raise RuntimeError(f"PLUMED sum_hills failed with status {int(status[0])}")
        after = hills.stat()
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns) or _sha256(hills) != source_digest:
            raise RuntimeError("HILLS changed during reconstruction; use a completed or snapshotted history")
        result = read_two_cv_fes(stage_dat, specs, energy_unit=energy_unit, temperature_K=temperature_K)
        metadata = dict(source_hills=str(hills), source_sha256=source_digest, hills_energy_unit="kJ/mol",
                        cv_specs=specs, bins=list(map(int, bins)), energy_unit=energy_unit,
                        raw_dat_energy_unit="kJ/mol", method="PLUMED sum_hills --mintozero",
                        grid_extent="explicit CV bounds" if explicit_grid else "PLUMED inferred from HILLS",
                        temperature_K=temperature_K, marginal_definition=result.get("marginal_definition"),
                        physical_domain_treatment=result.get("physical_domain_treatment"),
                        integration_domain_clipped=result.get("integration_domain_clipped"),
                        notes=["No additional well-tempered biasfactor scaling is applied.",
                               "This bias-based reconstruction is distinct from the reweighted COLVAR FES.",
                               "Marginals integrate only over the physical part of the reconstructed grid; no Jacobian correction is applied.",
                               "Conditional hill deposition is not evidence of free-energy convergence."])
        arrays: dict[str, Any] = dict(x=result["axes"][0], y=result["axes"][1],
                      free_energy=result["free_energy"], energy_unit=energy_unit)
        if "marginals" in result:
            arrays.update(temperature_K=temperature_K, probability=result["probability"], density=result["density"])
            for index, marginal in enumerate(result["marginals"]):
                arrays[f"integration_axis_{index}"] = result["integration_axes"][index]
                arrays[f"quadrature_weights_{index}"] = result["quadrature_weights"][index]
                arrays.update({f"marginal_{index}_{key}": value for key, value in marginal.items()})
        np.savez_compressed(stage / "fes.npz", **arrays)
        (stage / "fes.json").write_text(json.dumps(metadata, indent=2) + "\n")
        figure = plot_two_cv_hills(result)
        try:
            figure.savefig(stage / "fes.png", dpi=180)
        finally:
            import matplotlib.pyplot as plt
            plt.close(figure)
        for kind, source in (("dat", stage_dat), ("npz", stage / "fes.npz"),
                             ("metadata", stage / "fes.json"), ("plot", stage / "fes.png")):
            if overwrite:
                source.replace(artifacts[kind])
            else:
                artifacts[kind].hardlink_to(source)
        result.update(artifacts={key: str(path) for key, path in artifacts.items()}, metadata=metadata)
        return result
