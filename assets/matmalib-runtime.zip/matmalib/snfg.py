"""Vector SNFG drawings using the official Symbol Nomenclature for Glycans.

Symbol shapes and RGB colors: https://www.ncbi.nlm.nih.gov/glycans/snfg.html
Connectivity-to-diagram functionality follows CarPpy's display conventions;
this renderer needs no downloaded SVG assets or external drawing programs.
"""

from collections.abc import Mapping

import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon
import networkx as nx
import numpy as np

from ._glycan_analysis import identify_sugars, linkage_positions

__all__ = ["draw_snfg"]

_COLORS = ("#ffffff", "#0072bc", "#00a651", "#ffd400", "#f47920",
           "#f69ea1", "#a54399", "#8fcce9", "#a17a4d", "#ed1c24")
_ROWS = {
    "circle": ("Hex", "Glc", "Man", "Gal", "Gul", "Alt", "All", "Tal", "Ido", None),
    "square": ("HexNAc", "GlcNAc", "ManNAc", "GalNAc", "GulNAc", "AltNAc", "AllNAc", "TalNAc", "IdoNAc", None),
    "crossed_square": ("HexN", "GlcN", "ManN", "GalN", "GulN", "AltN", "AllN", "TalN", "IdoN", None),
    "divided_diamond": ("HexA", "GlcA", "ManA", "GalA", "GulA", "AltA", "AllA", "TalA", "IdoA", None),
    "triangle": ("dHex", "Qui", "Rha", None, "6dGul", "6dAlt", None, "6dTal", None, "Fuc"),
    "divided_triangle": ("dHexNAc", "QuiNAc", "RhaNAc", None, None, "6dAltNAc", None, "6dTalNAc", None, "FucNAc"),
    "rectangle": ("ddHex", "Oli", "Tyv", None, "Abe", "Par", "Dig", "Col", None, None),
    "star": ("Pen", None, "Ara", "Lyx", "Xyl", "Rib", None, None, None, None),
    "diamond": ("Non", None, "Kdn", None, None, None, "Neu5Ac", "Neu5Gc", "Neu", "Sia"),
    "flat_diamond": ("ddNon", None, "Pse", "Leg", None, "Aci", None, "4eLeg", None, None),
    "hexagon": ("Unknown", "Bac", "LDmanHep", "Kdo", "Dha", "DDmanHep", "MurNAc", "MurNGc", "Mur", None),
    "pentagon": ("Assigned", "Api", "Fru", "Tag", "Sor", "Psi", None, None, None, None),
}
_SYMBOLS = {name: (shape, color) for shape, row in _ROWS.items()
            for name, color in zip(row, _COLORS) if name is not None}
# Directions from the acceptor to its donor, with the reducing end at right.
_LINKAGE_ANGLES = {"2": 270, "3": 225, "4": 180, "6": 135, "8": 90}


def _default_configuration(name):
    return "L" if name.startswith(("Alt", "Ido", "Fuc", "Rha", "6dAlt")) or name in ("Ara", "Sor", "Api") else "D"


def _layout(glycan, bond_length, diagonal_bond_scale):
    graph = nx.DiGraph()
    graph.add_nodes_from(range(len(glycan.monomers)))
    graph.add_edges_from((bond["donor"], bond["acceptor"]) for bond in glycan.glycosidic_bonds)
    if not nx.is_directed_acyclic_graph(graph) or any(graph.out_degree(node) > 1 for node in graph):
        raise ValueError("Automatic SNFG layout requires a glycan forest; supply positions for cyclic or multiply linked glycans.")
    positions = {}
    angles = {}
    for link in glycan.glycosidic_bonds:
        position = linkage_positions(glycan, link)[1]
        if position not in _LINKAGE_ANGLES:
            raise ValueError(f"No automatic SNFG direction for acceptor position {position!r}; supply positions.")
        angles[link["donor"], link["acceptor"]] = _LINKAGE_ANGLES[position]

    def visit(node, origin):
        positions[node] = origin
        for child in sorted(graph.predecessors(node)):
            angle = angles[child, node]
            direction = np.array([np.cos(np.radians(angle)), np.sin(np.radians(angle))])
            direction[np.abs(direction) < 1e-12] = 0
            length = bond_length * (diagonal_bond_scale if angle % 90 else 1)
            visit(child, np.asarray(origin) + length * direction)

    top = 0.
    for root in sorted(node for node in graph if graph.out_degree(node) == 0):
        before = set(positions)
        visit(root, (0., 0.))
        component = set(positions) - before
        bottom = min(positions[node][1] for node in component)
        for node in component:
            x, y = positions[node]
            positions[node] = (x, y - bottom + top)
        top = max(positions[node][1] for node in component) + 2 * bond_length
    xy = np.asarray(list(positions.values()))
    if len(np.unique(np.round(xy, 10), axis=0)) != len(xy):
        raise ValueError("Fixed-length SNFG layout overlaps residues; supply positions for this topology.")
    return positions


def _glyph(ax, center, name, radius, linewidth):
    shape, color = _SYMBOLS[name]
    center = np.asarray(center)

    def polygon(vertices, face=color, edge="black", zorder=3):
        patch = Polygon(center + radius * np.asarray(vertices), closed=True,
                        facecolor=face, edgecolor=edge, linewidth=linewidth, zorder=zorder)
        ax.add_patch(patch)
        return patch

    if shape == "circle":
        ax.add_patch(Circle(center, radius, facecolor=color, edgecolor="black", linewidth=linewidth, zorder=3))
    elif shape in ("square", "crossed_square"):
        vertices = [(-.85, -.85), (.85, -.85), (.85, .85), (-.85, .85)]
        polygon(vertices)
        if shape == "crossed_square":
            polygon([(-.85, -.85), (.85, -.85), (-.85, .85)], face="white", zorder=4)
    elif shape in ("diamond", "divided_diamond", "flat_diamond"):
        wide, high = (1.25, .65) if shape == "flat_diamond" else (1.1, 1.1)
        polygon([(0, high), (wide, 0), (0, -high), (-wide, 0)])
        if shape == "divided_diamond":
            white_height = high if name == "IdoA" else -high
            polygon([(-wide, 0), (0, white_height), (wide, 0)], face="white", zorder=4)
    elif shape in ("triangle", "divided_triangle"):
        polygon([(0, 1.1), (1.05, -.8), (-1.05, -.8)])
        if shape == "divided_triangle":
            polygon([(0, 1.1), (0, -.8), (-1.05, -.8)], face="white", zorder=4)
    elif shape == "rectangle":
        polygon([(-1.2, -.6), (1.2, -.6), (1.2, .6), (-1.2, .6)])
    elif shape == "hexagon":
        polygon([(-1.2, 0), (-.6, .7), (.6, .7), (1.2, 0), (.6, -.7), (-.6, -.7)])
    elif shape in ("star", "pentagon"):
        count = 10 if shape == "star" else 5
        angles = np.pi / 2 + np.arange(count) * 2 * np.pi / count
        radii = np.where(np.arange(count) % 2, .45, 1.15) if shape == "star" else np.ones(count) * 1.1
        polygon(np.column_stack((radii * np.cos(angles), radii * np.sin(angles))))


def draw_snfg(glycan, *, labels=None, ax=None, positions=None, show_linkages=True,
              show_names=False, symbol_size=.32, symbol_linewidth=2.0, linkage_linewidth=2.0,
              bond_length=1.2, diagonal_bond_scale=1.2):
    """Draw a Glycan as SNFG symbols; return ``(figure, axes)``.

    Common aldohexopyranoses are named from connectivity and stereochemistry.
    Unsupported chemistry uses the white Unknown hexagon. ``labels`` may be
    a sequence (one standard SNFG abbreviation per monomer) or an index/name
    mapping overriding selected names, e.g. ``{0: 'Fru'}``. Explicit unknown
    abbreviations raise ValueError. Names describe base residues; protecting
    groups and all modifications are not inventoried by automatic naming.

    Reducing ends appear at the right. Automatic linkages extend from each
    acceptor towards its donor according to the acceptor carbon position:
    2 down (270 degrees), 3 lower left (225), 4 left (180), 6 upper left
    (135), and 8 up (90), independent of branching. ``bond_length`` sets the
    horizontal and vertical center-to-center distance in drawing coordinates
    (default 1.2). ``diagonal_bond_scale`` multiplies this length for diagonal
    links (default 1.2, or 20 percent longer); use 1 for equal lengths.
    Alpha linkages are dashed;
    beta and unknown linkages are solid. ``symbol_linewidth`` and ``linkage_linewidth`` set
    stroke widths in points. ``positions`` optionally maps every
    monomer index to (x, y); it is required for non-tree topologies. The
    lines between explicit positions are drawn straight without snapping or
    rescaling. Unknown or other acceptor positions and overlapping fixed-length
    layouts also require explicit positions.
    Linkage annotations give alpha/beta and donor–acceptor carbon positions. Anomers
    that cannot be determined are shown as ?. Nondefault D/L configurations
    and furanose rings are annotated. Figures support normal Matplotlib export.
    """
    if not np.isfinite(symbol_size) or symbol_size <= 0:
        raise ValueError("symbol_size must be finite and positive.")
    for name, value in (("symbol_linewidth", symbol_linewidth), ("linkage_linewidth", linkage_linewidth),
                        ("bond_length", bond_length), ("diagonal_bond_scale", diagonal_bond_scale)):
        if not np.isfinite(value) or value <= 0:
            raise ValueError(f"{name} must be finite and positive.")
    count = len(glycan.monomers)
    identities = identify_sugars(glycan)
    names = [info["name"] if info["name"] in _SYMBOLS else "Unknown" for info in identities]
    if labels is not None:
        if isinstance(labels, Mapping):
            overrides = labels.items()
        else:
            if isinstance(labels, str) or len(labels) != count:
                raise ValueError("labels must contain one SNFG abbreviation per monomer.")
            overrides = enumerate(labels)
        for index, name in overrides:
            if not isinstance(index, (int, np.integer)) or isinstance(index, bool) or not 0 <= index < count:
                raise ValueError("Label keys must be valid monomer indices.")
            if not isinstance(name, str) or name.replace("Nac", "NAc") not in _SYMBOLS:
                raise ValueError(f"Unsupported SNFG abbreviation: {name!r}.")
            names[index] = name.replace("Nac", "NAc")
    if positions is None:
        positions = _layout(glycan, bond_length, diagonal_bond_scale)
    if not isinstance(positions, Mapping) or set(positions) != set(range(count)):
        raise ValueError("positions must map every monomer index to one (x, y) coordinate.")
    xy = np.asarray([positions[i] for i in range(count)], dtype=float)
    if xy.shape != (count, 2) or not np.all(np.isfinite(xy)) or len(np.unique(xy, axis=0)) != count:
        raise ValueError("Symbol positions must be finite, distinct (x, y) coordinates.")
    span = np.ptp(xy, axis=0)
    if ax is None:
        fig, ax = plt.subplots(figsize=(max(2.5, span[0] + 1.5), max(2, span[1] + 1.5)))
    else:
        fig = ax.figure
    for link in glycan.glycosidic_bonds:
        start, end = xy[[link["donor"], link["acceptor"]]]
        anomer = identities[link["donor"]]["anomer"]
        ax.plot([start[0], end[0]], [start[1], end[1]], color="black", linewidth=linkage_linewidth,
                linestyle="--" if anomer == "alpha" else "-", zorder=1)
        if show_linkages:
            anomer = {"alpha": "α", "beta": "β"}.get(anomer, "?")
            donor, acceptor = linkage_positions(glycan, link)
            midpoint = (start + end) / 2
            delta = end - start
            normal = np.array([-delta[1], delta[0]]) / np.linalg.norm(delta)
            if normal[1] < 0:
                normal *= -1
            ax.annotate(f"{anomer}{donor}-{acceptor}", midpoint, xytext=12 * normal,
                        textcoords="offset points", ha="center", va="center", fontsize=10,
                        bbox=dict(facecolor="white", edgecolor="none", pad=.5), zorder=2)
    for index, (name, info) in enumerate(zip(names, identities)):
        _glyph(ax, xy[index], name, symbol_size, symbol_linewidth)
        marks = []
        if info["configuration"] and info["configuration"] != _default_configuration(name):
            marks.append(info["configuration"])
        if info["ring_type"] == "furanose":
            marks.append("f")
        if marks:
            ax.text(*xy[index], "".join(marks), ha="center", va="center", fontsize=9,
                    color="black", zorder=5, bbox=dict(facecolor="white", edgecolor="none", pad=.2))
        if show_names:
            ax.annotate(name, xy[index], xytext=(0, -22), textcoords="offset points",
                        ha="center", va="top", fontsize=10)
    margin = max(.8, symbol_size * 2)
    ax.set(xlim=(xy[:, 0].min() - margin, xy[:, 0].max() + margin),
           ylim=(xy[:, 1].min() - margin, xy[:, 1].max() + margin), aspect="equal")
    ax.set_axis_off()
    return fig, ax
