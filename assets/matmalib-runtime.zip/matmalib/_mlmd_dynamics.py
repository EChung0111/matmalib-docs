"""ASE integration and streaming output for mlmd."""

from contextlib import ExitStack
from dataclasses import asdict, replace
import inspect
from os import PathLike
from pathlib import Path
from time import perf_counter

import numpy as np
from ase import units
from .core import Data

from ._mlmd_io import (finish, output_path, positive, prepare, validate_output,
                       write_frame)
from ._mlmd_checkpoint import checkpoint_path, restore_integrator, save_checkpoint


def distinct_paths(system, *paths):
    resolved = [Path(p).expanduser().resolve() for p in paths if p is not None]
    if len(set(resolved)) != len(resolved):
        raise ValueError("Output, trajectory, and log paths must be different.")
    if isinstance(system, (str, PathLike)) and Path(system).expanduser().resolve() in resolved:
        raise ValueError("An output would overwrite the input geometry.")


def md_paths(system, config, final_output=None):
    paths = [config.trajectory, config.log_file, final_output, checkpoint_path(config)]
    meta = config.metadynamics
    if meta is not None:
        paths.extend([meta.log_file, meta.save_input])
        if meta.plumed_file is None and meta.input_lines is None:
            paths.extend([meta.hills_file, meta.colvar_file])
        if meta.plumed_file is not None:
            distinct_paths(meta.plumed_file, *paths)
    distinct_paths(system, *paths)
    for path in paths:
        if path is not None:
            output_path(path, overwrite=config.overwrite)


def check_finite(atoms, velocity_limit=None, force_limit=None):
    energy = float(atoms.get_potential_energy())
    forces = atoms.get_forces()
    if not np.isfinite(energy) or not np.isfinite(forces).all() or not np.isfinite(atoms.positions).all():
        raise RuntimeError("Nonfinite energy, forces, or coordinates; simulation stopped.")
    if atoms.has("momenta"):
        velocities = atoms.get_velocities() * units.fs
        if not np.isfinite(velocities).all():
            raise RuntimeError("Nonfinite velocities; simulation stopped.")
        if velocity_limit is not None and np.linalg.norm(velocities, axis=1).max() > velocity_limit:
            raise RuntimeError("Maximum velocity exceeded; simulation stopped without clipping.")
    maximum = float(np.linalg.norm(forces, axis=1).max())
    if force_limit is not None and maximum > force_limit:
        raise RuntimeError(f"Maximum force exceeded: {maximum:.6g} eV/angstrom "
                           f"(limit {force_limit}); simulation stopped.")
    return energy, maximum


def _system_report(atoms):
    return dict(atom_count=len(atoms), charge=atoms.info.get("charge", 0.0),
                multiplicity=atoms.info.get("mult", 1), pbc=atoms.pbc.tolist(),
                cell_angstrom=atoms.cell.array.tolist(), masses_amu=atoms.get_masses().tolist(),
                constraints=[type(c).__name__ for c in atoms.constraints],
                input_repair=atoms.info.get("input_repair"))


def _sample(atoms, energy, maximum, base, step_wall, *, include_pressure=False):
    kinetic = float(atoms.get_kinetic_energy())
    values = dict(potential_energy_eV=energy, kinetic_energy_eV=kinetic,
                  total_energy_eV=energy + kinetic, temperature_K=float(atoms.get_temperature()),
                  fmax_eV_A=maximum, force_std_eV_A=float(np.max(base.results.get("forces_std", np.nan))),
                  energy_std_eV=float(base.results.get("energy_std", np.nan)),
                  volume_A3=atoms.get_volume() if atoms.cell.rank == 3 else 0.0,
                  step_wall_seconds=step_wall)
    if include_pressure:
        # ASE stress is positive in tension. Use the active calculator so the
        # pressure includes PLUMED's virial, plus the instantaneous kinetic term.
        stress = atoms.get_stress(include_ideal_gas=True)
        values["pressure_bar"] = -float(np.mean(stress[:3])) / units.bar
    return values


def _log_formats(include_pressure, final_step):
    # Reserve room for signs and scientific notation without reducing precision.
    columns = [
        ("Step", "step", max(8, len(str(final_step))), "d"),
        ("Time_fs", "time_fs", 17, ".10g"),
        ("Epot_eV", "potential_energy_eV", 19, ".12g"),
        ("Ekin_eV", "kinetic_energy_eV", 19, ".12g"),
        ("T_K", "temperature_K", 17, ".10g"),
        ("Fmax_eV_A", "fmax_eV_A", 17, ".10g"),
        ("Fstd_eV_A", "force_std_eV_A", 17, ".10g"),
        ("Volume_A3", "volume_A3", 19, ".12g"),
        ("Etot_eV", "total_energy_eV", 19, ".12g"),
        ("StepWall_s", "step_wall_seconds", 19, ".12g"),
        ("Estd_eV", "energy_std_eV", 19, ".12g"),
    ]
    if include_pressure:
        columns.append(("Pressure_bar", "pressure_bar", 19, ".12g"))
    header = "# " + "  ".join(f"{label:>{width}}" for label, _, width, _ in columns) + "\n"
    row = "  " + "  ".join(f"{{{key}:>{width}{spec}}}" for _, key, width, spec in columns) + "\n"
    return header, row


def _write_log_summary(stream, summary):
    averages = summary["averages"]
    fields = [
        ("Ensemble", summary["ensemble"]),
        ("Mode", summary["mode"]),
        ("Steps completed", summary["steps"]),
        ("Start step", summary["start_step"]),
        ("Final step", summary["last_step"]),
        ("Simulation time (fs)", summary["simulation_time_fs"]),
        ("Final simulation time (fs)", summary["time_fs"]),
        ("Total wall time (s)", summary["elapsed_seconds"]),
        ("Average wall time per step (ms)", summary["performance"]["ms_per_step"]),
        ("Performance (ns/day)", summary["performance"]["ns_per_day"]),
        ("Averaged samples", summary["samples"]),
        ("Average temperature (K)", averages.get("temperature_K")),
    ]
    if summary["ensemble"] == "NPT":
        fields.append(("Average pressure (bar)", averages.get("pressure_bar")))
    fields.extend([
        ("Average potential energy (eV)", averages.get("potential_energy_eV")),
        ("Average kinetic energy (eV)", averages.get("kinetic_energy_eV")),
        ("Average total energy (eV)", averages.get("total_energy_eV")),
        ("Average volume (A^3)", averages.get("volume_A3")),
        ("Average maximum force (eV/A)", averages.get("fmax_eV_A")),
    ])
    stream.write(f"# Completed {summary['steps']} steps in {summary['elapsed_seconds']:.6g} s\n")
    stream.write("#\n# Simulation summary\n")
    width = max(len(label) for label, _ in fields)
    for label, value in fields:
        formatted = "n/a" if value is None else value if isinstance(value, str) else f"{value:.12g}"
        stream.write(f"# {label:<{width}}: {formatted:>19}\n")
    stream.write("# Averages use the initial, logged, and final samples (not time-weighted).\n")


def _workflow_report(api, phases, started):
    """Combine bounded online statistics without rereading logs or trajectories."""
    api.data.phases = phases
    summaries = [*phases.values(), getattr(api.data, "summary", {})]
    means, counts = {}, {}
    for summary in summaries:
        for key, mean in summary.get("averages", {}).items():
            count = summary.get("finite_samples", {}).get(key, 0)
            if count:
                previous = counts.get(key, 0)
                old_mean = means.get(key) if previous else 0.0
                means[key] = (old_mean * previous + mean * count) / (previous + count)
                counts[key] = previous + count
            else:
                means.setdefault(key, None)
                counts.setdefault(key, 0)
    api.data.total_elapsed_seconds = perf_counter() - started
    api.data.total_simulation_time_fs = sum(s.get("simulation_time_fs", 0.0) for s in summaries)
    api.data.workflow_averages = means
    api.data.workflow_finite_samples = counts
    api.data.workflow_samples = sum(s.get("samples", 0) for s in summaries)


def minimize(api, system, config, output, output_format):
    import ase.optimize
    from ase.optimize.optimize import Optimizer
    started = perf_counter()
    positive("fmax", config.fmax)
    positive("steps", config.steps, zero=True, integer=True)
    positive("maxstep", config.maxstep)
    positive("trajectory_interval", config.trajectory_interval, integer=True)
    optimizers = {name.upper(): cls for name, cls in vars(ase.optimize).items()
                  if inspect.isclass(cls) and issubclass(cls, Optimizer) and cls is not Optimizer}
    if not isinstance(config.optimizer, str) or config.optimizer.upper() not in optimizers:
        raise ValueError("optimizer must name an optimizer exported by ase.optimize.")
    optimizer = optimizers[config.optimizer.upper()]
    path, kind = validate_output(output, output_format, config.overwrite)
    distinct_paths(system, path, config.trajectory, config.log_file)
    traj = output_path(config.trajectory, overwrite=config.overwrite, xyz=True) if config.trajectory else None
    log = output_path(config.log_file, overwrite=config.overwrite) if config.log_file else None
    forbidden = {"atoms", "trajectory", "logfile", "maxstep"}.intersection(config.optimizer_kwargs)
    if forbidden:
        raise ValueError(f"Use explicit configuration fields for {sorted(forbidden)}.")
    atoms = prepare(system, config)
    atoms.calc = api._calculator(atoms)
    initial_energy, initial_force = check_finite(atoms)
    with ExitStack() as stack:
        stream = stack.enter_context(traj.open("w")) if traj else None
        log_stream = stack.enter_context(log.open("w")) if log else None
        kwargs = dict(config.optimizer_kwargs)
        if config.optimizer.upper() == "FIRE":
            kwargs.setdefault("downhill_check", True)
        if "maxstep" in inspect.signature(optimizer.__init__).parameters:
            kwargs["maxstep"] = config.maxstep
        opt = stack.enter_context(optimizer(
            atoms, logfile=log_stream, trajectory=None, **kwargs))
        last = -1

        def sample():
            nonlocal last
            check_finite(atoms)
            if stream and opt.nsteps % config.trajectory_interval == 0:
                atoms.info["step"] = opt.nsteps
                write_frame(stream, atoms)
                last = opt.nsteps

        opt.attach(sample, interval=1)
        converged = bool(opt.run(fmax=config.fmax, steps=config.steps))
        _, maximum = check_finite(atoms)
        converged = converged and maximum <= config.fmax
        atoms.info.update(minimization_converged=converged, minimization_steps=opt.nsteps)
        if stream and last != opt.nsteps:
            atoms.info["step"] = opt.nsteps
            write_frame(stream, atoms)
    summary = dict(converged=converged, steps=opt.nsteps, initial_energy_eV=initial_energy,
                   final_energy_eV=float(atoms.get_potential_energy()), initial_fmax=initial_force,
                   final_fmax=maximum, target_fmax=config.fmax, optimizer=config.optimizer,
                   energy_change_eV=float(atoms.get_potential_energy()) - initial_energy,
                   elapsed_seconds=perf_counter() - started,
                   maxstep_angstrom=kwargs.get("maxstep"))
    api.data = Data(operation="minimization", summary=summary, **summary,
                    output=path, trajectory=traj, log_file=log, system=_system_report(atoms),
                    models=getattr(atoms.calc, "mlmd_metadata", {"calculator": type(atoms.calc).__name__}))
    if not converged and config.require_convergence:
        raise RuntimeError(f"Minimization did not converge after {opt.nsteps} steps: "
                           f"maximum force {maximum:.6g} eV/angstrom, target {config.fmax}.")
    # An optimizer does not update momenta; keep them only if explicitly
    # supplied. MD can request initialize_velocities=True after relaxation.
    return finish(atoms, path, kind)


def validate_md(config, atoms):
    if atoms.get_number_of_degrees_of_freedom() <= 0:
        raise ValueError("MD requires at least one unconstrained degree of freedom.")
    for name in ("steps", "trajectory_interval", "log_interval", "checkpoint_interval",
                 "thermostat_chain", "barostat_chain"):
        positive(name, getattr(config, name), integer=True, zero=name == "steps")
    for name in ("timestep_fs", "thermostat_time_fs", "barostat_time_fs", "heavy_mass_multiplier"):
        positive(name, getattr(config, name))
    positive("temperature_K", config.temperature_K, zero=config.ensemble.upper() == "NVE")
    if config.seed is not None:
        positive("seed", config.seed, zero=True, integer=True)
    if config.initialize_velocities not in (None, True, False):
        raise ValueError("initialize_velocities must be None, True, or False.")
    if config.hydrogen_mass is not None:
        positive("hydrogen_mass", config.hydrogen_mass)
    if config.max_velocity_angstrom_fs is not None:
        positive("max_velocity_angstrom_fs", config.max_velocity_angstrom_fs)
    if config.max_force_eV_A is not None:
        positive("max_force_eV_A", config.max_force_eV_A)
    ensemble = config.ensemble.upper()
    if ensemble not in ("NVE", "NVT", "NPT"):
        raise ValueError("ensemble must be NVE, NVT, or NPT.")
    if config.mode not in ("md", "metadynamics"):
        raise ValueError("mode must be 'md' or 'metadynamics'.")
    if (config.mode == "metadynamics") != (config.metadynamics is not None):
        raise ValueError("Metadynamics requires mode='metadynamics' and a MetadynamicsConfig.")
    meta = config.metadynamics
    if meta is not None and (meta.cvs is not None or meta.pause_when is not None):
        if meta.plumed_file is not None or meta.input_lines is not None:
            raise ValueError("Structured cvs/pause_when cannot be combined with custom PLUMED input.")
        if meta.cvs is None:
            raise ValueError("pause_when requires structured cvs; a one-CV sequence is supported.")
        from ._mlmd_metadynamics import normalize_spec
        normalize_spec(meta.cvs, meta.pause_when, atom_count=len(atoms))
    if ensemble == "NVT":
        if config.thermostat.lower() not in ("langevin", "berendsen", "nose-hoover"):
            raise ValueError("NVT thermostat must be langevin, berendsen, or nose-hoover.")
        if config.thermostat.lower() == "nose-hoover" and atoms.constraints:
            raise ValueError("Nose-Hoover chains do not support constrained atoms; use Langevin.")
    if ensemble == "NPT":
        if not atoms.pbc.all() or atoms.cell.rank != 3:
            raise ValueError("NPT requires full 3D PBC and a finite-volume cell.")
        if not np.isfinite(config.pressure_bar):
            raise ValueError("pressure_bar must be finite.")
        if config.barostat.lower() not in ("mtk", "berendsen"):
            raise ValueError("NPT barostat must be mtk or berendsen.")
        if atoms.constraints:
            raise ValueError("NPT cell scaling is unsupported with fixed atoms or SHAKE constraints.")
        if config.barostat.lower() == "berendsen":
            positive("compressibility_per_bar", config.compressibility_per_bar)
    if config.metadynamics is not None and atoms.pbc.any() and not atoms.pbc.all():
        raise ValueError("PLUMED requires full 3D PBC or a nonperiodic system.")


def integrator(atoms, config, rng):
    kwargs = dict(atoms=atoms, timestep=config.timestep_fs * units.fs, trajectory=None, logfile=None)
    ensemble = config.ensemble.upper()
    if ensemble == "NVE":
        from ase.md.verlet import VelocityVerlet
        return VelocityVerlet(**kwargs)
    thermal = dict(temperature_K=config.temperature_K)
    taut = config.thermostat_time_fs * units.fs
    if ensemble == "NVT":
        if config.thermostat.lower() == "langevin":
            from ase.md.langevin import Langevin
            return Langevin(**kwargs, **thermal, friction=1 / taut, fixcm=False, rng=rng)
        if config.thermostat.lower() == "berendsen":
            from ase.md.nvtberendsen import NVTBerendsen
            return NVTBerendsen(**kwargs, **thermal, taut=taut, fixcm=False)
        from ase.md.nose_hoover_chain import NoseHooverChainNVT
        return NoseHooverChainNVT(**kwargs, **thermal, tdamp=taut, tchain=config.thermostat_chain)
    pressure = config.pressure_bar * units.bar
    taup = config.barostat_time_fs * units.fs
    if config.barostat.lower() == "berendsen":
        from ase.md.nptberendsen import NPTBerendsen
        return NPTBerendsen(**kwargs, **thermal, taut=taut, taup=taup, fixcm=False,
                            pressure_au=pressure,
                            compressibility_au=config.compressibility_per_bar / units.bar)
    from ase.md.nose_hoover_chain import IsotropicMTKNPT
    return IsotropicMTKNPT(**kwargs, **thermal, pressure_au=pressure, tdamp=taut,
                           pdamp=taup, tchain=config.thermostat_chain, pchain=config.barostat_chain)


def dynamics(api, atoms, config, *, trajectory, restart=None, bias_context=None, keep_bias=False):
    api.data = Data(operation="md", summary={"status": "failed", "steps": 0})
    validate_md(config, atoms)
    log_pressure = config.ensemble.upper() == "NPT"
    traj = output_path(trajectory, overwrite=config.overwrite, xyz=True) if trajectory else None
    log = output_path(config.log_file, overwrite=config.overwrite) if config.log_file else None
    checkpoint = checkpoint_path(config)
    if checkpoint is not None:
        output_path(checkpoint, overwrite=config.overwrite)
    continuing = bool(bias_context and "biased" in bias_context)
    start_step = (bias_context["step"] if continuing else
                  restart["metadata"]["step"] if restart is not None else 0)
    final_step = start_step + config.steps
    from ase.md.velocitydistribution import Stationary
    try:
        from ase.md.velocitydistribution import thermalize_momenta
    except ImportError:  # ASE 3.27–3.28
        from ase.md.velocitydistribution import MaxwellBoltzmannDistribution as thermalize_momenta
    rng = bias_context["rng"] if continuing else np.random.default_rng(config.seed)
    velocities = atoms.get_velocities() if atoms.has("momenta") else None
    masses = atoms.get_masses()
    hydrogen = atoms.numbers == 1
    if config.hydrogen_mass is not None:
        masses[hydrogen] = config.hydrogen_mass
    masses[~hydrogen] *= config.heavy_mass_multiplier
    atoms.set_masses(masses)
    if velocities is not None:
        atoms.set_velocities(velocities)
    initialize = config.initialize_velocities
    if initialize is None:
        initialize = not atoms.has("momenta")
    if initialize:
        thermalize_momenta(atoms, temperature_K=config.temperature_K, rng=rng)
        if config.remove_com_motion and len(atoms) > 1 and not atoms.constraints:
            Stationary(atoms, preserve_temperature=config.temperature_K > 0)
    elif not atoms.has("momenta"):
        raise ValueError("initialize_velocities=False requires input momenta/velocities.")
    base = api._calculator(atoms)
    if continuing and (base is not bias_context["base"] or
                       (atoms.info["charge"], atoms.info["mult"], tuple(atoms.pbc)) != bias_context["system"]):
        raise ValueError("Continuous equilibration bias requires the same potential, charge, multiplicity and PBC.")
    atoms.calc = base
    check_finite(atoms)
    # Fail before creating outputs if a custom MLIP has no pressure derivative.
    if config.ensemble.upper() == "NPT":
        atoms.get_stress()
    biased = None
    lines = None
    if config.metadynamics is not None:
        from ._mlmd_plumed import BiasedCalculator, input_lines
        lines = (bias_context["lines"] if continuing else restart["plumed_input"] if restart is not None
                 else input_lines(config.metadynamics, atoms, config))
        if config.metadynamics.save_input is not None and not continuing:
            saved = output_path(config.metadynamics.save_input, overwrite=config.overwrite)
            saved.write_text("\n".join(lines) + "\n")
        if continuing:
            biased = bias_context["biased"]
            biased.md_step = start_step
            biased.need_stress = config.ensemble.upper() == "NPT"
        else:
            biased = BiasedCalculator(base, atoms, config.metadynamics, config, lines,
                                      restart=restart is not None, start_step=start_step)
        atoms.calc = biased
        if restart is not None:
            # Controlled METAD initialization primes PLUMED without depositing.
            # Restore the checkpoint's integration caches after that operation.
            biased.md_step = start_step
            biased.updated_step = start_step
            biased.atoms = atoms.copy()
            biased.results = {key.removeprefix("bias_"): value.copy()
                              for key, value in restart["arrays"].items() if key.startswith("bias_")}
    start = perf_counter()
    completed = start_step
    last_checkpoint = None
    samples = 0
    means, counts = {}, {}
    initial_sample = final_sample = None
    status = "failed"
    failure = None
    try:
        with ExitStack() as stack:
            stream = stack.enter_context(traj.open("w")) if traj else None
            log_stream = stack.enter_context(log.open("w")) if log else None
            if log_stream:
                log_header, log_row = _log_formats(log_pressure, final_step)
                log_stream.write(log_header)
            dyn = stack.enter_context(integrator(atoms, config, rng))
            original_step = dyn.step
            dyn.step_wall_seconds = 0.0

            def timed_step(*args, **kwargs):
                step_start = perf_counter()
                try:
                    return original_step(*args, **kwargs)
                finally:
                    dyn.step_wall_seconds = perf_counter() - step_start

            dyn.step = timed_step
            if restart is not None:
                restore_integrator(dyn, rng, restart)
            elif continuing:
                dyn.nsteps = start_step
            for _ in dyn.irun(config.steps):
                step = dyn.nsteps
                completed = step
                energy, maximum = check_finite(atoms, config.max_velocity_angstrom_fs, config.max_force_eV_A)
                atoms.info.update(step=step, time_fs=step * config.timestep_fs)
                values = _sample(atoms, energy, maximum, base, dyn.step_wall_seconds,
                                 include_pressure=log_pressure)
                if initial_sample is None:
                    initial_sample = dict(values)
                final_sample = dict(values)
                if stream and (step % config.trajectory_interval == 0 or step in (start_step, final_step)):
                    write_frame(stream, atoms)
                if log_stream and (step % config.log_interval == 0 or step in (start_step, final_step)):
                    log_stream.write(log_row.format(step=step, time_fs=step * config.timestep_fs, **values))
                    log_stream.flush()
                if step % config.log_interval == 0 or step in (start_step, final_step):
                    samples += 1
                    for key, value in values.items():
                        if np.isfinite(value):
                            counts[key] = counts.get(key, 0) + 1
                            previous = means.get(key) if counts[key] > 1 else 0.0
                            means[key] = previous + (value - previous) / counts[key]
                        else:
                            means.setdefault(key, None)
                            counts.setdefault(key, 0)
                save_now = checkpoint is not None and (
                    (step > start_step and step % config.checkpoint_interval == 0) or step == final_step)
                if biased is not None:
                    # A retained bias is not finalized at the phase boundary.
                    # Flush its history even if equilibration checkpoints are
                    # disabled, so a zero-step production snapshot is complete.
                    biased.update_bias(atoms, checkpoint=save_now or (keep_bias and step == final_step))
                if save_now:
                    save_checkpoint(checkpoint, atoms, config, dyn, rng, lines=lines, biased=biased)
                    last_checkpoint = step
                if biased is not None:
                    biased.md_step = step + 1
            status = "complete"
    except BaseException as exc:
        failure = {"type": type(exc).__name__, "message": str(exc)}
        raise
    finally:
        if biased is not None:
            if keep_bias and status == "complete":
                bias_context.update(biased=biased, base=base, lines=lines, step=completed, rng=rng,
                                    system=(atoms.info["charge"], atoms.info["mult"], tuple(atoms.pbc)))
            else:
                biased.close()
                if bias_context is not None:
                    bias_context.clear()
            atoms.calc = base
        elapsed = perf_counter() - start
        steps = completed - start_step
        summary = dict(status=status, steps=steps, start_step=start_step,
                       last_step=completed, time_fs=completed * config.timestep_fs,
                       simulation_time_fs=steps * config.timestep_fs,
                       elapsed_seconds=elapsed, ensemble=config.ensemble.upper(),
                       mode=config.mode, samples=samples,
                       averages=means, finite_samples=counts,
                       initial=initial_sample, final=final_sample, failure=failure,
                       performance=dict(ms_per_step=1000 * elapsed / steps if steps else None,
                                        ns_per_day=steps * config.timestep_fs * .0864 / elapsed
                                        if steps and elapsed > 0 else None))
        api.data = Data(operation="md", summary=summary, **summary,
                        trajectory=traj, log_file=log, plumed_input=lines,
                        checkpoint_file=checkpoint, checkpoint_step=last_checkpoint,
                        system=_system_report(atoms),
                        models=getattr(base, "mlmd_metadata", {"calculator": type(base).__name__}),
                        settings=dict(timestep_fs=config.timestep_fs, temperature_K=config.temperature_K,
                                      thermostat=config.thermostat, thermostat_time_fs=config.thermostat_time_fs,
                                      barostat=config.barostat, pressure_bar=config.pressure_bar,
                                      trajectory_interval=config.trajectory_interval, log_interval=config.log_interval,
                                      hydrogen_mass=config.hydrogen_mass, heavy_mass_multiplier=config.heavy_mass_multiplier))
        if log is not None and status == "complete":
            # Use the finalized report, including cleanup time, for matching diagnostics.
            with log.open("a") as stream:
                _write_log_summary(stream, summary)
    return atoms


def equilibrate(api, system, config, output, output_format, *, bias_context=None, keep_bias=False):
    started = perf_counter()
    if config.equilibration is not None:
        raise ValueError("EquilibrationConfig cannot contain another equilibration.")
    path, kind = validate_output(output, output_format, config.overwrite)
    md_paths(system, config, path)
    atoms = prepare(system, config)
    validate_md(config, atoms)
    phases = {}
    if config.minimization is not None:
        relaxed = api.minimize(atoms, config.minimization)
        phases["minimization"] = api.data.summary
        atoms = prepare(relaxed, config)
    try:
        atoms = dynamics(api, atoms, config, trajectory=config.trajectory,
                         bias_context=bias_context, keep_bias=keep_bias)
    finally:
        api.data.operation = "equilibration"
        api.data.output = path
        _workflow_report(api, phases, started)
    return finish(atoms, path, kind)


def _validate_bias_continuation(atoms, config):
    eq = config.equilibration
    if eq is None or config.metadynamics is None or eq.metadynamics is None:
        raise ValueError("continue_equilibration_bias requires metadynamics in both equilibration and production.")
    if config.mode != "metadynamics" or eq.mode != "metadynamics":
        raise ValueError("Continuous bias requires mode='metadynamics' in both phases.")
    if config.timestep_fs != eq.timestep_fs or config.temperature_K != eq.temperature_K:
        raise ValueError("Continuous bias requires identical timestep_fs and temperature_K in both phases.")
    if config.ensemble.upper() != eq.ensemble.upper():
        raise ValueError("Continuous bias requires the same ensemble so PLUMED grid semantics remain unchanged.")
    if config.seed is not None and eq.seed is not None and config.seed != eq.seed:
        raise ValueError("Continuous bias carries the RNG; use matching seeds or leave one seed unset.")

    def normalized(meta):
        result = asdict(meta)
        for name in ("plumed_file", "hills_file", "colvar_file", "log_file", "save_input"):
            if result[name] is not None:
                result[name] = str(Path(result[name]).expanduser().resolve())
        if result["input_lines"] is not None:
            result["input_lines"] = tuple(result["input_lines"])
        return result

    if normalized(config.metadynamics) != normalized(eq.metadynamics):
        raise ValueError("Continuous bias requires identical MetadynamicsConfig settings and shared bias files.")
    initial_eq = prepare(atoms, eq)
    if (not np.array_equal(initial_eq.cell, atoms.cell) or not np.array_equal(initial_eq.pbc, atoms.pbc)
            or initial_eq.info["charge"] != atoms.info["charge"] or initial_eq.info["mult"] != atoms.info["mult"]):
        raise ValueError("Continuous bias cannot override the cell, PBC, charge or multiplicity between phases.")


def run_md(api, system, config):
    started = perf_counter()
    if config.trajectory is None:
        raise ValueError("MD requires a trajectory XYZ path.")
    md_paths(system, config)
    trajectory = output_path(config.trajectory, overwrite=config.overwrite, xyz=True)
    if config.log_file:
        output_path(config.log_file, overwrite=config.overwrite)
    atoms = prepare(system, config)
    validate_md(config, atoms)
    if config.continue_equilibration_bias:
        _validate_bias_continuation(atoms, config)
    # Phase transitions use just one State; their trajectories remain on disk.
    phases = {}
    if config.minimization is not None:
        opt = config.minimization
        distinct_paths(system, config.trajectory, config.log_file, checkpoint_path(config),
                       opt.trajectory, opt.log_file)
        atoms = prepare(api.minimize(atoms, config.minimization), config)
        phases["minimization"] = api.data.summary
    bias_context = {} if config.continue_equilibration_bias else None
    try:
        if config.equilibration is not None:
            eq = config.equilibration
            distinct_paths(system, config.trajectory, config.log_file, checkpoint_path(config),
                           eq.trajectory, eq.log_file, checkpoint_path(eq))
            eq = replace(eq, hydrogen_mass=config.hydrogen_mass if eq.hydrogen_mass is None else eq.hydrogen_mass,
                         heavy_mass_multiplier=config.heavy_mass_multiplier
                         if eq.heavy_mass_multiplier == 1.0 else eq.heavy_mass_multiplier)
            if bias_context is not None:
                eq = replace(eq, seed=config.seed if eq.seed is None else eq.seed)
                relaxed = equilibrate(api, atoms, eq, None, "state", bias_context=bias_context, keep_bias=True)
            else:
                relaxed = api.equilibrate(atoms, eq)
            # Preserve the cell produced by NPT equilibration.
            atoms = prepare(relaxed, replace(config, cell=None))
            phases["equilibration"] = api.data.summary
            # Do not apply mass multipliers or redraw velocities a second time.
            config = replace(config, hydrogen_mass=None, heavy_mass_multiplier=1.0,
                             initialize_velocities=False)
        dynamics(api, atoms, config, trajectory=trajectory, bias_context=bias_context)
    finally:
        if bias_context and "biased" in bias_context:
            bias_context["biased"].close()
            bias_context.clear()
        _workflow_report(api, phases, started)
    return trajectory
