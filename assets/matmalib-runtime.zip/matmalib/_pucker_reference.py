"""Canonical puckering references (degrees).

CARPPY_PUCKERS is adapted from CarP/utilities.py::ring_pucker_dict at
EChung0111/CarPpy commit 4589b228cf8772b0f2bd6ccae8bb2f41ad1e7d70.
CarPpy numbers the ring carbons 1–5 and the ring oxygen 6.
"""

from math import atan, degrees, sqrt


# Ideal Cremer–Pople (theta, phi), distinct from the three dihedrals below.
# Ring order is O, C1, C2, C3, C4, C5; 6 denotes O. With the negative-sine
# phase convention, an envelope raising O has phi=0 and theta=atan(sqrt(2)).
# Half-chairs have theta=atan(sqrt(3/2)); opposite puckers are antipodal.
_ENVELOPE_THETA = degrees(atan(sqrt(2)))
_HALF_CHAIR_THETA = degrees(atan(sqrt(3 / 2)))
CREMER_POPLE_PUCKERS = {
    '4C1': (0.0, 180.0),
    '1C4': (180.0, 180.0),
    '3,6B': (90.0, 0.0),
    '3S1': (90.0, 30.0),
    'B1,4': (90.0, 60.0),
    '5S1': (90.0, 90.0),
    '2,5B': (90.0, 120.0),
    '2S6': (90.0, 150.0),
    'B3,6': (90.0, 180.0),
    '1S3': (90.0, 210.0),
    '1,4B': (90.0, 240.0),
    '1S5': (90.0, 270.0),
    'B2,5': (90.0, 300.0),
    '6S2': (90.0, 330.0),
    '6E': (_ENVELOPE_THETA, 0.0),
    'E1': (_ENVELOPE_THETA, 60.0),
    '2E': (_ENVELOPE_THETA, 120.0),
    'E3': (_ENVELOPE_THETA, 180.0),
    '4E': (_ENVELOPE_THETA, 240.0),
    'E5': (_ENVELOPE_THETA, 300.0),
    '3E': (180 - _ENVELOPE_THETA, 0.0),
    'E4': (180 - _ENVELOPE_THETA, 60.0),
    '5E': (180 - _ENVELOPE_THETA, 120.0),
    'E6': (180 - _ENVELOPE_THETA, 180.0),
    '1E': (180 - _ENVELOPE_THETA, 240.0),
    'E2': (180 - _ENVELOPE_THETA, 300.0),
    '6H1': (_HALF_CHAIR_THETA, 30.0),
    '2H1': (_HALF_CHAIR_THETA, 90.0),
    '2H3': (_HALF_CHAIR_THETA, 150.0),
    '4H3': (_HALF_CHAIR_THETA, 210.0),
    '4H5': (_HALF_CHAIR_THETA, 270.0),
    '6H5': (_HALF_CHAIR_THETA, 330.0),
    '3H4': (180 - _HALF_CHAIR_THETA, 30.0),
    '5H4': (180 - _HALF_CHAIR_THETA, 90.0),
    '5H6': (180 - _HALF_CHAIR_THETA, 150.0),
    '1H6': (180 - _HALF_CHAIR_THETA, 210.0),
    '1H2': (180 - _HALF_CHAIR_THETA, 270.0),
    '3H2': (180 - _HALF_CHAIR_THETA, 330.0),
}


CARPPY_PUCKERS = {
    '1C4': (-35.26, -35.26, -35.26),
    '4C1': (35.26, 35.26, 35.26),
    '1,4B': (-35.26, 74.2, -35.26),
    'B1,4': (35.26, -74.2, 35.26),
    '2,5B': (74.2, -35.26, -35.26),
    'B2,5': (-74.2, 35.26, 35.26),
    '3,6B': (-35.26, -35.26, 74.2),
    'B3,6': (35.26, 35.26, -74.2),
    '1H2': (-42.16, 9.07, -17.83),
    '2H1': (42.16, -9.07, 17.83),
    '2H3': (42.16, 17.83, -9.06),
    '3H2': (-42.16, -17.83, 9.06),
    '3H4': (-17.83, -42.16, 9.07),
    '4H3': (17.83, 42.16, -9.07),
    '4H5': (-9.07, 42.16, 17.83),
    '5H4': (9.07, -42.16, -17.83),
    '5H6': (9.07, -17.83, -42.16),
    '6H5': (-9.07, 17.83, 42.16),
    '6H1': (17.83, -9.07, 42.16),
    '1H6': (-17.83, 9.07, -42.16),
    '1S3': (0.0, 50.84, -50.84),
    '3S1': (0.0, -50.84, 50.84),
    '5S1': (50.84, -50.84, 0.0),
    '1S5': (-50.84, 50.84, 0.0),
    '6S2': (-50.84, 0.0, 50.84),
    '2S6': (50.84, 0.0, -50.84),
    '1E': (-35.26, 17.37, -35.26),
    'E1': (35.26, -17.37, 35.26),
    '2E': (46.86, 0.0, 0.0),
    'E2': (-46.86, 0.0, 0.0),
    '3E': (-35.26, -35.26, 17.37),
    'E3': (35.26, 35.26, -17.37),
    '4E': (0.0, 46.86, 0.0),
    'E4': (0.0, -46.86, 0.0),
    '5E': (17.37, -35.26, -35.26),
    'E5': (-17.37, 35.26, 35.26),
    '6E': (0.0, 0.0, 46.86),
    'E6': (0.0, 0.0, -46.86),
}
