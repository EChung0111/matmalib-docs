"""Atomic, pickle-free MD snapshots; trajectory history stays on disk."""

from dataclasses import asdict, replace
import json
import os
from pathlib import Path
import shutil
from tempfile import NamedTemporaryFile
from zipfile import ZipFile

import ase
from ase import Atoms, units
import numpy as np

from ._mlmd_io import output_path, positive

# ASE's extended-system coordinates are not contained in Atoms.
_STATE_FIELDS = {
    "": ("_q", "_p", "_eps", "_p_eps", "_volume0", "_cell0"),
    "_thermostat": ("_eta", "_p_eta"),
    "_barostat": ("_xi", "_p_xi"),
}


def checkpoint_path(config):
    if config.checkpoint_file is None:
        return None
    if config.checkpoint_file != "auto":
        return Path(config.checkpoint_file).expanduser().resolve()
    source = config.trajectory or config.log_file or "equilibration"
    return Path(source).expanduser().resolve().with_suffix(".checkpoint.npz")


def _json_default(value):
    if isinstance(value, os.PathLike):
        return os.fspath(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(f"Checkpoint metadata cannot encode {type(value).__name__}.")


def _state(dyn):
    result = {}
    for owner, fields in _STATE_FIELDS.items():
        obj = getattr(dyn, owner, None) if owner else dyn
        for name in fields:
            if hasattr(obj, name):
                result[f"{owner}/{name}"] = getattr(obj, name)
    return result


def restore_integrator(dyn, rng, snapshot):
    meta = snapshot["metadata"]
    if meta["integrator"] != type(dyn).__name__:
        raise ValueError("Checkpoint integrator does not match the requested simulation.")
    expected = _state(dyn)
    if set(meta["integrator_state"]) != set(expected):
        raise ValueError("Incompatible ASE integrator state in checkpoint.")
    for key, value in meta["integrator_state"].items():
        owner, name = key.split("/")
        obj = getattr(dyn, owner) if owner else dyn
        old = expected[key]
        if isinstance(old, np.ndarray):
            value = np.asarray(value, dtype=old.dtype)
            if value.shape != old.shape or not np.isfinite(value).all():
                raise ValueError("Invalid integrator array in checkpoint.")
        elif not np.isfinite(value):
            raise ValueError("Invalid integrator scalar in checkpoint.")
        setattr(obj, name, value)
    rng.bit_generator.state = meta["rng_state"]
    dyn.nsteps = meta["step"]


def save_checkpoint(path, atoms, config, dyn, rng, *, lines=None, biased=None):
    constraints = []
    for constraint in atoms.constraints:
        record = constraint.todict()
        if record["name"] == "FixBondLengths" and constraint.bondlengths is not None:
            record["kwargs"]["bondlengths"] = np.asarray(constraint.bondlengths).tolist()
        constraints.append(record)
    meta_config = config.metadynamics
    portable_bias = meta_config is None or (
        meta_config.plumed_file is None and meta_config.input_lines is None)
    # Preparation is complete; a restart must not repeat it.
    saved_config = asdict(replace(config, minimization=None, equilibration=None,
                                 continue_equilibration_bias=False))
    for name in ("trajectory", "log_file"):
        if saved_config[name] is not None:
            saved_config[name] = str(Path(saved_config[name]).expanduser().resolve())
    if meta_config is not None:
        for name in ("hills_file", "colvar_file"):
            saved_config["metadynamics"][name] = str(Path(getattr(meta_config, name)).expanduser().resolve())
    metadata = dict(format="matmalib-mlmd-checkpoint", version=1,
                    ase_version=ase.__version__, step=dyn.nsteps,
                    time_fs=dyn.nsteps * config.timestep_fs,
                    charge=atoms.info["charge"], mult=atoms.info["mult"],
                    config=saved_config, constraints=constraints,
                    integrator=type(dyn).__name__, integrator_state=_state(dyn),
                    rng_state=rng.bit_generator.state, plumed_input=lines,
                    portable_bias=portable_bias)
    arrays = dict(numbers=atoms.numbers, positions=atoms.positions,
                  velocities_angstrom_fs=atoms.get_velocities() * units.fs,
                  momenta=atoms.get_momenta(), masses=atoms.get_masses(),
                  cell=atoms.cell.array, pbc=atoms.pbc)
    if biased is not None:
        for key in ("energy", "free_energy", "forces", "stress"):
            if key in biased.results:
                arrays[f"bias_{key}"] = np.asarray(biased.results[key])
    path = Path(path)
    temporary = None
    try:
        with NamedTemporaryFile(dir=path.parent, prefix=f".{path.name}.", delete=False) as file:
            temporary = Path(file.name)
            with ZipFile(file, "w") as archive:
                archive.writestr("metadata.json", json.dumps(metadata, default=_json_default))
                for name, array in arrays.items():
                    with archive.open(f"{name}.npy", "w", force_zip64=True) as stream:
                        np.lib.format.write_array(stream, np.asarray(array), allow_pickle=False)
                if meta_config is not None and portable_bias:
                    # Native output is flushed before this snapshot. ZipFile.write
                    # streams growing HILLS/COLVAR files instead of loading them.
                    for role in ("hills", "colvar"):
                        archive.write(getattr(meta_config, f"{role}_file"), f"plumed/{role}")
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def load_checkpoint(path):
    from ase.constraints import dict2constraint
    with ZipFile(path) as archive:
        metadata = json.loads(archive.read("metadata.json"))
        if metadata.get("format") != "matmalib-mlmd-checkpoint" or metadata.get("version") != 1:
            raise ValueError("Unsupported mlmd checkpoint format.")
        if metadata["ase_version"] != ase.__version__:
            raise ValueError(f"Restart requires ASE {metadata['ase_version']} used by the checkpoint.")
        positive("checkpoint step", metadata["step"], integer=True, zero=True)
        arrays = {}
        for name in ("numbers", "positions", "momenta", "velocities_angstrom_fs", "masses", "cell", "pbc",
                     "bias_energy", "bias_free_energy", "bias_forces", "bias_stress"):
            if f"{name}.npy" in archive.namelist():
                with archive.open(f"{name}.npy") as stream:
                    arrays[name] = np.lib.format.read_array(stream, allow_pickle=False)
                if not np.isfinite(arrays[name]).all():
                    raise ValueError(f"Nonfinite checkpoint field: {name}.")
    atoms = Atoms(numbers=arrays["numbers"], positions=arrays["positions"],
                  cell=arrays["cell"], pbc=arrays["pbc"], masses=arrays["masses"],
                  momenta=arrays["momenta"])
    if np.any(atoms.get_masses() <= 0) or not np.allclose(
            atoms.get_velocities() * units.fs, arrays["velocities_angstrom_fs"], rtol=1e-12, atol=1e-15):
        raise ValueError("Inconsistent checkpoint velocities or masses.")
    atoms.info.update(charge=metadata["charge"], mult=metadata["mult"],
                      step=metadata["step"], time_fs=metadata["time_fs"])
    atoms.set_constraint([dict2constraint(c) for c in metadata["constraints"]])
    return {"metadata": metadata, "atoms": atoms, "arrays": arrays}


def restart(api, checkpoint, steps, trajectory, log_file, checkpoint_file):
    from ._mlmd_dynamics import dynamics, md_paths, distinct_paths
    positive("steps", steps, integer=True, zero=True)
    source = Path(checkpoint).expanduser().resolve()
    snapshot = load_checkpoint(source)
    metadata = snapshot["metadata"]
    if not metadata["portable_bias"]:
        raise ValueError("Automatic bias restart supports generated MetadynamicsConfig input. "
                         "Custom PLUMED actions require their own restart-state handling.")
    fields = dict(metadata["config"])
    if fields["metadynamics"] is not None:
        fields["metadynamics"] = api.MetadynamicsConfig(**fields["metadynamics"])
    config = api.MDConfig(**fields)
    if trajectory is None:
        original = Path(config.trajectory or config.log_file or source)
        trajectory = source.parent / f"{original.stem}.restart-{metadata['step']}.xyz"
    traj = output_path(trajectory, overwrite=False, xyz=True)
    config = replace(config, steps=steps, trajectory=traj, log_file=log_file,
                     checkpoint_file=checkpoint_file, overwrite=False,
                     hydrogen_mass=None, heavy_mass_multiplier=1.0, initialize_velocities=False)
    directory = None
    if config.metadynamics is not None:
        directory = traj.with_suffix(".plumed")
        if directory.exists():
            raise FileExistsError(f"Restart PLUMED directory already exists: {directory}")
        if any(c.isspace() for c in str(directory)):
            raise ValueError("PLUMED restart output paths must not contain whitespace.")
        old_meta = config.metadynamics
        new_meta = replace(old_meta, hills_file=directory / "HILLS", colvar_file=directory / "COLVAR",
                           log_file=None, save_input=directory / "plumed.dat")
        lines = list(metadata["plumed_input"])
        replacements = {}
        for role in ("hills", "colvar"):
            old = str(Path(getattr(old_meta, f"{role}_file")).expanduser().resolve())
            new = str(getattr(new_meta, f"{role}_file"))
            replacements[f"FILE={old}"] = f"FILE={new}"
        # Generated paths have no whitespace. Replace complete FILE tokens in
        # one pass: HILLS may be a prefix of the COLVAR path (e.g. data/data.cv).
        lines = [" ".join(replacements.get(token, token) for token in line.split()) for line in lines]
        snapshot["plumed_input"] = lines
        config = replace(config, metadynamics=new_meta)
    distinct_paths(source, traj, log_file, checkpoint_path(config))
    md_paths(source, config)
    if directory is not None:
        directory.mkdir(parents=True, exist_ok=True)
        with ZipFile(source) as archive:
            for role in ("hills", "colvar"):
                with archive.open(f"plumed/{role}") as inp, \
                        Path(getattr(config.metadynamics, f"{role}_file")).open("xb") as out:
                    shutil.copyfileobj(inp, out, length=1024 * 1024)
    dynamics(api, snapshot["atoms"], config, trajectory=traj, restart=snapshot)
    api.data.restarted_from = source
    return traj
