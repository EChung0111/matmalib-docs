import matplotlib
import numpy as np
import matplotlib.pyplot as plt
import os
import sys
import colormaps
import copy
from math import log
from numbers import Integral, Real
from dataclasses import dataclass, asdict
import matplotlib as mpl
from matplotlib.ticker import NullFormatter
from matplotlib.ticker import FormatStrFormatter
from matplotlib.colors import LinearSegmentedColormap, ListedColormap, Normalize
from matplotlib.ticker import FuncFormatter, MaxNLocator
from numpy.ma.extras import average


class _PuckerContourTransform(mpl.transforms.Transform):
    """Project contour rings separately, including on Matplotlib 3.10.

    Older geographic transforms interpolate across MOVETO/CLOSEPOLY codes
    in compound paths, introducing false wedges between islands and holes.
    """

    input_dims = output_dims = 2

    def __init__(self, projection):
        super().__init__()
        self._projection = projection
        self.set_children(projection)

    def transform_non_affine(self, values):
        return self._projection.transform(values)

    def transform_path_non_affine(self, path):
        if not len(path.vertices):
            return path
        if path.codes is None:
            return self._projection.transform_path(path)
        starts = np.flatnonzero(path.codes == mpl.path.Path.MOVETO)
        stops = np.r_[starts[1:], len(path.vertices)]
        projected = []
        for start, stop in zip(starts, stops):
            vertices = path.vertices[start:stop].copy()
            codes = path.codes[start:stop]
            vertices[codes == mpl.path.Path.CLOSEPOLY] = vertices[0]
            projected.append(self._projection.transform_path(mpl.path.Path(vertices, codes)))
        return mpl.path.Path.make_compound_path(*projected)

    def inverted(self):
        return self._projection.inverted()


def _pucker_energy_contours(energy, longitude, latitude):
    """Refine the display using only occupied bins; retain holes and the seam."""
    from scipy.interpolate import RegularGridInterpolator

    weights = (~np.ma.getmaskarray(energy)).astype(float)
    weighted_energy = energy.filled(0)

    def pad(values):
        seam = (values[:, :1] + values[:, -1:]) / 2
        values = np.concatenate((seam, values, seam), axis=1)
        return np.concatenate((values[:1], values, values[-1:]))

    longitude = np.r_[-np.pi, longitude, np.pi]
    latitude = np.r_[-np.pi / 2, latitude, np.pi / 2]

    def refine(coordinates):
        # Include every original center exactly; only the drawing grid changes.
        return np.r_[np.linspace(coordinates[:-1], coordinates[1:], 9, axis=1)[:, :-1].ravel(),
                     coordinates[-1]]

    fine_longitude, fine_latitude = refine(longitude), refine(latitude)
    yy, xx = np.meshgrid(fine_latitude, fine_longitude, indexing="ij")
    points = np.stack((yy, xx), axis=-1)
    grid = (latitude, longitude)
    support = RegularGridInterpolator(grid, pad(weights))(points)
    numerator = RegularGridInterpolator(grid, pad(weighted_energy))(points)
    values = np.divide(numerator, support, out=np.zeros_like(numerator), where=support > 0)
    # Half-occupancy outlines round off the original rectangular cells. Empty
    # bin centers remain masked, and zeros never bias the interpolated energy.
    return fine_longitude, fine_latitude, np.ma.array(values, mask=support < .5)


class Plot():
    """
    A class that creates plots from a numpy array.
    It can make reaction coordinate diagrams, RMSD and RMSF trajectory plots,
    Free energy plots, Scatter Plots, and SNFG Figures.
    """

    def __init__(self):

        """
        Construct a plot object with default configuration and colors.
        """

        config_dict = {
            'xrange': None,
            'yrange': None,
            'xtick': None,
            'ytick': None,
            'xlabel': None,
            'ylabel': None,
            'title': None,
            'font': None,
            'xextend': None,
            'yextend': None,
            'title_fontsize': None,
            'axis_fontsize': None,
            'tick_fontsize': None,
            'headers': None,
        }

        config = Plot.Config(**config_dict)
        self.config = config

        self.config_dict = config_dict

        # RK: Just set some default colors for ease of use, adjust as needed.
        self.colors = ["#4856d1", "#f3a667", '#e31a1c', '#1f78b4', '#53546c']

    def snfg(self, glycan, **kwargs):
        """Draw SNFG symbols; return (figure, axes) and retain them on this Plot."""
        from .snfg import draw_snfg
        self.fig, self.ax = draw_snfg(glycan, **kwargs)
        return self.fig, self.ax

    def cluster_dendrogram(self, clusters, *, labels=None, ax=None, **kwargs):
        """Plot a ClusterResult's linkage tree in RMSD units.

        Optional labels cover all original conformers; energy-excluded states
        are omitted from the tree. Remaining options go to SciPy dendrogram.
        """
        from scipy.cluster.hierarchy import dendrogram
        if labels is None:
            labels = [str(i) for i in range(len(clusters.labels))]
        if len(labels) != len(clusters.labels):
            raise ValueError("Supply one dendrogram label per original conformer.")
        selected = [labels[i] for i in clusters.included_indices]
        if ax is None:
            self.fig, self.ax = plt.subplots()
        else:
            self.fig, self.ax = ax.figure, ax
        if len(selected) == 1:
            if kwargs.get("orientation", "top") in ("left", "right"):
                self.ax.set_yticks([0], selected)
                self.ax.set_xlim(0, max(1, clusters.threshold * 1.1))
            else:
                self.ax.set_xticks([0], selected)
                self.ax.set_ylim(0, max(1, clusters.threshold * 1.1))
        else:
            kwargs.setdefault("color_threshold", clusters.threshold)
            dendrogram(clusters.linkage, labels=selected, ax=self.ax, **kwargs)
        if kwargs.get("orientation", "top") in ("left", "right"):
            self.ax.set_xlabel("RMSD (coordinate units)")
            self.ax.axvline(clusters.threshold, linestyle="--", color="gray", linewidth=1)
        else:
            self.ax.set_ylabel("RMSD (coordinate units)")
            self.ax.axhline(clusters.threshold, linestyle="--", color="gray", linewidth=1)
        return self.fig, self.ax

    @dataclass
    class Config():
        xrange: list = None
        yrange: list = None
        xtick: list = None
        ytick: list = None
        xlabel: str = None
        ylabel: str = None
        title: str = None
        font: str = None
        xextend: float = None
        yextend: float = None
        title_fontsize: float = None
        axis_fontsize: float = None
        tick_fontsize: float = None
        headers: list = None

    def cmap(self, color_num: int = None, offset: float = 0, map: str = 'ice', reverse: bool = False):
        """
        Generates and processes a colormap with optional offsetting logic.
        :param color_num: (int) Number of discrete colors.
        :param offset: (float) Fractional offset to shift the colormap.
        :param map: (str) Name of the colormap from the colormaps library.

        Also configures the palette for cremer_pople_sphere and updates
        an already-drawn sphere and its colorbar. An explicit cmap argument
        when drawing a new sphere overrides this palette for that call only.
        """
        # Check if the colormap exists in colormaps
        if not hasattr(colormaps, map):
            raise ValueError(f"Colormap '{map}' not found in colormaps library!")

        # Fetch colormap
        colors_obj = getattr(colormaps, map)

        if color_num is not None:
            color_num += 1
        # Ensure the colormap has an array of colors
        if not hasattr(colors_obj, 'colors'):
            raise ValueError(f"The selected colormap '{map}' does not have a valid 'colors' attribute!")

        colormap_colors = colors_obj.colors

        # Validating the shape of colormap_colors
        if len(colormap_colors[0]) != 3:
            raise ValueError(f"Expected RGB colors in the colormap, but got shape {np.array(colormap_colors).shape}.")

        # Applying offset manually

        if offset != 0:
            new_colors = []

            for color in colormap_colors:

                new_color = []
                for color_elm in color:
                    color_elm -= offset

                    if color_elm > 1:
                        color_elm = 1

                    if color_elm < 0:
                        color_elm = 0

                    new_color.append(color_elm)
                new_colors.append(new_color)

            colormap_colors = new_colors

        if reverse:
            colormap_colors = list(reversed(colormap_colors))

        # Discretize the colormap to the required number of colors
        if color_num is not None:
            discrete_colors = np.linspace(0, len(colormap_colors) - 1, color_num, dtype=int)
            self.colors = [colormap_colors[i] for i in discrete_colors]
        else:
            self.colors = np.asarray(colormap_colors).tolist()

        self._pucker_cmap = ListedColormap(self.colors, name=map)
        heatmap = getattr(self, "heatmap", None)
        if heatmap is not None:
            heatmap.set_cmap(self._pucker_cmap)
            heatmap.figure.canvas.draw_idle()

    def savefig(self, filename='fig', format: str = 'png'):
        self.fig.savefig(f"{self.path}/{filename}.{format}", dpi=300, bbox_inches='tight')

    def set_colors(self, colors: list = None):
        self.colors = colors
        if colors is not None:
            self._pucker_cmap = ListedColormap(colors, name="custom")
        elif hasattr(self, "_pucker_cmap"):
            del self._pucker_cmap

    def set_config(self, conf: dict):
        old_conf = self.config_dict

        for key, value in old_conf.items():
            if key not in conf.keys():
                conf[key] = value

        self.config = Plot.Config(**conf)

    def set_axes(self, ax: matplotlib.pyplot.axes):
        from matplotlib import rc

        config = self.config
        config_dict = asdict(config)

        for key, value in config_dict.items():

            if key == 'xrange' and value is not None:
                ax.set_xlim(value[0], value[1])
            if key == 'yrange' and value is not None:
                ax.set_ylim(value[0], value[1])
            if key == 'xticks' and value is not None:
                ax.set_xticks(value)
            if key == 'yticks' and value is not None:
                ax.set_yticks(value)
            if key == 'xlabel' and value is not None:
                ax.set_xlabel(value)
            if key == 'ylabel' and value is not None:
                ax.set_ylabel(value)
            if key == 'title' and value is not None:
                ax.set_title(value)
            if key == 'font' and value is not None:
                mpl.rcParams['font.sans-serif'] = value
                mpl.rcParams['font.family'] = "sans-serif"
            if key == 'axis fontsize' and value is not None:
                mpl.rcParams['axes.labelsize'] = value
            if key == 'title fontsize' and value is not None:
                ax.title.set_size(value)
            if key == 'tick fontsize' and value is not None:
                ax.tick_params(labelsize=value, axis='both')

    def trajectory(self, data_list, var_name='colvar', col=1, average=None, title=None, hist=True, alpha=None,
                   calc_qa=False, overlap=False, headers=None, *, projection=None, monomer=0,
                   pucker_labels=False, cmap=None, bins=(72, 36), num_levels=8,
                   quantity="free_energy", temp=300, energy_unit="kcal/mol"):

        """ Plots MD trajectory with histogram. Takes in data for CP2K or Gromacs via Mol.
        :param data_list: (Mol / List) Either a Data object, or a list of Data objs if you want to overlay data.
        :param var_name: (list) Name of the collective variable you are plotting on your y-axis.
        :param col: (int) Index of the column containing your colvar data, in the case that you have multiple.

        For a Cremer–Pople free-energy map, use cremer_pople_sphere.
        ``projection="mollweide"`` forwards to that method, including monomer,
        pucker_labels, cmap, bins, num_levels, quantity, temp and energy_unit.
        In that view col, var_name and hist do not
        apply; smoothing, overlap and calc_qa are unsupported. With
        projection=None or "rectilinear", the time-series view is used.
        """
        if projection not in (None, "rectilinear", "mollweide"):
            raise ValueError("projection must be None, 'rectilinear', or 'mollweide'.")
        if not isinstance(data_list, list):
            data_list = [data_list]

        if headers is None and self.config.headers is not None:
            headers = self.config.headers

        if projection == "mollweide":
            if (average is not None and np.any(np.asarray(average) > 1)) or overlap or calc_qa:
                raise ValueError("Mollweide heatmaps do not support average, overlap, or calc_qa.")
            return self.cremer_pople_sphere(data_list, monomer=monomer, title=title, alpha=alpha,
                                           headers=headers, pucker_labels=pucker_labels, cmap=cmap,
                                           bins=bins, num_levels=num_levels, quantity=quantity, temp=temp,
                                           energy_unit=energy_unit)

        self.path = data_list[0].path
        # CP2K default timestep unit is in fs, Gromacs is in ps:
        # We convert these to ps and nm respectively:

        #         if mol_list[0].software == 'cp2`k':
        #             time_unit = 'ps'`

        #         elif mol_list[0].software == 'gromacs':
        #             time_unit = self.time_unit

        fig, ax = plt.subplots(1, 2, figsize=(11, 3), gridspec_kw={'width_ratios': [3.5, 1]})

        i = 0

        if alpha == None:
            alpha = [0.8] * len(data_list)

        if average == None:
            average = [0] * len(data_list)

        elif not isinstance(average, list):
            average = [average] * len(data_list)

        if headers == None:
            headers = [None for i in range(len(data_list))]

        for header, datum in zip(headers, data_list):

            residue = False

            if datum.time_unit == 'fs':
                time = (datum.data[:, 0] / 1000).tolist()  # fs -> ps for CP2K
                time_label = 'ps'

            elif datum.time_unit == 'ps':
                time = (datum.data[:, 0] / 1000).tolist()  # ps -> ns for GROMACS
                time_label = 'ns'

            elif datum.time_unit == 'ns':
                time = (datum.data[:, 0]).tolist()  # if GROMACS already in ns don't convert
                time_label = 'ns'

            elif datum.time_unit == 'Residue':
                time = (datum.data[:, 0]).tolist()  # if GROMACS in residue, also don't convert
                time_label = 'residue'
                residue = True

            colvar = datum.data[:, col].tolist()

            timestep = np.abs(time[0] - time[1])

            if not hasattr(self, 'colors'):
                self.cmap(color_num=len(data_list), offset=0, map='ice')

            color = self.colors

            if average[i] > 1:
                array_len = len(colvar)
                # conv_kernel = np.ones(average[i])/array_len
                conv_kernel = np.ones(average[i]) / average[i]
                colvar_conv = np.convolve(colvar, conv_kernel, mode='valid').tolist()
                time = time[:-1 * average[i] + 1]

            if overlap == True:

                ax[0].plot(time, colvar_conv, linewidth=2, color=color[i], alpha=alpha[i], label=header)
                ax[0].plot(time, colvar[:(len(colvar_conv))], linewidth=0.8, color=color[i], alpha=alpha[i] * .3)
                ax[1].hist(colvar, bins='rice', orientation="horizontal", color=color[i], alpha=alpha[i])

            elif overlap == False and average[i] > 1:
                ax[0].plot(time, colvar_conv, linewidth=0.8, color=color[i], alpha=alpha[i], label=header)

            else:
                ax[0].plot(time, colvar, linewidth=0.8, color=color[i], alpha=alpha[i], label=header)
                ax[1].hist(colvar, bins='rice', orientation="horizontal", color=color[i], alpha=alpha[i],
                           label=np.round(np.average(colvar)))

            if calc_qa == True:

                nbins = 50
                hist = np.histogram(colvar[500:], nbins, range=(min(colvar), max(colvar)))

                dmin = np.argmin(hist[0][15:23]) + 15
                bs = np.sum(hist[0][:dmin + 1]);
                us = np.sum(hist[0][dmin + 1:])

                if us == 0:
                    Qa = 1000.0; boundary = 0.0

                else:
                    Qa = float(bs) / float(us);
                    boundary = float(dmin) / 10

                # ax[1].fill_between([0, ax[1].get_xlim()[1]], boundary, boundary+0.1, color='0.8')

                # Only annotate Qas if one trajectory is entered, otherwise print them.
                if len(data_list) == 1:
                    ax[1].axhline(y=boundary, color='gray', linestyle='-', alpha=0.5, linewidth=5)

                    textstr = r'$Q_a$={0:3.2f}'.format(Qa)
                    ax[1].text(0.55 * ax[1].get_xlim()[1], 0.95 * ax[1].get_ylim()[1], textstr, fontsize=14,
                               verticalalignment='top')

                else:
                    print(f"mol{i + 1} Qa = {np.round(Qa, 3)}")

            # if len(data_list) == 1:
            #    ax[1].set_title(f"average = {np.round(np.average(colvar), 3)}", fontsize = 10)

            # else:

            # x= (np.round(np.average(colvar), 3))
            # ax[1].legend()
            # print(x)

            # print(f"average = {np.round(np.average(colvar), 2)}")

            i = i + 1

        if headers[0] is not None:
            ax[0].legend(loc='upper right')

        if not residue:
            ax[0].set_xlabel(f"time ({time_label}); stepsize = {timestep}{time_label}")

        else:
            ax[0].set_xlabel(f"{time_label}")

        ax[0].set_ylabel(var_name)

        if title != None:
            ax[0].set_title(f"{title}", fontsize=10)

        if hist == False:
            fig.delaxes(ax[1])

        if not residue:
            xmax = ax[0].get_xlim()[1]
            xmax = xmax + 1
            ax[0].set_xlim(0, xmax)

        ax[1].set_xlabel('structures')

        self.set_axes(ax[0])

        if ax[1].get_ylim() != ax[0].get_ylim():
            ax[1].set_ylim(ax[0].get_ylim())

        # Hard code the y axis of the histogram to align with the trajectory:
        for key, value in self.config_dict.items():
            if key == 'yrange' and value is not None:
                ax[1].set_ylim(value[0], value[1])

        plt.tight_layout()
        self.fig = fig
        self.ax = ax

    def cremer_pople_sphere(self, data_list, *, monomer=0, cmap=None, title=None,
                           alpha=None, headers=None, pucker_labels=False, figsize=(8, 4),
                           bins=(72, 36), num_levels=8, quantity="free_energy", temp=300,
                           energy_unit="kcal/mol"):
        """Plot relative free energy on a Mollweide Cremer–Pople sphere.

        Accept a Data or list of Data returned by cremer_pople_trajectory.
        Select a zero-based six-membered ``monomer`` (default 0). Named theta
        and phi columns are required; angle_unit is degrees or radians. Each
        valid row contributes one conformer, irrespective of time or order.
        Multiple datasets are pooled into one histogram. ``bins`` is a positive
        integer or a (phi, theta) pair of bin counts; the default (72, 36) gives
        5-degree cells. By default, each occupied bin has free energy
        ``-R * temp * log(N / Nmax)``, using R = 8.314 J/(mol K) and
        ``temp=300`` kelvin, matching Plot.fes. ``energy_unit`` defaults to
        "kcal/mol"; "kJ/mol" is also supported (1 kcal = 4.184 kJ).
        The most populated bin is
        zero; empty bins are masked. This uses counts per angular cell, with
        no spherical-area correction or reweighting. ``quantity="counts"``
        restores the population map.

        Filled contours interpolate between sampled bin centers using
        ``num_levels`` color bands (default 8). In free-energy mode, a finer
        drawing grid interpolates energies using occupied neighbors and rounds
        the boundary at half occupancy. Isolated samples remain visible and
        empty bin centers stay white. This changes only the rendering, not the
        stored populations or energies. A light dashed grid marks CP angles.
        Use the palette configured by Plot.cmap() or Plot.set_colors(), or a
        pastel green palette by default. An explicit ``cmap`` Matplotlib name
        or object overrides it for this plot. The vertical colorbar on the
        right shows free energy in the selected unit, or Number of conformers
        in count mode.

        Longitude is 180-phi degrees and latitude is 90-theta; tick labels show
        CP angles in degrees. Phi wraps at 0/360 degrees. Pure chairs are
        counted at the poles using phi=180, where phase is arbitrary; planar
        frames and other undefined angles are omitted. Set pucker_labels=True
        to annotate the 38 ideal puckers. Labels assume
        O, C1, ..., C5 ring order, with O denoting position 6 in classification
        results.

        ``figsize`` defaults to (8, 4) inches and ``alpha`` to 1. Alpha must be
        common to all pooled datasets. Headers are joined into a default title.
        Supports title and label/font configuration; configured axis limits
        are unsupported. Return (figure, axes), also stored as fig and ax on
        this Plot; heatmap and colorbar hold the filled contours and Colorbar.
        conformer_counts holds the exact integer histogram in displayed
        (latitude, longitude) order, with latitude_edges and longitude_edges
        in radians. In free-energy mode, free_energy holds the masked energy
        grid in the same order and in the selected energy_unit.
        """
        from ._pucker_reference import CREMER_POPLE_PUCKERS

        if not isinstance(data_list, list):
            data_list = [data_list]
        if not data_list:
            raise ValueError("Supply at least one Cremer–Pople trajectory.")
        if isinstance(monomer, bool) or not isinstance(monomer, Integral) or monomer < 0:
            raise ValueError("monomer must be a nonnegative integer.")
        if self.config.xrange is not None or self.config.yrange is not None:
            raise ValueError("Mollweide axes have fixed limits; remove xrange and yrange from the plot config.")
        try:
            bin_counts = (bins, bins) if isinstance(bins, Integral) else tuple(bins)
        except TypeError:
            raise ValueError("bins must be a positive integer or a (phi, theta) pair of positive integers.") from None
        if len(bin_counts) != 2 or any(isinstance(n, bool) or not isinstance(n, Integral) or n <= 0
                                       for n in bin_counts):
            raise ValueError("bins must be a positive integer or a (phi, theta) pair of positive integers.")
        if isinstance(num_levels, bool) or not isinstance(num_levels, Integral) or num_levels <= 0:
            raise ValueError("num_levels must be a positive integer.")
        if quantity not in ("free_energy", "counts"):
            raise ValueError("quantity must be 'free_energy' or 'counts'.")
        if not isinstance(temp, Real) or isinstance(temp, bool) or not np.isfinite(temp) or temp <= 0:
            raise ValueError("temp must be finite and positive, in kelvin.")
        if energy_unit not in ("kcal/mol", "kJ/mol"):
            raise ValueError("energy_unit must be 'kcal/mol' or 'kJ/mol'.")
        if headers is None and self.config.headers is not None:
            headers = self.config.headers
        if headers is None:
            headers = [None] * len(data_list)
        if len(headers) != len(data_list):
            raise ValueError("Supply one header per dataset.")
        if alpha is None or np.isscalar(alpha):
            alpha = [1.0 if alpha is None else alpha] * len(data_list)
        if len(alpha) != len(data_list):
            raise ValueError("Supply one alpha value per dataset, or a single shared value.")
        alpha = np.asarray(alpha, dtype=float)
        if not np.all(np.isfinite(alpha) & (alpha >= 0) & (alpha <= 1)):
            raise ValueError("alpha must lie between 0 and 1.")
        if not np.all(alpha == alpha[0]):
            raise ValueError("Pooled heatmaps require the same alpha for all datasets.")

        if cmap is None:
            colormap = getattr(self, "_pucker_cmap", None)
            if colormap is None:
                colormap = LinearSegmentedColormap.from_list(
                    "pucker_green", ["#b7efbe", "#88e2b2", "#58cfa4"]
                )
        else:
            colormap = mpl.colormaps.get_cmap(cmap)
        phi_edges = np.linspace(0, 2 * np.pi, bin_counts[0] + 1)
        theta_edges = np.linspace(0, np.pi, bin_counts[1] + 1)
        counts = np.zeros(bin_counts, dtype=np.int64)
        for datum in data_list:
            columns = tuple(getattr(datum, "columns", ()))
            theta_name, phi_name = f"monomer_{monomer}.theta", f"monomer_{monomer}.phi"
            if theta_name not in columns or phi_name not in columns:
                raise ValueError(
                    f"Mollweide projection requires six-membered Cremer–Pople data with "
                    f"{theta_name} and {phi_name} columns."
                )
            values = np.asarray(datum.data, dtype=float)
            if values.ndim != 2 or values.shape[0] == 0 or values.shape[1] != len(columns):
                raise ValueError("Trajectory data must be a nonempty 2D array matching its columns.")
            theta, phi = values[:, [columns.index(theta_name), columns.index(phi_name)]].T
            unit = getattr(datum, "angle_unit", None)
            if unit == "degrees":
                theta, phi = np.radians(theta), np.radians(phi)
            elif unit != "radians":
                raise ValueError("Cremer–Pople angle_unit must be 'degrees' or 'radians'.")
            if np.any(np.isfinite(theta) & ((theta < 0) | (theta > np.pi))):
                raise ValueError("Cremer–Pople theta must lie between 0 and 180 degrees (0 and pi radians).")

            # Phase is arbitrary at a pole: count all pure chairs together.
            poles = np.isclose(theta, 0, atol=1e-12, rtol=0) | np.isclose(theta, np.pi, atol=1e-12, rtol=0)
            phi = np.where(poles, np.pi, phi)
            valid = np.isfinite(theta) & np.isfinite(phi)
            histogram, _, _ = np.histogram2d(phi[valid] % (2 * np.pi), theta[valid],
                                            bins=(phi_edges, theta_edges))
            counts += histogram.astype(np.int64)

        maximum = int(counts.max())
        fig, ax = plt.subplots(figsize=figsize, subplot_kw={"projection": "mollweide"},
                               layout="constrained")
        fig.set_facecolor("white")
        ax.set_facecolor("white")
        # Both CP angles decrease along the displayed axes.
        self.conformer_counts = counts.T[::-1, ::-1].copy()
        self.longitude_edges = np.pi - phi_edges[::-1]
        self.latitude_edges = np.pi / 2 - theta_edges[::-1]
        longitude = (self.longitude_edges[:-1] + self.longitude_edges[1:]) / 2
        latitude = (self.latitude_edges[:-1] + self.latitude_edges[1:]) / 2

        self.free_energy = None
        if quantity == "free_energy":
            occupied = self.conformer_counts > 0
            self.free_energy = np.ma.masked_all(self.conformer_counts.shape, dtype=float)
            if maximum:
                gas_constant = .008314 / (4.184 if energy_unit == "kcal/mol" else 1)
                self.free_energy[occupied] = gas_constant * temp * (
                    np.log(maximum) - np.log(self.conformer_counts[occupied])
                )
            upper = max(1., float(np.ceil(self.free_energy.max()))) if maximum else 1.
            norm = Normalize(0, upper)
            levels = np.linspace(0, upper, num_levels + 1)
            longitude, latitude, field = _pucker_energy_contours(
                self.free_energy, longitude, latitude,
            )
        else:
            norm = Normalize(0, max(1, maximum))
            # A half-count threshold retains isolated samples in count mode.
            levels = np.linspace(.5, maximum + .5, min(num_levels, maximum) + 1) if maximum else [0, 1]
            values = self.conformer_counts if maximum else np.ma.masked_all(self.conformer_counts.shape)

            # Wrap the seam and extend edge rows to the poles in count mode.
            seam = (values[:, :1] + values[:, -1:]) / 2
            field = np.ma.concatenate((seam, values, seam), axis=1)
            field = np.ma.concatenate((field[:1], field, field[-1:]))
            longitude = np.r_[-np.pi, longitude, np.pi]
            latitude = np.r_[-np.pi / 2, latitude, np.pi / 2]
        heatmap = ax.contourf(longitude, latitude, field, levels=levels,
                              cmap=colormap, norm=norm, alpha=alpha[0], zorder=1,
                              corner_mask=True)
        heatmap.set_transform(_PuckerContourTransform(ax.transProjection) + ax.transAffine + ax.transAxes)

        ax.set_longitude_grid(30)
        ax.set_latitude_grid(30)
        # Geographic axes place the secondary x labels below the equator,
        # leaving space above it for boat and skew-boat annotations.
        ax.tick_params(axis="x", labeltop=True, labelbottom=False)
        ax.tick_params(axis="both", labelsize=8)
        ax.xaxis.set_major_formatter(FuncFormatter(lambda x, pos: f"{180 - np.degrees(x):.0f}°"))
        ax.yaxis.set_major_formatter(FuncFormatter(lambda y, pos: f"{90 - np.degrees(y):.0f}°"))
        ax.set_xlabel(r"$\phi$ (degrees)", fontsize=9)
        ax.set_ylabel(r"$\theta$ (degrees)", fontsize=9)
        ax.set_axisbelow(False)
        ax.grid(True, color="0.75", linewidth=.65, linestyle="--", zorder=3)
        ax.spines["geo"].set_color("0.3")
        ax.spines["geo"].set_linewidth(.8)

        if pucker_labels:
            reference_points = []
            for label, (theta, phi) in CREMER_POPLE_PUCKERS.items():
                family = next(code for code in "CBSHE" if code in label)
                above, below = label.replace("6", "O").split(family)
                text = rf"$^{{{above}}}\mathrm{{{family}}}_{{{below}}}$"
                # Show seam references at both edges, where they identify the
                # same point on the sphere. Offset labels into the map.
                longitudes = (-np.pi, np.pi) if phi == 0 else (np.radians(180 - phi),)
                for longitude in longitudes:
                    latitude = np.radians(90 - theta)
                    reference_points.append((longitude, latitude))
                    dx = 4 if longitude == -np.pi else -4 if longitude == np.pi else 0
                    dy = -7 if theta == 0 else -10 if family == "E" else 6
                    ax.annotate(text, (longitude, latitude), xytext=(dx, dy),
                                textcoords="offset points", fontsize=8, color="0.25",
                                ha="left" if dx > 0 else "right" if dx < 0 else "center",
                                va="top" if theta == 0 else "bottom", zorder=4,
                                bbox=dict(facecolor="white", edgecolor="none", alpha=0.7, pad=0.5))
            ax.scatter(*np.asarray(reference_points).T, s=6, color="0.45", zorder=2)

        if title is None and any(header is not None for header in headers):
            title = ", ".join(str(header) for header in headers if header is not None)
        if title is not None:
            ax.set_title(title, fontsize=11, pad=6)
        self.set_axes(ax)
        self.heatmap = heatmap
        if quantity == "free_energy":
            ticks = np.linspace(0, upper, min(num_levels, 5) + 1) if maximum else [0]
            colorbar_label = f"Free energy ({energy_unit})"
        else:
            ticks = MaxNLocator(nbins=5, integer=True).tick_values(0, max(1, maximum))
            ticks = ticks[(ticks >= 1) & (ticks <= maximum)] if maximum else [0]
            colorbar_label = "Number of conformers"
        self.colorbar = fig.colorbar(heatmap, ax=ax,
                                     orientation="vertical", fraction=0.035, pad=0.035,
                                     shrink=.8, ticks=ticks)
        self.colorbar.set_label(colorbar_label, fontsize=9)
        self.colorbar.ax.tick_params(labelsize=8)
        self.colorbar.outline.set_linewidth(.7)
        self.path = getattr(data_list[0], "path", "")
        self.fig, self.ax = fig, ax
        return fig, ax

    def fes_1d(self, data, *, smooth_window=None, show_raw=True, show_basins=True,
               energy_unit="kJ/mol", ax=None, color="#235789", label=None):
        """Plot the 1D FES returned by ``mlmd.analyze_metadynamics``.

        Uses the analysis script's local cubic smoothing, basin shading and
        projected-barrier marker. Smoothing preserves unsampled gaps and does
        not modify the raw profile or its thermodynamics. Set smooth_window=0
        to disable it. Return (figure, axes), also retained on this Plot.
        ``Plot.fes`` continues to handle two-dimensional population plots.
        """
        from ._mlmd_analysis_core import Profile, smooth_profile
        factors = {"kJ/mol": 1.0, "kcal/mol": 1 / 4.184, "eV": 1 / 96.48533212331002}
        if energy_unit not in factors:
            raise ValueError("energy_unit must be kJ/mol, kcal/mol, or eV.")
        if not hasattr(data, "free_energy") or not hasattr(data, "x"):
            raise TypeError("fes_1d expects Data from mlmd.analyze_metadynamics().")
        x = np.asarray(data.x, dtype=float)
        raw = np.asarray(data.free_energy, dtype=float)
        if (x.ndim != 1 or raw.shape != x.shape or len(x) < 2 or not np.isfinite(x).all()
                or np.any(np.diff(x) <= 0) or not np.isfinite(raw).any()):
            raise ValueError("A 1D FES needs an increasing CV grid and sampled free energies.")
        if getattr(data, "energy_unit", "kJ/mol") != "kJ/mol":
            raise ValueError("Analysis input energies must be in kJ/mol.")
        window = getattr(data, "smooth_window", 11) if smooth_window is None else smooth_window
        if isinstance(window, bool) or not isinstance(window, Integral):
            raise ValueError("smooth_window must be an integer.")
        smooth = smooth_profile(Profile(x, raw), window)
        if ax is None:
            self.fig, self.ax = plt.subplots(figsize=(8, 4.5), constrained_layout=True)
        else:
            self.fig, self.ax = ax.figure, ax
        factor = factors[energy_unit]
        if window and show_raw:
            self.ax.plot(x, np.where(np.isfinite(raw), raw * factor, np.nan),
                         color="#9aa5b1", linewidth=1, alpha=0.45, label="Raw FES")
        self.ax.plot(x, np.where(np.isfinite(smooth), smooth * factor, np.nan),
                     color=color, linewidth=2,
                     label=label or ("Smoothed FES" if window else "FES"))
        summary = getattr(data, "summary", {})
        if show_basins:
            for name, shade in (("reactant", "#38995b"), ("product", "#d48122")):
                if f"{name}_range" in summary:
                    text = name.capitalize()
                    if summary.get("basin_assignment") == "inferred":
                        text += " (inferred)"
                    self.ax.axvspan(*summary[f"{name}_range"], color=shade, alpha=0.15, label=text)
            if "transition_state_cv" in summary:
                self.ax.axvline(summary["transition_state_cv"], color="#a13c4b",
                                linestyle="--", label="Projected barrier")
        self.ax.set(xlabel=f"{getattr(data, 'cv', 'CV')} [{getattr(data, 'cv_unit', 'input units')}]",
                    ylabel=f"Relative free energy [{energy_unit}]")
        if window or label or (show_basins and "reactant_range" in summary):
            self.ax.legend(frameon=False)
        self.set_axes(self.ax)
        self.path = getattr(data, "path", None)
        self.free_energy = raw.copy()
        return self.fig, self.ax

    def fes(self, data, cols=[1, 2], temp=300, num_levels=8):

        """ Plots MD FES. Takes in data for CP2K or Gromacs via Mol.
        :param data: (Data) Class Data.
        :param cols: (int) Index of the 2 columns containing your colvar data, in the case that you have more than 2.
        """

        self.path = data.path
        Temp = temp;
        R = 8.314  # J/K mol

        colvar1 = data.data[:, cols[0]]
        colvar2 = data.data[:, cols[1]]

        Hall, x_edges, y_edges = np.histogram2d(colvar1, colvar2, bins=72)

        Hall = - R * Temp * np.log(Hall)
        hmin = np.min(Hall)

        Hall_rel = 0.001 * (Hall.T - hmin)

        vmin, vmax = 0, np.ceil(np.nanmax(Hall_rel[~np.isinf(Hall_rel)]))
        MHall = np.ma.masked_greater(Hall_rel, vmax)

        fig, ax = plt.subplots(figsize=(6, 6))

        # colors = self.colors
        # cmap = ListedColormap(colors)

        self.set_axes(ax)

        num_levels = num_levels
        plot = ax.contourf(x_edges[:-1], y_edges[:-1], MHall, colors=self.colors, zorder=1, levels=num_levels)
        # plot = ax.contourf(x_edges[:-1], y_edges[:-1], Hall.T, cmap=cmap, zorder=1, levels=num_levels)

        cb_ticks = np.linspace(vmin, vmax, 6)
        cb = fig.colorbar(plot, ax=ax, ticks=cb_ticks, pad=0.05, shrink=0.6)
        cb.ax.set_yticklabels([f"{tick:.1f}" for tick in cb_ticks], fontsize=12)
        cb.set_label("\n Free energy [kJ]", fontsize=14)

        # Enable grid that aligns with ticks
        ax.grid(True, ls='--', zorder=10.0)

        x_range = ax.get_xlim()
        y_range = ax.get_ylim()

        dx = x_range[1] - x_range[0]
        dy = y_range[1] - y_range[0]

        ax.set_aspect(dx/dy, adjustable='box')

        fig.tight_layout()
        self.fig = fig
        self.ax = ax

    def contour(self, xpm_data_list, limit=16):

        """ Plots contour maps for a provided list of moles from xpm files.
        :param xpm_data_list: Data object or list of Data objects read from XPM files.
        :param limit: (Int) The upper limit on your energy scale
        """

        if not isinstance(xpm_data_list, list):
            xpm_data_list = [xpm_data_list]

        if len(xpm_data_list) == 1:
            self.path = xpm_data_list[0].path
        else:
            self.path = xpm_data_list[0].path

        Mat = []

        for xpm_data in xpm_data_list:
            M = xpm_data.data
            MM = np.ma.masked_greater(M, limit - 1)
            Mat.append(MM)

        #         if xpm_mol1 != None and xpm_mol2 != None and xpm_mol3 != None:
        #             M1 = xpm_mol1.data
        #             M2 = xpm_mol2.data
        #             M3 = xpm_mol3.data
        #             MM1 = np.ma.masked_greater(M1, limit-1)
        #             MM2 = np.ma.masked_greater(M2, limit-1)
        #             MM3 = np.ma.masked_greater(M3, limit-1)
        #             Mat = [MM1, MM2, MM3]

        #         elif xpm_mol1 != None and xpm_mol2 != None:
        #             M1 = xpm_mol1.data
        #             M2 = xpm_mol2.data
        #              #DiffM = M1-M2
        #             MM1 = np.ma.masked_greater(M1, limit-1)
        #             MM2 = np.ma.masked_greater(M2, limit-1)
        #             Mat = [MM1, MM2]

        #         else:
        #             raise ValueError("Give me a correct number of some chunky matrices")
        fig, axes = plt.subplots(1, len(Mat), figsize=(4 * len(Mat) + (len(Mat) - 1) * 1, 4), sharex=True, sharey=True)
        # fig, axes = plt.subplots(1,len(Mat), figsize=(4*len(Mat) + 1.5, 4), sharex=True, sharey=True)

        levels = np.linspace(0, limit, 9)  # 8 levels between 0 and limit
        if len(Mat) > 1:
            for n, ax in enumerate(axes):

                self.set_axes(ax)
                dx = ax.get_xlim()[1] - ax.get_xlim()[0]
                dy = ax.get_ylim()[1] - ax.get_ylim()[0]

                ax.set_aspect(dx/dy, adjustable='box')
                ax.grid(True, ls='--', zorder=10.0)

                # Create the contourf plot with consistent levels
                plot = ax.contourf(Mat[n], levels=levels, colors=self.colors, zorder=1)

                # Add a color bar with consistent boundaries and ticks
                cb = fig.colorbar(plot, ax=ax, pad=0.025, aspect=20, ticks=levels, shrink=0.7)
                cb.set_ticklabels(["{0:3.1f}".format(x) for x in levels])
        else:
            self.set_axes(axes)
            dx = axes.get_xlim()[1] - axes.get_xlim()[0]
            dy = axes.get_ylim()[1] - axes.get_ylim()[0]

            axes.set_aspect(dx / dy, adjustable='box')
            axes.grid(True, ls='--', zorder=10.0)

            # Create the contourf plot with consistent levels
            plot = axes.contourf(Mat[0], levels=levels, colors=self.colors, zorder=1)

            # Add a color bar with consistent boundaries and ticks
            cb = fig.colorbar(plot, ax=axes, pad=0.025, aspect=20, ticks=levels, shrink=0.7)
            cb.set_ticklabels(["{0:3.1f}".format(x) for x in levels])

        fig.tight_layout()

        self.fig = fig
        self.ax = axes

    def foo_plot(self, data, SCR=None, w=0.5):

        """ Not a bar plot. Mostly used for SCR stuff
        :param data: (Data) Data objects generated from csv files.
        :param SCR: (list) Specifies specific SCRs to plot from your data. Otherwise, default is to plot them all.
        :param w: (float) Width of the lines in the foo plot.
        """

        color = self.colors
        self.path = data.path

        if SCR == None:

            SCR = []
            for line in data.data[1:]:
                SCR.append(line.split()[0])

        SUG = data.data[0].split();
        data_dict = {}

        for line in data.data[1:]:
            # Doctor Founder says not to transform the data, only plot the data:
            # data[line.split()[0]] = [log(float(i)*(float(i)+1)/C0,10) for i in line.split()[1:]]

            data_dict[line.split()[0]] = [float(i) for i in line.split()[1:]]

        fig, ax = plt.subplots(figsize=(8.0, 4.0))

        ax.tick_params(axis='both', which='both', bottom=True, top=False, labelbottom=True, right=False, left=False,
                       labelleft=True, labelright=False)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.spines['left'].set_visible(False)
        ax.xaxis.set_tick_params(direction='out')

        x_pos = np.arange(len(SUG))
        xmax = len(SUG)

        ax.set_xlim(-1, xmax)

        ymin = 0;
        ymax = np.round(max(val for sublist in data_dict.values() for val in sublist))
        ax.set_ylim(ymin, ymax + 0.1)
        yticks = np.linspace(ymin, ymax, 7)
        ax.set_yticks(yticks)
        # ax.set_yticklabels(yticks)

        ax.set_xticks(x_pos)
        ax.set_xticklabels(SUG)

        # ax.set_xlabel(r'time [ns]')
        for i in yticks:  ax.plot([-1, xmax], [i, i], '0.75', lw=0.5)

        ax.grid(axis='y', color='grey', linestyle='-', linewidth=0.5)

        for n, scr in enumerate(SCR):
            for i in range(len(SUG)):
                ax.plot([x_pos[i] - w / 2, x_pos[i] + w / 2], [data_dict[scr][i], data_dict[scr][i]], color=color[n],
                        lw=2)

                # ax.bar ( x_pos[i], data[scr][i], align='center', color=color[n])

        plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")

        self.set_axes(ax)

        fig.tight_layout()
        self.fig = fig
        self.ax = ax

    def scatter(self, data=None, headers=None, format: str = '.', figsize=(6, 6)):

        """
        Generates a scatter plot from data
        """

        if headers is not None and self.config.headers is not None:
            headers = self.config.headers

        data_list = []
        if isinstance(data, list):
            for set in data:
                data_list.append(set.data)
        else:
            data = data.data
            data_list.append(data)

        if headers != None:
            desc = headers

        # x_extend = 0
        # y_extend = 0

        colors = self.colors if self.colors is not None else ['b', 'r', 'g', 'c', 'm', 'y', 'k']
        fig, ax = plt.subplots(1, 1, figsize=figsize)

        for i, data in enumerate(data_list):

            if data.ndim == 2:
                data_x = data[:, 0]
                data_ys = []
                row_len = len(data[0, :])
            else:
                data_x = data[0]
                data_ys = []
                row_len = len(data)

            nullfmt = NullFormatter()  # no labels

            # fig, ax = plt.subplots(1, figsize=figsize)

            for col in range(1, row_len):
                if data.ndim == 2:
                    data_y = data[:, col]
                    data_ys.append(data_y)
                else:
                    data_y = data[col]
                    data_ys.append(data_y)

                fit = np.polyfit(data_x, data_y, 1)
                val = np.polyval(fit, data_x)

                if headers is not None:
                    if len(data_list) == 1:
                        ax.scatter(data_x, data_y, marker=format, label=desc[col - 1], color=colors[col - 1])
                        ax.legend()
                    else:
                        ax.scatter(data_x, data_y, marker=format, label=desc[i], color=colors[i])
                        ax.legend()

                else:
                    if len(data_list) == 1:
                        ax.scatter(data_x, data_y, marker=format, color=colors[col - 1])
                    else:
                        ax.scatter(data_x, data_y, marker=format, color=colors[i])

        ax.tick_params(axis='both', which='both', bottom=True, top=False, labelbottom=True, right=False, left=True,
                       labelleft=True)
        for s in ['top', 'right']:
            ax.spines[s].set_visible(False)
        ax.xaxis.set_tick_params(direction='out')
        ax.yaxis.set_tick_params(direction='out')

        self.set_axes(ax)

        xmin, xmax = ax.get_xlim()[0], ax.get_xlim()[1]
        ymin, ymax = ax.get_ylim()[0], ax.get_ylim()[1]

        # if x_extend != 0.0 :
        #    xmin -= x_extend ; xmax += x_extend
        #    ax.set_xlim(xmin, xmax)
        #    print(xmin, xmax)

        # if y_extend != 0.0:
        #    ax.set_ylim(ymin-y_extend, ymax)

        # ax.plot([xmin, xmax], [ymin-y_extend, ymin-y_extend], 'k', lw=1)
        # ax.plot([xmin+ax_fit, xmin+ax_fit], [ymin ,ymax], 'k', lw=1)

        plt.tight_layout()
        self.fig = fig
        self.ax = ax

    def gaussian_broadening(self, state, broaden=1, resolution=1):

        """ Performs gaussian broadening on IR spectrum
        generates attribute self.IR - np.array with dimmension 4000/resolution consisting gaussian-boraden spectrum

        :param broaden: (float) gaussian broadening in wn-1
        :param resolution: (float) resolution of the spectrum (number of points for 1 wn) defaults is 1, needs to be fixed in plotting
        """

        IR = np.zeros((int(4000 / resolution) + 1,))
        X = np.linspace(0, 4000, int(4000 / resolution) + 1)
        for f, i in zip(state.Freq, state.Ints):  IR += i * np.exp(-0.5 * ((X - f) / int(broaden)) ** 2)
        state.IR = np.vstack((X, IR)).T  # tspec

    def ir(self, state, xmin=900, xmax=1700, normal_modes: bool = False):

        """ Plots the IR spectrum in xmin -- xmax range,
        x-axis is multiplied by scaling factor, everything
        is normalized to 1. If exp_data is specified,
        then the top panel is getting plotted too.
        Need to add output directory. Default name is self._id
        """

        import matplotlib.pyplot as plt
        from matplotlib.ticker import NullFormatter
        import math

        colors = self.colors
        background_colors = []

        for color in colors:
            color[0] += 0.25
            color[1] += 0.25
            color[2] += 0.25
            background_colors.append(color)

        fig, ax = plt.subplots(1, figsize=(math.ceil(10 * (xmax - xmin) / (1500)), 3))

        self.gaussian_broadening(state, resolution=0.001, broaden=2)

        # left, width = 0.02, 0.98 ; bottom, height = 0.15, 0.8
        # ax  = [left, bottom, width, height ]
        # ax  = plt.axes(ax)
        exten = 20

        ax.tick_params(axis='both', which='both', bottom=True, top=False, labelbottom=True, right=False, left=False,
                       labelleft=False)
        ax.spines['top'].set_visible(False);
        ax.spines['right'].set_visible(False);
        ax.spines['left'].set_visible(False)
        ax.xaxis.set_tick_params(direction='out')
        ax.yaxis.set_major_formatter(NullFormatter())
        ax.set_ylim(0, 1.1)

        xticks = np.linspace(xmin, xmax, int((xmax - xmin + 2 * exten) / 100) + 1)
        ax.set_xticks(xticks)
        ax.set_xticklabels([int(x) for x in xticks], fontsize=10)
        ax.set_xlim(xmin - exten, xmax + exten + 10)

        shift = 0.05
        incr = (state.IR[-1, 0] - state.IR[0, 0]) / (len(state.IR) - 1)
        scale_t = 1 / np.amax(state.IR[int(xmin / incr):int(xmax / incr) + 100, 1])

        Xsc = state.IR[:, 0];
        IRsc = state.IR[:, 1] * scale_t
        ir_theo = ax.plot(Xsc, IRsc + shift, color='k', linewidth=0.5)
        ax.fill_between(Xsc, np.linspace(shift, shift, len(IRsc)), IRsc + shift, color=background_colors[0], alpha=0.5)

        if normal_modes == True:
            for l in range(len(state.Freq)):
                ax.plot([state.Freq[l], state.Freq[l]], [shift, state.Ints[l] * scale_t + shift], linewidth=2,
                        color=colors[0])

        fig.tight_layout()
        current_path = os.getcwd()
        # output_path =  os.path.join(current_path, state.path, state._id+'.png')
        # print(output_path + state._id+'.png')

    def space(self, list_of_spaces, names=None, quant: str = 'E'):

        fig, ax = plt.subplots()

        n = 0

        for space in list_of_spaces:

            # if quant == 'E': data = space.energies
            # elif quant == 'F': data = space.free_energies
            # elif quant == 'H': data = space.enthalpies

            data = space.diff(quant=quant)

            if names == None:
                name = [str(n)] * len(data)
            else:
                name = names[n]

            ax.scatter(name, data, marker='_', linewidths=3, s=700)

            n = n + 1

        if n != 1:
            pad = 1 / (n - 1)
            ax.set_xmargin(pad)

        plt.ylabel(f"{quant} (Ha)")
        plt.xlabel('conformer id')

        self.set_axes(ax)
