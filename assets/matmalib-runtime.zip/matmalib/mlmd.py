"""Machine-learning molecular dynamics, relaxation, and periodic solvation.

Coordinates are in angstrom, energies in eV, times in fs, temperatures in K,
and pressures in bar. PLUMED input uses nm, kJ/mol and ps unless overridden.
Heavy simulation libraries are imported only when an operation is requested.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from os import PathLike
from pathlib import Path
from typing import Any

__all__ = ["mlmd"]


class mlmd:
    """Simulation interface accepting XYZ/PDB paths or matmalib ``State`` objects.

    ``model_path`` accepts one AIMNet inference file, or a sequence of files
    whose predictions are averaged. With no path, all four AIMNet2-2025
    B97-3c/D3 members are used. Registry downloads are managed by AIMNet.
    Other MLIPs can be used by passing an ASE ``calculator`` instance.
    Input systems are copied; no trajectory is accumulated in memory.
    """

    @dataclass
    class SystemConfig:
        cell: Any = None
        pbc: bool | tuple[bool, bool, bool] | None = None
        charge: float | None = None
        multiplicity: int | None = None
        min_distance: float = 0.5
        fixed_atoms: tuple[int, ...] = ()  # zero-based
        fix_com: bool = False  # persistent constraint; also enabled by SHAKE
        shake_hydrogens: bool = False
        shake_cutoff: float = 1.3
        shake_tolerance: float = 1e-6

    @dataclass
    class MinimizationConfig(SystemConfig):
        optimizer: str = "FIRE"
        fmax: float = 0.05
        steps: int = 10000
        maxstep: float = 0.1
        optimizer_kwargs: dict[str, Any] = field(default_factory=dict)
        require_convergence: bool = True
        trajectory: str | PathLike | None = None
        trajectory_interval: int = 1
        log_file: str | PathLike | None = None
        overwrite: bool = False

    @dataclass
    class CVConfig:
        """One generated CV with one-based atom indices and optional grid.

        DISTANCE widths and optional bounds use nm by default, or angstrom
        when unit="angstrom". ANGLE and TORSION use radians. Generated PLUMED
        input and canonical metadata always use nm/radians.
        Omitting all grid fields evaluates hills directly without fixed bounds.
        If supplied, a torsion grid spans the periodic interval [-pi, pi].
        """

        label: str
        type: str
        atoms: tuple[int, ...]
        sigma: float
        grid_min: float | None = None
        grid_max: float | None = None
        grid_bins: int | None = None
        unit: str | None = None

    @dataclass
    class DepositionPause:
        """Pause hills while a CV is >= or <= its threshold; resume afterward.

        The accumulated bias and ordinary trajectory/COLVAR output stay active.
        Thresholds inherit the configured CV unit, or use an explicit unit:
        nm/angstrom for distances and rad/deg for angles. Combine comparisons
        with all/any or use between.
        """

        cv: str
        comparison: str
        threshold: float
        unit: str | None = None

        @staticmethod
        def all(*conditions) -> mlmd.DepositionPauseGroup:
            """Pause while every supplied condition holds."""
            return mlmd.DepositionPauseGroup("all", conditions)

        @staticmethod
        def any(*conditions) -> mlmd.DepositionPauseGroup:
            """Pause while at least one supplied condition holds."""
            return mlmd.DepositionPauseGroup("any", conditions)

        @staticmethod
        def between(cv, lower, upper, *, unit=None) -> mlmd.DepositionPauseGroup:
            """Pause inside an inclusive interval; use any for a periodic seam."""
            from ._mlmd_metadynamics import _real

            lower = _real(lower, "lower pause threshold")
            upper = _real(upper, "upper pause threshold")
            if lower > upper:
                raise ValueError("lower must be <= upper; use any for a torsion interval crossing -pi/pi")
            return mlmd.DepositionPause.all(
                mlmd.DepositionPause(cv, ">=", lower, unit),
                mlmd.DepositionPause(cv, "<=", upper, unit))

    @dataclass
    class DepositionPauseGroup:
        """Combine comparisons or nested groups using operator='all' or 'any'."""

        operator: str
        conditions: tuple[mlmd.DepositionPause | mlmd.DepositionPauseGroup | dict[str, Any], ...]

    @dataclass
    class MetadynamicsConfig:
        # Use cvs for one/two generated CVs; custom input supports arbitrary actions.
        plumed_file: str | PathLike | None = None
        input_lines: tuple[str, ...] | None = None
        save_input: str | PathLike | None = None  # save resolved input for analysis/reproducibility
        cv: str = "DISTANCE"
        cv_label: str = "cv"
        atoms: tuple[int, ...] = (1, 2)  # one-based PLUMED indices
        metad_label: str = "metad"
        metad_arg: str | None = None  # None uses cv_label, or all ordered cvs labels
        sigma: float = 0.02  # nm for DISTANCE, radians for ANGLE/TORSION
        height_kj_mol: float = 2.0
        pace: int = 300
        biasfactor: float = 10.0
        temperature_K: float | None = None
        hills_file: str | PathLike = "HILLS"
        colvar_file: str | PathLike = "COLVAR"
        colvar_stride: int = 10
        colvar_arg: str | None = None  # None selects available CV/bias columns
        wall_type: str | None = None  # UPPER_WALLS or LOWER_WALLS
        wall_label: str = "wall"
        wall_arg: str | None = None  # None uses cv_label
        wall_at: float = 0.35
        wall_kappa: float = 150000.0
        wall_exp: int = 2
        wall_eps: float = 1.0
        wall_offset: float = 0.0
        calc_rct: bool | None = None  # automatic when a valid grid is available
        grid_auto: bool | None = None  # automatic for fixed-cell periodic DISTANCE
        grid_min: float = 0.0
        grid_max: float | None = None
        grid_bins: int | None = None
        grid_spacing: float = 0.002
        log_file: str | PathLike | None = None
        # When supplied, cvs replaces the scalar CV/grid fields above. Dictionaries
        # with the same fields as CVConfig are accepted, including after restart.
        cvs: tuple[mlmd.CVConfig | dict[str, Any], ...] | list | None = None
        pause_when: mlmd.DepositionPause | mlmd.DepositionPauseGroup | dict[str, Any] | None = None

    @dataclass
    class MDConfig(SystemConfig):
        steps: int = 10000
        timestep_fs: float = 0.5
        temperature_K: float = 300.0
        ensemble: str = "NVT"  # NVE, NVT, NPT
        thermostat: str = "langevin"  # NVT: langevin, berendsen, nose-hoover
        barostat: str = "mtk"  # NPT: mtk, berendsen (includes thermostat)
        thermostat_time_fs: float = 100.0
        barostat_time_fs: float = 1000.0
        pressure_bar: float = 1.0
        compressibility_per_bar: float = 4.57e-5  # NPT Berendsen; set for your liquid
        thermostat_chain: int = 3
        barostat_chain: int = 3
        seed: int | None = None
        initialize_velocities: bool | None = None  # None preserves existing momenta
        remove_com_motion: bool = True  # at velocity initialization only
        hydrogen_mass: float | None = None
        heavy_mass_multiplier: float = 1.0
        max_velocity_angstrom_fs: float | None = None  # abort; never clip velocities
        max_force_eV_A: float | None = 150.0  # abort excessive forces; None disables
        trajectory: str | PathLike = "trajectory.xyz"
        trajectory_interval: int = 10
        log_file: str | PathLike | None = "md.log"
        log_interval: int = 10
        checkpoint_interval: int = 1000
        checkpoint_file: str | PathLike | None = "auto"  # None disables checkpoints
        mode: str = "md"  # md or metadynamics
        metadynamics: mlmd.MetadynamicsConfig | None = None
        minimization: mlmd.MinimizationConfig | None = None
        equilibration: mlmd.EquilibrationConfig | None = None
        continue_equilibration_bias: bool = False  # keep live PLUMED bias across phases
        overwrite: bool = False

    @dataclass
    class EquilibrationConfig(MDConfig):
        steps: int = 2000
        thermostat_time_fs: float = 10.0
        max_force_eV_A: float | None = None
        trajectory: str | PathLike | None = None
        log_file: str | PathLike | None = "equilibration.log"

    @dataclass
    class SolvationConfig:
        cell: float | tuple[float, float, float] = 30.0
        density_g_ml: float = 1.0
        counterion: Any = None  # XYZ/State, one copy
        counterion_gap: float = 0.5
        packmol: str | PathLike = "packmol"
        tolerance: float = 2.0
        nloop: int = 1000
        timeout: float = 600.0
        seed: int = 12345
        volume_samples: int = 200000
        vdw_radii: dict[str, float] = field(default_factory=dict)
        work_dir: str | PathLike | None = None  # None uses a temporary directory
        dry_run: bool = False  # write packing inputs/report only; requires work_dir
        charge: float | None = None  # None sums component charges
        multiplicity: int = 1  # multiplicities cannot be added
        overwrite: bool = False

    @dataclass
    class AnalysisConfig:
        colvar: Any = None  # path or sequence of independent infrequent runs
        hills: str | PathLike | None = None
        fes_file: str | PathLike | None = None
        plumed_input: str | PathLike | None = None
        plumed: str | PathLike | None = None  # command-line executable
        cv: str | None = None
        temperature: float | None = None
        energy_unit: str | None = None
        time_unit: str | None = None
        cv_unit: str | None = None
        bins: int = 100
        grid_range: tuple[float, float] | None = None
        energy_column: str = "file.free"
        rbias_column: str | None = None
        bias_column: str | None = None
        rct_column: str | None = None
        additional_bias: tuple[str, ...] | None = None
        start_time: float | None = None
        end_time: float | None = None
        upper_wall: tuple[float, float] | None = None
        keep_wall: bool = False
        reactant: tuple[float, float] | None = None
        product: tuple[float, float] | None = None
        kappa: float = 1.0
        infrequent: bool = False
        acceleration_column: str | None = None
        smooth_window: int = 11
        plot: bool = False  # save using Plot.fes_1d when output_dir is supplied
        output_dir: str | PathLike | None = None
        overwrite: bool = False

    def __init__(self, model_path=None, *, device=None, compile_model=False,
                 calculator=None, model_kwargs=None):
        if calculator is not None and model_path is not None:
            raise ValueError("Choose model_path or calculator, not both.")
        self.model_path = model_path
        self.device = device
        self.compile_model = compile_model
        self.calculator = calculator
        self.model_kwargs = dict(model_kwargs or {})
        self._calculators = {}
        from .core import Data
        self.data = Data()  # structured diagnostics from the most recent operation

    def _calculator(self, atoms):
        if self.calculator is not None:
            return self.calculator
        from ._mlmd_calculators import build_calculator
        # AIMNet may switch its Coulomb treatment on the first periodic call.
        # Keep isolated/periodic adapters separate when reusing an interface.
        key = (atoms.info["charge"], atoms.info["mult"], tuple(atoms.pbc))
        if key not in self._calculators:
            self._calculators[key] = build_calculator(
                self.model_path, charge=key[0], mult=key[1], device=self.device,
                compile_model=self.compile_model, model_kwargs=self.model_kwargs,
            )
        return self._calculators[key]

    def minimize(self, system, config=None, *, output=None, output_format=None):
        """Relax geometry; return a State, or a Path when ``output`` is supplied.

        ``output_format='state'`` returns a State even when writing an XYZ.
        ``output_format='xyz'`` requires an output path. Nonconvergence raises
        unless ``require_convergence=False``; the result records convergence.
        """
        self._require_ase()
        from ._mlmd_dynamics import minimize
        return minimize(self, system, config or self.MinimizationConfig(),
                        output, output_format)

    def equilibrate(self, system, config=None, *, output=None, output_format=None):
        """Run equilibration and return its final State or XYZ path.

        Final masses and momenta are retained for a subsequent production run.
        An optional equilibration trajectory is streamed to its configured path.
        Checkpoints save positions and velocities every 1,000 steps and at
        completion by default, with or without PLUMED.
        """
        self._require_ase()
        from ._mlmd_dynamics import equilibrate
        return equilibrate(self, system, config or self.EquilibrationConfig(),
                           output, output_format)

    def run_md(self, system, config=None, *, trajectory=None) -> Path:
        """Run normal or biased dynamics; return the streamed XYZ trajectory path.

        All ensembles save positions/velocities checkpoints every 1,000 steps and
        at completion by default. This includes ordinary MD and generated or
        custom PLUMED input; PLUMED is not needed for ordinary MD checkpointing.
        """
        self._require_ase()
        from dataclasses import replace
        from ._mlmd_dynamics import run_md
        config = config or self.MDConfig()
        if trajectory is not None:
            config = replace(config, trajectory=trajectory)
        return run_md(self, system, config)

    def restart_md(self, checkpoint, *, steps, trajectory=None, log_file=None,
                   checkpoint_file="auto") -> Path:
        """Continue a checkpoint for ``steps`` additional integration steps.

        Restore velocities, RNG and thermostat/barostat state. Output is a new
        XYZ segment with continuous step/time labels. Use the same calculator
        and model files as the original run. Generated metadynamics input also
        restores its saved HILLS/COLVAR history into a new directory.
        """
        self._require_ase()
        from ._mlmd_checkpoint import restart
        return restart(self, checkpoint, steps, trajectory, log_file, checkpoint_file)

    @staticmethod
    def _require_ase():
        try:
            import ase  # noqa: F401 -- deliberately optional until simulation
        except ImportError as exc:
            raise ImportError("Simulations require ASE: pip install 'matmalib[mlmd]' "
                              "(or 'matmalib[md]' for a supplied ASE calculator).") from exc

    def solvate(self, solute, solvent, config=None, *, output=None, output_format=None):
        """Pack a periodic solvent box; inputs accept XYZ, PDB, or State.

        Density is total mass / box volume. The final State contains a
        ``solvation_report`` with counts, actual density and packing diagnostics.
        ``dry_run=True`` requires ``work_dir`` and returns Data with reusable
        packing inputs and the report; omit output/output_format for a dry run.
        """
        self._require_ase()
        from ._mlmd_solvation import solvate
        return solvate(self, solute, solvent, config or self.SolvationConfig(),
                       output, output_format)

    def analyze_metadynamics(self, config=None, *, output_format="data"):
        """Analyze a 1D FES and optional infrequent kinetics from PLUMED files.

        Return a matmalib Data object accepted by ``Plot.fes_1d``. It is also
        stored as ``self.data``. With ``output_format='files'``, require
        ``config.output_dir`` and return that directory after writing CSV/JSON.
        """
        from ._mlmd_analysis import analyze
        return analyze(self, config or self.AnalysisConfig(), output_format)

    @staticmethod
    def validate_metadynamics(cvs, pause_when=None, atom_count=None):
        """Return validated CV/pause metadata without loading simulation extras.

        Accept CVConfig, DepositionPause and DepositionPauseGroup objects or
        equivalent dictionaries. Atom numbers are one-based; canonical values
        use nm/radians. Distance inputs may use angstrom and angular pause
        thresholds may use degrees; conversion happens once during validation.
        """
        from ._mlmd_metadynamics import normalize_spec
        return normalize_spec(cvs, pause_when, atom_count)

    @staticmethod
    def read_metadynamics_spec(lines):
        """Read generated CV/pause metadata from canonical saved PLUMED lines.

        Also recognizes the earlier AIMNET notebook marker for portable restarts.
        Return None for legacy scalar or arbitrary custom input without metadata.
        """
        from ._mlmd_metadynamics import parse_marker
        return parse_marker(lines)

    @staticmethod
    def analyze_two_cv(colvar, cv_specs, *, temperature_K, bins=(80, 80), ranges=None,
                       start_ps=0.0, time_column="time", bias_column="metad.rbias",
                       energy_unit="kJ/mol", window_ends_ps=None, output_dir=None,
                       overwrite=False):
        """Reweight COLVAR into a 2D FES, integrated marginals and time windows.

        Normalized bias is read in kJ/mol and time in ps. Empty bins retain
        infinite free energy. Return arrays, diagnostics and optional artifacts.
        This operation does not require ASE or PLUMED.
        """
        from ._mlmd_analysis_2d import analyze_two_cv
        return analyze_two_cv(
            colvar, cv_specs, temperature_K=temperature_K, bins=bins, ranges=ranges,
            start_ps=start_ps, time_column=time_column, bias_column=bias_column,
            energy_unit=energy_unit, window_ends_ps=window_ends_ps,
            output_dir=output_dir, overwrite=overwrite)

    @staticmethod
    def plot_two_cv(result, *, vmax=None, distance_unit="nm"):
        """Plot a reweighted FES; distance axes may display nm or angstrom."""
        from ._mlmd_analysis_2d import plot_two_cv
        return plot_two_cv(result, vmax=vmax, distance_unit=distance_unit)

    @staticmethod
    def plot_two_cv_windows(result, *, vmax=None, distance_unit="nm"):
        """Plot cumulative FES estimates with distance axes in nm or angstrom."""
        from ._mlmd_analysis_2d import plot_two_cv_windows
        return plot_two_cv_windows(result, vmax=vmax, distance_unit=distance_unit)

    @staticmethod
    def reconstruct_two_cv_hills(hills_file, cv_specs, *, output_dir, bins=(80, 80),
                                 energy_unit="kcal/mol", temperature_K=None, overwrite=False):
        """Reconstruct a 2D HILLS FES using native PLUMED in this process.

        HILLS must use kJ/mol, as in the generated metadynamics input. Returns
        DAT/NPZ/PNG paths and provenance; existing outputs are protected by default.
        Grid-free CVs infer plotting extents from HILLS. Supply temperature_K to
        include integrated one-dimensional marginal profiles.
        """
        from ._mlmd_hills_2d import reconstruct_two_cv_hills
        return reconstruct_two_cv_hills(
            hills_file, cv_specs, output_dir=output_dir, bins=bins,
            energy_unit=energy_unit, temperature_K=temperature_K, overwrite=overwrite)

    @staticmethod
    def read_two_cv_fes(path, cv_specs, *, energy_unit="kcal/mol", temperature_K=None):
        """Read a native PLUMED sum_hills grid, whose stored energy is kJ/mol.

        Supply temperature_K to integrate marginal probability/free-energy profiles.
        """
        from ._mlmd_hills_2d import read_two_cv_fes
        return read_two_cv_fes(path, cv_specs, energy_unit=energy_unit, temperature_K=temperature_K)

    @staticmethod
    def plot_two_cv_hills(result, *, distance_unit="nm"):
        """Plot a native HILLS reconstruction with distance axes in nm or angstrom."""
        from ._mlmd_hills_2d import plot_two_cv_hills
        return plot_two_cv_hills(result, distance_unit=distance_unit)
