"""Machine-learning molecular dynamics, relaxation, and periodic solvation.

Coordinates are in angstrom, energies in eV, times in fs, temperatures in K,
and pressures in bar. PLUMED input uses nm, kJ/mol and ps unless overridden.
Heavy simulation libraries are imported only when an operation is requested.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from os import PathLike
from pathlib import Path
from typing import Any

__all__ = ["mlmd"]


class mlmd:
    """Simulation interface accepting XYZ/PDB paths or matmalib ``State`` objects.

    ``model_path`` accepts one AIMNet inference file, or a sequence of files
    whose predictions are averaged. With no path, all four AIMNet2-2025
    B97-3c/D3 members are used. Registry downloads are managed by AIMNet.
    Other MLIPs can be used by passing an ASE ``calculator`` instance.
    Input systems are copied; no trajectory is accumulated in memory.
    """

    @dataclass
    class SystemConfig:
        cell: Any = None
        pbc: bool | tuple[bool, bool, bool] | None = None
        charge: float | None = None
        multiplicity: int | None = None
        min_distance: float = 0.5
        fixed_atoms: tuple[int, ...] = ()  # zero-based
        fix_com: bool = False  # persistent constraint; also enabled by SHAKE
        shake_hydrogens: bool = False
        shake_cutoff: float = 1.3
        shake_tolerance: float = 1e-6

    @dataclass
    class MinimizationConfig(SystemConfig):
        optimizer: str = "FIRE"
        fmax: float = 0.05
        steps: int = 10000
        maxstep: float = 0.1
        optimizer_kwargs: dict[str, Any] = field(default_factory=dict)
        require_convergence: bool = True
        trajectory: str | PathLike | None = None
        trajectory_interval: int = 1
        log_file: str | PathLike | None = None
        overwrite: bool = False

    @dataclass
    class MetadynamicsConfig:
        # Supply a PLUMED file or lines for arbitrary/multiple collective variables.
        plumed_file: str | PathLike | None = None
        input_lines: tuple[str, ...] | None = None
        save_input: str | PathLike | None = None  # save resolved input for analysis/reproducibility
        cv: str = "DISTANCE"
        cv_label: str = "cv"
        atoms: tuple[int, ...] = (1, 2)  # one-based PLUMED indices
        metad_label: str = "metad"
        metad_arg: str | None = None  # None uses cv_label
        sigma: float = 0.02  # nm for DISTANCE, radians for ANGLE/TORSION
        height_kj_mol: float = 2.0
        pace: int = 300
        biasfactor: float = 10.0
        temperature_K: float | None = None
        hills_file: str | PathLike = "HILLS"
        colvar_file: str | PathLike = "COLVAR"
        colvar_stride: int = 10
        colvar_arg: str | None = None  # None selects available CV/bias columns
        wall_type: str | None = None  # UPPER_WALLS or LOWER_WALLS
        wall_label: str = "wall"
        wall_arg: str | None = None  # None uses cv_label
        wall_at: float = 0.35
        wall_kappa: float = 150000.0
        wall_exp: int = 2
        wall_eps: float = 1.0
        wall_offset: float = 0.0
        calc_rct: bool | None = None  # automatic when a valid grid is available
        grid_auto: bool | None = None  # automatic for fixed-cell periodic DISTANCE
        grid_min: float = 0.0
        grid_max: float | None = None
        grid_bins: int | None = None
        grid_spacing: float = 0.002
        log_file: str | PathLike | None = None

    @dataclass
    class MDConfig(SystemConfig):
        steps: int = 10000
        timestep_fs: float = 0.5
        temperature_K: float = 300.0
        ensemble: str = "NVT"  # NVE, NVT, NPT
        thermostat: str = "langevin"  # NVT: langevin, berendsen, nose-hoover
        barostat: str = "mtk"  # NPT: mtk, berendsen (includes thermostat)
        thermostat_time_fs: float = 100.0
        barostat_time_fs: float = 1000.0
        pressure_bar: float = 1.0
        compressibility_per_bar: float = 4.57e-5  # NPT Berendsen; set for your liquid
        thermostat_chain: int = 3
        barostat_chain: int = 3
        seed: int | None = None
        initialize_velocities: bool | None = None  # None preserves existing momenta
        remove_com_motion: bool = True  # at velocity initialization only
        hydrogen_mass: float | None = None
        heavy_mass_multiplier: float = 1.0
        max_velocity_angstrom_fs: float | None = None  # abort; never clip velocities
        max_force_eV_A: float | None = 150.0  # abort excessive forces; None disables
        trajectory: str | PathLike = "trajectory.xyz"
        trajectory_interval: int = 10
        wrap_output: bool = False
        log_file: str | PathLike | None = "md.log"
        log_interval: int = 10
        checkpoint_interval: int = 1000
        checkpoint_file: str | PathLike | None = "auto"  # None disables checkpoints
        mode: str = "md"  # md or metadynamics
        metadynamics: mlmd.MetadynamicsConfig | None = None
        minimization: mlmd.MinimizationConfig | None = None
        equilibration: mlmd.EquilibrationConfig | None = None
        continue_equilibration_bias: bool = False  # keep live PLUMED bias across phases
        overwrite: bool = False

    @dataclass
    class EquilibrationConfig(MDConfig):
        steps: int = 2000
        thermostat_time_fs: float = 10.0
        max_force_eV_A: float | None = None
        trajectory: str | PathLike | None = None
        log_file: str | PathLike | None = "equilibration.log"

    @dataclass
    class SolvationConfig:
        cell: float | tuple[float, float, float] = 30.0
        density_g_ml: float = 1.0
        counterion: Any = None  # XYZ/State, one copy
        counterion_gap: float = 0.5
        packmol: str | PathLike = "packmol"
        tolerance: float = 2.0
        nloop: int = 1000
        timeout: float = 600.0
        seed: int = 12345
        volume_samples: int = 200000
        vdw_radii: dict[str, float] = field(default_factory=dict)
        work_dir: str | PathLike | None = None  # None uses a temporary directory
        dry_run: bool = False  # write packing inputs/report only; requires work_dir
        charge: float | None = None  # None sums component charges
        multiplicity: int = 1  # multiplicities cannot be added
        overwrite: bool = False

    @dataclass
    class AnalysisConfig:
        colvar: Any = None  # path or sequence of independent infrequent runs
        hills: str | PathLike | None = None
        fes_file: str | PathLike | None = None
        plumed_input: str | PathLike | None = None
        plumed: str | PathLike | None = None  # command-line executable
        cv: str | None = None
        temperature: float | None = None
        energy_unit: str | None = None
        time_unit: str | None = None
        cv_unit: str | None = None
        bins: int = 100
        grid_range: tuple[float, float] | None = None
        energy_column: str = "file.free"
        rbias_column: str | None = None
        bias_column: str | None = None
        rct_column: str | None = None
        additional_bias: tuple[str, ...] | None = None
        start_time: float | None = None
        end_time: float | None = None
        upper_wall: tuple[float, float] | None = None
        keep_wall: bool = False
        reactant: tuple[float, float] | None = None
        product: tuple[float, float] | None = None
        kappa: float = 1.0
        infrequent: bool = False
        acceleration_column: str | None = None
        smooth_window: int = 11
        plot: bool = False  # save using Plot.fes_1d when output_dir is supplied
        output_dir: str | PathLike | None = None
        overwrite: bool = False

    def __init__(self, model_path=None, *, device=None, compile_model=False,
                 calculator=None, model_kwargs=None):
        if calculator is not None and model_path is not None:
            raise ValueError("Choose model_path or calculator, not both.")
        self.model_path = model_path
        self.device = device
        self.compile_model = compile_model
        self.calculator = calculator
        self.model_kwargs = dict(model_kwargs or {})
        self._calculators = {}
        from .core import Data
        self.data = Data()  # structured diagnostics from the most recent operation

    def _calculator(self, atoms):
        if self.calculator is not None:
            return self.calculator
        from ._mlmd_calculators import build_calculator
        # AIMNet may switch its Coulomb treatment on the first periodic call.
        # Keep isolated/periodic adapters separate when reusing an interface.
        key = (atoms.info["charge"], atoms.info["mult"], tuple(atoms.pbc))
        if key not in self._calculators:
            self._calculators[key] = build_calculator(
                self.model_path, charge=key[0], mult=key[1], device=self.device,
                compile_model=self.compile_model, model_kwargs=self.model_kwargs,
            )
        return self._calculators[key]

    def minimize(self, system, config=None, *, output=None, output_format=None):
        """Relax geometry; return a State, or a Path when ``output`` is supplied.

        ``output_format='state'`` returns a State even when writing an XYZ.
        ``output_format='xyz'`` requires an output path. Nonconvergence raises
        unless ``require_convergence=False``; the result records convergence.
        """
        self._require_ase()
        from ._mlmd_dynamics import minimize
        return minimize(self, system, config or self.MinimizationConfig(),
                        output, output_format)

    def equilibrate(self, system, config=None, *, output=None, output_format=None):
        """Run equilibration and return its final State or XYZ path.

        Final masses and momenta are retained for a subsequent production run.
        An optional equilibration trajectory is streamed to its configured path.
        Checkpoints save positions and velocities every 1,000 steps and at
        completion by default, with or without PLUMED.
        """
        self._require_ase()
        from ._mlmd_dynamics import equilibrate
        return equilibrate(self, system, config or self.EquilibrationConfig(),
                           output, output_format)

    def run_md(self, system, config=None, *, trajectory=None) -> Path:
        """Run normal or biased dynamics; return the streamed XYZ trajectory path.

        All ensembles save positions/velocities checkpoints every 1,000 steps and
        at completion by default. This includes ordinary MD and generated or
        custom PLUMED input; PLUMED is not needed for ordinary MD checkpointing.
        """
        self._require_ase()
        from dataclasses import replace
        from ._mlmd_dynamics import run_md
        config = config or self.MDConfig()
        if trajectory is not None:
            config = replace(config, trajectory=trajectory)
        return run_md(self, system, config)

    def restart_md(self, checkpoint, *, steps, trajectory=None, log_file=None,
                   checkpoint_file="auto") -> Path:
        """Continue a checkpoint for ``steps`` additional integration steps.

        Restore velocities, RNG and thermostat/barostat state. Output is a new
        XYZ segment with continuous step/time labels. Use the same calculator
        and model files as the original run. Generated metadynamics input also
        restores its saved HILLS/COLVAR history into a new directory.
        """
        self._require_ase()
        from ._mlmd_checkpoint import restart
        return restart(self, checkpoint, steps, trajectory, log_file, checkpoint_file)

    @staticmethod
    def _require_ase():
        try:
            import ase  # noqa: F401 -- deliberately optional until simulation
        except ImportError as exc:
            raise ImportError("Simulations require ASE: pip install 'matmalib[mlmd]' "
                              "(or 'matmalib[md]' for a supplied ASE calculator).") from exc

    def solvate(self, solute, solvent, config=None, *, output=None, output_format=None):
        """Pack a periodic solvent box; inputs accept XYZ, PDB, or State.

        Density is total mass / box volume. The final State contains a
        ``solvation_report`` with counts, actual density and packing diagnostics.
        ``dry_run=True`` requires ``work_dir`` and returns Data with reusable
        packing inputs and the report; omit output/output_format for a dry run.
        """
        self._require_ase()
        from ._mlmd_solvation import solvate
        return solvate(self, solute, solvent, config or self.SolvationConfig(),
                       output, output_format)

    def analyze_metadynamics(self, config=None, *, output_format="data"):
        """Analyze a 1D FES and optional infrequent kinetics from PLUMED files.

        Return a matmalib Data object accepted by ``Plot.fes_1d``. It is also
        stored as ``self.data``. With ``output_format='files'``, require
        ``config.output_dir`` and return that directory after writing CSV/JSON.
        """
        from ._mlmd_analysis import analyze
        return analyze(self, config or self.AnalysisConfig(), output_format)
